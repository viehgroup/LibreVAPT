static void
silcpurple_chat_wb(PurpleBlistNode *node, gpointer data)
{
	SilcPurpleChatWb wb = data;
	silcpurple_wb_init_ch(wb->sg, wb->channel);
	silc_free(wb);
}
