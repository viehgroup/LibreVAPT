void
purple_plugin_pref_set_bounds(PurplePluginPref *pref, int min, int max)
{
	int tmp;
	g_return_if_fail(pref       != NULL);
	g_return_if_fail(pref->name != NULL);
	if (purple_prefs_get_type(pref->name) != PURPLE_PREF_INT)
	{
		purple_debug_warning("pluginpref",
				"purple_plugin_pref_set_bounds: %s is not an integer pref\n",
				pref->name);
		return;
	}
	if (min > max)
	{
		tmp = min;
		min = max;
		max = tmp;
	}
	pref->min = min;
	pref->max = max;
}
