void
pidgin_dialogs_im_with_user(PurpleAccount *account, const char *username)
{
	PurpleConversation *conv;
	g_return_if_fail(account != NULL);
	g_return_if_fail(username != NULL);
	conv = purple_find_conversation_with_account(PURPLE_CONV_TYPE_IM, username, account);
	if (conv == NULL)
		conv = purple_conversation_new(PURPLE_CONV_TYPE_IM, account, username);
	pidgin_conv_attach_to_conversation(conv);
	purple_conversation_present(conv);
}
