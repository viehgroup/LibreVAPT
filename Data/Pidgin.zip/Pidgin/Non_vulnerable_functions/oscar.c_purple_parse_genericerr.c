}
static int purple_parse_genericerr(OscarData *od, FlapConnection *conn, FlapFrame *fr, ...) {
	va_list ap;
	guint16 reason;
	va_start(ap, fr);
	reason = (guint16) va_arg(ap, unsigned int);
	va_end(ap);
	purple_debug_error("oscar", "snac threw error (reason 0x%04hx: %s)\n",
			reason, oscar_get_msgerr_reason(reason));
	return 1;
}
