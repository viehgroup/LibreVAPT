}
static void nullprpl_roomlist_expand_category(PurpleRoomlist *list,
                                              PurpleRoomlistRoom *category) {
 purple_debug_info("nullprpl", "%s asked to expand room list category %s\n",
                   list->account->username, category->name);
}
