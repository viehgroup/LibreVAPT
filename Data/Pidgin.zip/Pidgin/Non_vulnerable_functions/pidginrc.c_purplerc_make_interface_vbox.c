static GtkWidget *
purplerc_make_interface_vbox(void)
{
	GtkWidget *vbox = NULL, *hbox = NULL, *check = NULL;
	GtkSizeGroup *labelsg = NULL;
	gsize i;
	vbox = gtk_vbox_new(FALSE, PIDGIN_HIG_CAT_SPACE);
	labelsg = gtk_size_group_new(GTK_SIZE_GROUP_HORIZONTAL);
	gtk_container_set_border_width(GTK_CONTAINER(vbox), PIDGIN_HIG_BORDER);
	for (i = 0; i < G_N_ELEMENTS(color_prefs); i++) {
		hbox = gtk_hbox_new(FALSE, PIDGIN_HIG_CAT_SPACE);
		gtk_box_pack_start(GTK_BOX(vbox), hbox, FALSE, FALSE, 0);
		check = pidgin_prefs_checkbox(_(color_names[i]),
		                              color_prefs_set[i], hbox);
		gtk_size_group_add_widget(labelsg, check);
		color_widgets[i] = pidgin_pixbuf_button_from_stock("",
				GTK_STOCK_SELECT_COLOR, PIDGIN_BUTTON_HORIZONTAL);
		gtk_box_pack_start(GTK_BOX(hbox), color_widgets[i], FALSE,
		                   FALSE, 0);
		gtk_widget_set_sensitive(color_widgets[i],
		                         purple_prefs_get_bool(color_prefs_set[i]));
		g_signal_connect(G_OBJECT(check), "toggled",
		                 G_CALLBACK(pidgin_toggle_sensitive),
		                 color_widgets[i]);
		g_signal_connect(G_OBJECT(color_widgets[i]), "clicked",
		                 G_CALLBACK(purplerc_set_color),
		                 GINT_TO_POINTER(i));
	}
	g_object_unref(labelsg);
	return vbox;
}
