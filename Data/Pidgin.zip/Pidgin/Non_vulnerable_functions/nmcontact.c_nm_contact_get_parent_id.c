int
nm_contact_get_parent_id(NMContact * contact)
{
	if (contact == NULL)
		return -1;
	return contact->parent_id;
}
