void
gtk_source_undo_manager_end_not_undoable_action (GtkSourceUndoManager *um)
{
	g_return_if_fail (GTK_SOURCE_IS_UNDO_MANAGER (um));
	g_return_if_fail (um->priv != NULL);
	gtk_source_undo_manager_end_not_undoable_action_internal (um);
	if (um->priv->running_not_undoable_actions == 0)
	{
		gtk_source_undo_manager_free_action_list (um);
		um->priv->next_redo = -1;
		if (um->priv->can_undo)
		{
			um->priv->can_undo = FALSE;
			g_signal_emit (G_OBJECT (um),
				       undo_manager_signals [CAN_UNDO],
				       0,
				       FALSE);
		}
		if (um->priv->can_redo)
		{
			um->priv->can_redo = FALSE;
			g_signal_emit (G_OBJECT (um),
				       undo_manager_signals [CAN_REDO],
				       0,
				       FALSE);
		}
	}
}
