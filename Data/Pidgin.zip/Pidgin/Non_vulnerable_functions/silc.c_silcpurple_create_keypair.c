static void
silcpurple_create_keypair(PurplePluginAction *action)
{
	PurpleConnection *gc = (PurpleConnection *) action->context;
	SilcPurple sg = gc->proto_data;
	PurpleRequestFields *fields;
	PurpleRequestFieldGroup *g;
	PurpleRequestField *f;
	const char *username, *realname;
	char *hostname, **u;
	char tmp[256], pkd[256], pkd2[256], prd[256], prd2[256];
	username = purple_account_get_username(sg->account);
	u = g_strsplit(username, "@", 2);
	username = u[0];
	realname = purple_account_get_user_info(sg->account);
	hostname = silc_net_localhost();
	g_snprintf(tmp, sizeof(tmp), "%s@%s", username, hostname);
	g_snprintf(pkd2, sizeof(pkd2), "%s" G_DIR_SEPARATOR_S"public_key.pub", silcpurple_silcdir());
	g_snprintf(prd2, sizeof(prd2), "%s" G_DIR_SEPARATOR_S"private_key.prv", silcpurple_silcdir());
	g_snprintf(pkd, sizeof(pkd) - 1, "%s",
		   purple_account_get_string(gc->account, "public-key", pkd2));
	g_snprintf(prd, sizeof(prd) - 1, "%s",
		   purple_account_get_string(gc->account, "private-key", prd2));
	fields = purple_request_fields_new();
	g = purple_request_field_group_new(NULL);
	f = purple_request_field_string_new("key", _("Key length"), "2048", FALSE);
	purple_request_field_group_add_field(g, f);
	f = purple_request_field_string_new("pkfile", _("Public key file"), pkd, FALSE);
	purple_request_field_group_add_field(g, f);
	f = purple_request_field_string_new("prfile", _("Private key file"), prd, FALSE);
	purple_request_field_group_add_field(g, f);
	purple_request_fields_add_group(fields, g);
	g = purple_request_field_group_new(NULL);
	f = purple_request_field_string_new("un", _("Username"), username ? username : "", FALSE);
	purple_request_field_group_add_field(g, f);
	f = purple_request_field_string_new("hn", _("Hostname"), hostname ? hostname : "", FALSE);
	purple_request_field_group_add_field(g, f);
	f = purple_request_field_string_new("rn", _("Real name"), realname ? realname : "", FALSE);
	purple_request_field_group_add_field(g, f);
	f = purple_request_field_string_new("e", _("Email"), tmp, FALSE);
	purple_request_field_group_add_field(g, f);
	f = purple_request_field_string_new("o", _("Organization"), "", FALSE);
	purple_request_field_group_add_field(g, f);
	f = purple_request_field_string_new("c", _("Country"), "", FALSE);
	purple_request_field_group_add_field(g, f);
	purple_request_fields_add_group(fields, g);
	g = purple_request_field_group_new(NULL);
	f = purple_request_field_string_new("pass1", _("Passphrase"), "", FALSE);
	purple_request_field_string_set_masked(f, TRUE);
	purple_request_field_group_add_field(g, f);
	f = purple_request_field_string_new("pass2", _("Passphrase (retype)"), "", FALSE);
	purple_request_field_string_set_masked(f, TRUE);
	purple_request_field_group_add_field(g, f);
	purple_request_fields_add_group(fields, g);
	purple_request_fields(gc, _("Create New SILC Key Pair"),
			    _("Create New SILC Key Pair"), NULL, fields,
			    _("Generate Key Pair"), G_CALLBACK(silcpurple_create_keypair_cb),
			    _("Cancel"), G_CALLBACK(silcpurple_create_keypair_cancel),
				gc->account, NULL, NULL, gc);
	g_strfreev(u);
	silc_free(hostname);
}
