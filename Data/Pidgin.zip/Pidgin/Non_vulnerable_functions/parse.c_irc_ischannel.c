}
gboolean irc_ischannel(const char *string)
{
	return (string[0] == '#' || string[0] == '&');
}
