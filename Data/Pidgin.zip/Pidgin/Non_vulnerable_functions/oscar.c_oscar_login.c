void
oscar_login(PurpleAccount *account)
{
	PurpleConnection *gc;
	OscarData *od;
	const gchar *encryption_type;
	const gchar *login_type;
	GList *handlers;
	GList *sorted_handlers;
	GList *cur;
	GString *msg = g_string_new("");
	gc = purple_account_get_connection(account);
	od = oscar_data_new();
	od->gc = gc;
	purple_connection_set_protocol_data(gc, od);
	oscar_data_addhandler(od, AIM_CB_FAM_SPECIAL, AIM_CB_SPECIAL_CONNERR, purple_connerr, 0);
	oscar_data_addhandler(od, AIM_CB_FAM_SPECIAL, AIM_CB_SPECIAL_CONNINITDONE, flap_connection_established, 0);
	oscar_data_addhandler(od, SNAC_FAMILY_ADMIN, 0x0003, purple_info_change, 0);
	oscar_data_addhandler(od, SNAC_FAMILY_ADMIN, 0x0005, purple_info_change, 0);
	oscar_data_addhandler(od, SNAC_FAMILY_ADMIN, 0x0007, purple_account_confirm, 0);
	oscar_data_addhandler(od, SNAC_FAMILY_ALERT, 0x0001, purple_parse_genericerr, 0);
	oscar_data_addhandler(od, SNAC_FAMILY_ALERT, SNAC_SUBTYPE_ALERT_MAILSTATUS, purple_email_parseupdate, 0);
	/* These are only needed when connecting with the old-style BUCP login */
	oscar_data_addhandler(od, SNAC_FAMILY_AUTH, 0x0003, purple_parse_auth_resp, 0);
	oscar_data_addhandler(od, SNAC_FAMILY_AUTH, 0x0007, purple_parse_login, 0);
	oscar_data_addhandler(od, SNAC_FAMILY_AUTH, SNAC_SUBTYPE_AUTH_SECURID_REQUEST, purple_parse_auth_securid_request, 0);
	oscar_data_addhandler(od, SNAC_FAMILY_BART, SNAC_SUBTYPE_BART_RESPONSE, purple_icon_parseicon, 0);
	oscar_data_addhandler(od, SNAC_FAMILY_BOS, 0x0001, purple_parse_genericerr, 0);
	oscar_data_addhandler(od, SNAC_FAMILY_BOS, 0x0003, purple_bosrights, 0);
	oscar_data_addhandler(od, SNAC_FAMILY_BUDDY, 0x0001, purple_parse_genericerr, 0);
	oscar_data_addhandler(od, SNAC_FAMILY_BUDDY, SNAC_SUBTYPE_BUDDY_RIGHTSINFO, purple_parse_buddyrights, 0);
	oscar_data_addhandler(od, SNAC_FAMILY_BUDDY, SNAC_SUBTYPE_BUDDY_ONCOMING, purple_parse_oncoming, 0);
	oscar_data_addhandler(od, SNAC_FAMILY_BUDDY, SNAC_SUBTYPE_BUDDY_OFFGOING, purple_parse_offgoing, 0);
	oscar_data_addhandler(od, SNAC_FAMILY_CHAT, 0x0001, purple_parse_genericerr, 0);
	oscar_data_addhandler(od, SNAC_FAMILY_CHAT, SNAC_SUBTYPE_CHAT_USERJOIN, purple_conv_chat_join, 0);
	oscar_data_addhandler(od, SNAC_FAMILY_CHAT, SNAC_SUBTYPE_CHAT_USERLEAVE, purple_conv_chat_leave, 0);
	oscar_data_addhandler(od, SNAC_FAMILY_CHAT, SNAC_SUBTYPE_CHAT_ROOMINFOUPDATE, purple_conv_chat_info_update, 0);
	oscar_data_addhandler(od, SNAC_FAMILY_CHAT, SNAC_SUBTYPE_CHAT_INCOMINGMSG, purple_conv_chat_incoming_msg, 0);
	oscar_data_addhandler(od, SNAC_FAMILY_CHATNAV, 0x0001, purple_parse_genericerr, 0);
	oscar_data_addhandler(od, SNAC_FAMILY_CHATNAV, SNAC_SUBTYPE_CHATNAV_INFO, purple_chatnav_info, 0);
	oscar_data_addhandler(od, SNAC_FAMILY_FEEDBAG, SNAC_SUBTYPE_FEEDBAG_ERROR, purple_ssi_parseerr, 0);
	oscar_data_addhandler(od, SNAC_FAMILY_FEEDBAG, SNAC_SUBTYPE_FEEDBAG_RIGHTSINFO, purple_ssi_parserights, 0);
	oscar_data_addhandler(od, SNAC_FAMILY_FEEDBAG, SNAC_SUBTYPE_FEEDBAG_LIST, purple_ssi_parselist, 0);
	oscar_data_addhandler(od, SNAC_FAMILY_FEEDBAG, SNAC_SUBTYPE_FEEDBAG_SRVACK, purple_ssi_parseack, 0);
	oscar_data_addhandler(od, SNAC_FAMILY_FEEDBAG, SNAC_SUBTYPE_FEEDBAG_ADD, purple_ssi_parseaddmod, 0);
	oscar_data_addhandler(od, SNAC_FAMILY_FEEDBAG, SNAC_SUBTYPE_FEEDBAG_MOD, purple_ssi_parseaddmod, 0);
	oscar_data_addhandler(od, SNAC_FAMILY_FEEDBAG, SNAC_SUBTYPE_FEEDBAG_RECVAUTH, purple_ssi_authgiven, 0);
	oscar_data_addhandler(od, SNAC_FAMILY_FEEDBAG, SNAC_SUBTYPE_FEEDBAG_RECVAUTHREQ, purple_ssi_authrequest, 0);
	oscar_data_addhandler(od, SNAC_FAMILY_FEEDBAG, SNAC_SUBTYPE_FEEDBAG_RECVAUTHREP, purple_ssi_authreply, 0);
	oscar_data_addhandler(od, SNAC_FAMILY_FEEDBAG, SNAC_SUBTYPE_FEEDBAG_ADDED, purple_ssi_gotadded, 0);
	oscar_data_addhandler(od, SNAC_FAMILY_ICBM, SNAC_SUBTYPE_ICBM_INCOMING, purple_parse_incoming_im, 0);
	oscar_data_addhandler(od, SNAC_FAMILY_ICBM, SNAC_SUBTYPE_ICBM_MISSEDCALL, purple_parse_misses, 0);
	oscar_data_addhandler(od, SNAC_FAMILY_ICBM, SNAC_SUBTYPE_ICBM_CLIENTAUTORESP, purple_parse_clientauto, 0);
	oscar_data_addhandler(od, SNAC_FAMILY_ICBM, SNAC_SUBTYPE_ICBM_MTN, purple_parse_mtn, 0);
	oscar_data_addhandler(od, SNAC_FAMILY_LOCATE, SNAC_SUBTYPE_LOCATE_RIGHTSINFO, purple_parse_locaterights, 0);
	oscar_data_addhandler(od, SNAC_FAMILY_OSERVICE, 0x0001, purple_parse_genericerr, 0);
	oscar_data_addhandler(od, SNAC_FAMILY_OSERVICE, 0x000f, purple_selfinfo, 0);
	oscar_data_addhandler(od, SNAC_FAMILY_OSERVICE, 0x001f, purple_memrequest, 0);
	oscar_data_addhandler(od, SNAC_FAMILY_OSERVICE, SNAC_SUBTYPE_OSERVICE_REDIRECT, purple_handle_redirect, 0);
	oscar_data_addhandler(od, SNAC_FAMILY_OSERVICE, SNAC_SUBTYPE_OSERVICE_MOTD, purple_parse_motd, 0);
	oscar_data_addhandler(od, SNAC_FAMILY_POPUP, 0x0002, purple_popup, 0);
	oscar_data_addhandler(od, SNAC_FAMILY_USERLOOKUP, SNAC_SUBTYPE_USERLOOKUP_ERROR, purple_parse_searcherror, 0);
	oscar_data_addhandler(od, SNAC_FAMILY_USERLOOKUP, 0x0003, purple_parse_searchreply, 0);
	g_string_append(msg, "Registered handlers: ");
#if GLIB_CHECK_VERSION(2,14,0)
	handlers = g_hash_table_get_keys(od->handlerlist);
#else
	handlers = NULL;
	g_hash_table_foreach(od->handlerlist, hash_table_get_list_of_keys, &handlers);
#endif /* GLIB < 2.14.0 */
	sorted_handlers = g_list_sort(g_list_copy(handlers), compare_handlers);
	for (cur = sorted_handlers; cur; cur = cur->next) {
		guint x = GPOINTER_TO_UINT(cur->data);
		g_string_append_printf(msg, "%04x/%04x, ", x >> 16, x & 0xFFFF);
	}
	g_list_free(sorted_handlers);
	g_list_free(handlers);
	purple_debug_misc("oscar", "%s\n", msg->str);
	g_string_free(msg, TRUE);
	purple_debug_misc("oscar", "oscar_login: gc = %p\n", gc);
	if (!oscar_util_valid_name(purple_account_get_username(account))) {
		gchar *buf;
		buf = g_strdup_printf(_("Unable to sign on as %s because the username is invalid.  Usernames must be a valid email address, or start with a letter and contain only letters, numbers and spaces, or contain only numbers."), purple_account_get_username(account));
		purple_connection_error_reason(gc, PURPLE_CONNECTION_ERROR_INVALID_SETTINGS, buf);
		g_free(buf);
		return;
	}
	gc->flags |= PURPLE_CONNECTION_HTML;
	if (g_str_equal(purple_account_get_protocol_id(account), "prpl-icq")) {
		od->icq = TRUE;
	} else {
		gc->flags |= PURPLE_CONNECTION_AUTO_RESP;
	}
	/* Set this flag based on the protocol_id rather than the username,
	   because that is what's tied to the get_moods prpl callback. */
	if (g_str_equal(purple_account_get_protocol_id(account), "prpl-icq"))
		gc->flags |= PURPLE_CONNECTION_SUPPORT_MOODS;
	od->default_port = purple_account_get_int(account, "port", OSCAR_DEFAULT_LOGIN_PORT);
	login_type = purple_account_get_string(account, "login_type", OSCAR_DEFAULT_LOGIN);
	encryption_type = purple_account_get_string(account, "encryption", OSCAR_DEFAULT_ENCRYPTION);
	if (!purple_ssl_is_supported() && strcmp(encryption_type, OSCAR_REQUIRE_ENCRYPTION) == 0) {
		purple_connection_error_reason(
			gc,
			PURPLE_CONNECTION_ERROR_NO_SSL_SUPPORT,
			_("You required encryption in your account settings, but encryption is not supported by your system."));
		return;
	}
	od->use_ssl = purple_ssl_is_supported() && strcmp(encryption_type, OSCAR_NO_ENCRYPTION) != 0;
	/* Connect to core Purple signals */
	purple_prefs_connect_callback(gc, "/purple/away/idle_reporting", idle_reporting_pref_cb, gc);
	purple_prefs_connect_callback(gc, "/plugins/prpl/oscar/recent_buddies", recent_buddies_pref_cb, gc);
	/*
	 * On 2008-03-05 AOL released some documentation on the OSCAR protocol
	 * which includes a new login method called clientLogin.  It is similar
	 * (though not the same?) as what the AIM 6.0 series uses to
	 * authenticate.
	 *
	 * AIM 5.9 and lower use an MD5-based login procedure called "BUCP".
	 * This authentication method is used for both ICQ and AIM when
	 * clientLogin is not enabled.
	 */
	if (purple_strequal(login_type, OSCAR_CLIENT_LOGIN)) {
		/* Note: Actual server/port configuration is ignored here */
		send_client_login(od, purple_account_get_username(account));
	} else if (purple_strequal(login_type, OSCAR_KERBEROS_LOGIN)) {
		const char *server;
		if (!od->use_ssl) {
			purple_connection_error_reason(
				gc,
				PURPLE_CONNECTION_ERROR_NO_SSL_SUPPORT,
				_("You required Kerberos authentication but encryption is disabled in your account settings."));
			return;
		}
		server = purple_account_get_string(account, "server", AIM_DEFAULT_KDC_SERVER);
		/*
		 * If the account's server is what the oscar protocol has offered as
		 * the default login server through the vast eons (all two of
		 * said default options, AFAIK) and the user wants KDC, we'll
		 * do what we know is best for them and change the setting out
		 * from under them to the KDC login server.
		 */
		if (purple_strequal(server, get_login_server(od->icq, FALSE)) ||
			purple_strequal(server, get_login_server(od->icq, TRUE)) ||
			purple_strequal(server, AIM_ALT_LOGIN_SERVER) ||
			purple_strequal(server, "")) {
			purple_debug_info("oscar", "Account uses Kerberos auth, so changing server to default KDC server\n");
			purple_account_set_string(account, "server", AIM_DEFAULT_KDC_SERVER);
			purple_account_set_int(account, "port", AIM_DEFAULT_KDC_PORT);
		}
		send_kerberos_login(od, purple_account_get_username(account));
	} else {
		FlapConnection *newconn;
		const char *server;
		newconn = flap_connection_new(od, SNAC_FAMILY_AUTH);
		if (od->use_ssl) {
			server = purple_account_get_string(account, "server", get_login_server(od->icq, TRUE));
			/*
			 * If the account's server is what the oscar prpl has offered as
			 * the default login server through the vast eons (all two of
			 * said default options, AFAIK) and the user wants SSL, we'll
			 * do what we know is best for them and change the setting out
			 * from under them to the SSL login server.
			 */
			if (purple_strequal(server, get_login_server(od->icq, FALSE)) ||
				purple_strequal(server, AIM_ALT_LOGIN_SERVER) ||
				purple_strequal(server, AIM_DEFAULT_KDC_SERVER) ||
				purple_strequal(server, "")) {
				purple_debug_info("oscar", "Account uses SSL, so changing server to default SSL server\n");
				purple_account_set_string(account, "server", get_login_server(od->icq, TRUE));
				purple_account_set_int(account, "port", OSCAR_DEFAULT_LOGIN_PORT),
				server = get_login_server(od->icq, TRUE);
			}
			newconn->gsc = purple_ssl_connect(account, server,
					purple_account_get_int(account, "port", OSCAR_DEFAULT_LOGIN_PORT),
					ssl_connection_established_cb, ssl_connection_error_cb, newconn);
		} else {
			server = purple_account_get_string(account, "server", get_login_server(od->icq, FALSE));
			/*
			 * See the comment above. We do the reverse here. If they don't want
			 * SSL but their server is set to OSCAR_DEFAULT_SSL_LOGIN_SERVER,
			 * set it back to the default.
			 */
			if (purple_strequal(server, get_login_server(od->icq, TRUE)) ||
				purple_strequal(server, AIM_DEFAULT_KDC_SERVER) ||
				purple_strequal(server, "")) {
				purple_debug_info("oscar", "Account does not use SSL, so changing server back to non-SSL\n");
				purple_account_set_string(account, "server", get_login_server(od->icq, FALSE));
				purple_account_set_int(account, "port", OSCAR_DEFAULT_LOGIN_PORT),
				server = get_login_server(od->icq, FALSE);
			}
			newconn->connect_data = purple_proxy_connect(NULL, account, server,
					purple_account_get_int(account, "port", OSCAR_DEFAULT_LOGIN_PORT),
					connection_established_cb, newconn);
		}
		if (newconn->gsc == NULL && newconn->connect_data == NULL) {
			purple_connection_error_reason(gc, PURPLE_CONNECTION_ERROR_NETWORK_ERROR,
					_("Unable to connect"));
			return;
		}
	}
	purple_connection_update_progress(gc, _("Connecting"), 0, OSCAR_CONNECT_STEPS);
}
