guint32
nm_count_fields(NMField * fields)
{
	guint32 count = 0;
	if (fields) {
		while (fields->tag != NULL) {
			count++;
			fields++;
		}
	}
	return count;
}
