PurpleTypingState
purple_conv_im_get_typing_state(const PurpleConvIm *im)
{
	g_return_val_if_fail(im != NULL, 0);
	return im->typing_state;
}
