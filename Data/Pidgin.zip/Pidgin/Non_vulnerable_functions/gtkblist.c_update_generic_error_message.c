static void
update_generic_error_message(PurpleAccount *account,
                             const char *description)
{
	PidginBuddyListPrivate *priv = PIDGIN_BUDDY_LIST_GET_PRIVATE(gtkblist);
	GtkWidget *mini_dialog = find_child_widget_by_account(
		GTK_CONTAINER(priv->error_scrollbook), account);
	pidgin_mini_dialog_set_description(PIDGIN_MINI_DIALOG(mini_dialog),
		description);
}
