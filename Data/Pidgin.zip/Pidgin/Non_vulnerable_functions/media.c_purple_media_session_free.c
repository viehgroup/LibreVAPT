static void
purple_media_session_free(PurpleMediaSession *session)
{
	if (session == NULL)
		return;
	g_free(session->id);
	g_free(session);
}
