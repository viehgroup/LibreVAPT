static void
jabber_caps_client_info_destroy(JabberCapsClientInfo *info)
{
	if (info == NULL)
		return;
	while(info->identities) {
		JabberIdentity *id = info->identities->data;
		g_free(id->category);
		g_free(id->type);
		g_free(id->name);
		g_free(id->lang);
		g_free(id);
		info->identities = g_list_delete_link(info->identities, info->identities);
	}
	free_string_glist(info->features);
	while (info->forms) {
		xmlnode_free(info->forms->data);
		info->forms = g_list_delete_link(info->forms, info->forms);
	}
	jabber_caps_node_exts_unref(info->exts);
	g_free((char *)info->tuple.node);
	g_free((char *)info->tuple.ver);
	g_free((char *)info->tuple.hash);
	g_free(info);
}
