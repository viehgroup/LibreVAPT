}
void gg_image_sendout(struct gg_session *sess)
{
	struct gg_session_private *p = sess->private_data;
	while (p->imgout_waiting_ack < GG_IMGOUT_WAITING_MAX && p->imgout_queue) {
		gg_imgout_queue_t *it = p->imgout_queue;
		int res;
		p->imgout_queue = p->imgout_queue->next;
		p->imgout_waiting_ack++;
		res = gg_send_packet(sess, GG_SEND_MSG,
			&it->msg_hdr, sizeof(it->msg_hdr),
			it->buf, it->buf_len,
			NULL);
		free(it);
		if (res == -1)
			break;
	}
}
