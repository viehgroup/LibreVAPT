void
nm_folder_add_ref(NMFolder * folder)
{
	if (folder)
		folder->ref_count++;
}
