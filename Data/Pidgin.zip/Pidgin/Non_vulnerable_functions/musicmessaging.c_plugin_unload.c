static gboolean
plugin_unload(PurplePlugin *plugin) {
	MMConversation *mmconv = NULL;
	while (conversations != NULL)
	{
		mmconv = conversations->data;
		conv_destroyed(mmconv->conv);
	}
	return TRUE;
}
