}
void purple_conversation_clear_message_history(PurpleConversation *conv)
{
	GList *list = conv->message_history;
	message_history_free(list);
	conv->message_history = NULL;
	purple_signal_emit(purple_conversations_get_handle(),
			"cleared-message-history", conv);
}
