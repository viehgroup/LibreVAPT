}
void purple_marshal_VOID__POINTER_INT_INT(PurpleCallback cb, va_list args,
                                        void *data, void **return_val)
{
	void *arg1 = va_arg(args, void *);
	gint arg2 = va_arg(args, gint);
	gint arg3 = va_arg(args, gint);
	((void (*)(void *, gint, gint, void *))cb)(arg1, arg2, arg3, data);
}
