guint64
aim_locate_getcaps(OscarData *od, ByteStream *bs, int len)
{
	guint64 flags = 0;
	int offset;
	for (offset = 0; byte_stream_bytes_left(bs) && (offset < len); offset += 0x10) {
		guint8 *cap;
		int i, identified;
		cap = byte_stream_getraw(bs, 0x10);
		for (i = 0, identified = 0; !(aim_caps[i].flag & OSCAR_CAPABILITY_LAST); i++) {
			if (memcmp(&aim_caps[i].data, cap, 0x10) == 0) {
				flags |= aim_caps[i].flag;
				identified++;
				break; /* should only match once... */
			}
		}
		if (!identified)
			purple_debug_misc("oscar", "unknown capability: {%02x%02x%02x%02x-%02x%02x-%02x%02x-%02x%02x-%02x%02x%02x%02x%02x%02x}\n",
					cap[0], cap[1], cap[2], cap[3],
					cap[4], cap[5],
					cap[6], cap[7],
					cap[8], cap[9],
					cap[10], cap[11], cap[12], cap[13],
					cap[14], cap[15]);
		g_free(cap);
	}
	return flags;
}
