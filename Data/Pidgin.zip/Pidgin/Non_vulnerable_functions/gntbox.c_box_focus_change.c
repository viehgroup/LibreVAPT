static gboolean
box_focus_change(GntBox *box, gboolean next)
{
	GntWidget *now;
	now = box->active;
	if (next) {
		find_next_focus(box);
	} else {
		find_prev_focus(box);
	}
	if (now && now != box->active) {
		gnt_widget_set_focus(now, FALSE);
		gnt_widget_set_focus(box->active, TRUE);
		return TRUE;
	}
	return FALSE;
}
