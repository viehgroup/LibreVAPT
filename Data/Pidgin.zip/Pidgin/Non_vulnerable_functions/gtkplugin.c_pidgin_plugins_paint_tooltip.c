static gboolean
pidgin_plugins_paint_tooltip(GtkWidget *tipwindow, gpointer data)
{
	PangoLayout *layout = g_object_get_data(G_OBJECT(tipwindow), "tooltip-plugin");
	gtk_paint_layout(tipwindow->style, tipwindow->window, GTK_STATE_NORMAL, FALSE,
			NULL, tipwindow, "tooltip",
			6, 6, layout);
	return TRUE;
}
