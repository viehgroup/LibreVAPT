}
static guint _purple_logsize_user_equal(struct _purple_logsize_user *lu1,
		struct _purple_logsize_user *lu2)
{
	return (lu1->account == lu2->account && purple_strequal(lu1->name, lu2->name));
}
