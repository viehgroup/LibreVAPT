static void
peer_connection_got_proposition_no_cb(gpointer data, gint id)
{
	PeerConnection *conn;
	conn = data;
	aim_im_denytransfer(conn->od, conn->bn, conn->cookie,
			AIM_TRANSFER_DENY_DECLINE);
	peer_connection_destroy(conn, OSCAR_DISCONNECT_LOCAL_CLOSED, NULL);
}
