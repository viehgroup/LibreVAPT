void
oscar_auth_recvrequest(PurpleConnection *gc, gchar *name, gchar *nick, gchar *reason)
{
	PurpleAccount* account = purple_connection_get_account(gc);
	struct name_data *data = g_new(struct name_data, 1);
	data->gc = gc;
	data->name = name;
	data->nick = nick;
	purple_account_request_authorization(account, data->name, NULL, data->nick,
		reason, purple_find_buddy(account, data->name) != NULL,
		oscar_auth_grant, oscar_auth_dontgrant_msgprompt, data);
}
