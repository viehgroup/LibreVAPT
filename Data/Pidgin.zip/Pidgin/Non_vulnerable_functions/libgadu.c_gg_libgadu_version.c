 */
const char *gg_libgadu_version(void)
{
	return GG_LIBGADU_VERSION;
}
