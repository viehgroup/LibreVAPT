static void
silcpurple_add_buddy_select_cb(SilcPurpleBuddyRes r, PurpleRequestFields *fields)
{
	PurpleRequestField *f;
	GList *list;
	SilcClientEntry client_entry;
	f = purple_request_fields_get_field(fields, "list");
	list = purple_request_field_list_get_selected(f);
	if (!list) {
		/* The user did not select any user. */
		silcpurple_add_buddy_pk_no(r);
		silc_free(r);
		return;
	}
	client_entry = purple_request_field_list_get_data(f, list->data);
	silcpurple_add_buddy_resolved(r->client, r->conn, &client_entry, 1, r);
}
