void
gnt_widget_draw(GntWidget *widget)
{
	/* Draw the widget */
	if (GNT_WIDGET_IS_FLAG_SET(widget, GNT_WIDGET_DRAWING))
		return;
	GNT_WIDGET_SET_FLAGS(widget, GNT_WIDGET_DRAWING);
	if (!(GNT_WIDGET_FLAGS(widget) & GNT_WIDGET_MAPPED)) {
		gnt_widget_map(widget);
	}
	if (widget->window == NULL)
	{
#if 0
		int x, y, maxx, maxy, w, h;
		int oldw, oldh;
		gboolean shadow = TRUE;
		if (!gnt_widget_has_shadow(widget))
			shadow = FALSE;
		x = widget->priv.x;
		y = widget->priv.y;
		w = oldw = widget->priv.width + shadow;
		h = oldh = widget->priv.height + shadow;
		getmaxyx(stdscr, maxy, maxx);
		maxy -= 1;		/* room for the taskbar */
		x = MAX(0, x);
		y = MAX(0, y);
		if (x + w >= maxx)
			x = MAX(0, maxx - w);
		if (y + h >= maxy)
			y = MAX(0, maxy - h);
		w = MIN(w, maxx);
		h = MIN(h, maxy);
		widget->priv.x = x;
		widget->priv.y = y;
		if (w != oldw || h != oldh) {
			widget->priv.width = w - shadow;
			widget->priv.height = h - shadow;
			g_signal_emit(widget, signals[SIG_SIZE_CHANGED], 0, oldw, oldh);
		}
#else
		widget->window = newpad(widget->priv.height + 20, widget->priv.width + 20);  /* XXX: */
#endif
		init_widget(widget);
	}
	g_signal_emit(widget, signals[SIG_DRAW], 0);
	gnt_widget_queue_update(widget);
	GNT_WIDGET_UNSET_FLAGS(widget, GNT_WIDGET_DRAWING);
}
