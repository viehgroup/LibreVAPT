void
purple_prefs_rename_boolean_toggle(const char *oldname, const char *newname)
{
		struct purple_pref *oldpref, *newpref;
		PURPLE_PREFS_UI_OP_CALL(rename_boolean_toggle, oldname, newname);
		oldpref = find_pref(oldname);
		/* it's already been renamed, call off the cats */
		if(!oldpref)
			return;
		if (oldpref->type != PURPLE_PREF_BOOLEAN)
		{
			purple_debug_error("prefs", "Unable to rename %s to %s: old pref not a boolean\n", oldname, newname);
			return;
		}
		if (oldpref->first_child != NULL) /* can't rename parents */
		{
			purple_debug_error("prefs", "Unable to rename %s to %s: can't rename parents\n", oldname, newname);
			return;
		}
		newpref = find_pref(newname);
		if (newpref == NULL)
		{
			purple_debug_error("prefs", "Unable to rename %s to %s: new pref not created\n", oldname, newname);
			return;
		}
		if (oldpref->type != newpref->type)
		{
			purple_debug_error("prefs", "Unable to rename %s to %s: differing types\n", oldname, newname);
			return;
		}
		purple_debug_info("prefs", "Renaming and toggling %s to %s\n", oldname, newname);
		purple_prefs_set_bool(newname, !(oldpref->value.boolean));
		remove_pref(oldpref);
}
