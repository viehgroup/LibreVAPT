static void
pidgin_status_box_size_request(GtkWidget *widget,
								 GtkRequisition *requisition)
{
	GtkRequisition box_req;
	gint border_width = GTK_CONTAINER (widget)->border_width;
	gtk_widget_size_request(PIDGIN_STATUS_BOX(widget)->toggle_button, requisition);
	/* Make this icon the same size as other buddy icons in the list; unless it already wants to be bigger */
	requisition->height = MAX(requisition->height, 34);
	requisition->height += border_width * 2;
	/* If the gtkimhtml is visible, then add some additional padding */
	gtk_widget_size_request(PIDGIN_STATUS_BOX(widget)->vbox, &box_req);
	if (box_req.height > 1)
		requisition->height += box_req.height + border_width * 2;
	requisition->width = 1;
}
