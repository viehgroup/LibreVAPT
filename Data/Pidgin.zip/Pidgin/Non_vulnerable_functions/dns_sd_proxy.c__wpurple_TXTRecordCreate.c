}
void _wpurple_TXTRecordCreate(TXTRecordRef *txtRecord, uint16_t bufferLen, void *buffer) {
	g_return_if_fail(_TXTRecordCreate != NULL);
	(_TXTRecordCreate)(txtRecord, bufferLen, buffer);
}
