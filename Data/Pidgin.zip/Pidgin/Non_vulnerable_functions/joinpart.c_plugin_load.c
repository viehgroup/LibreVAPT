}
static gboolean plugin_load(PurplePlugin *plugin)
{
	void *conv_handle;
	GHashTable *users;
	guint id;
	gpointer *data;
	users = g_hash_table_new_full((GHashFunc)joinpart_key_hash,
	                              (GEqualFunc)joinpart_key_equal,
	                              (GDestroyNotify)joinpart_key_destroy,
	                              g_free);
	conv_handle = purple_conversations_get_handle();
	purple_signal_connect(conv_handle, "chat-buddy-joining", plugin,
	                    PURPLE_CALLBACK(chat_buddy_joining_cb), users);
	purple_signal_connect(conv_handle, "chat-buddy-leaving", plugin,
	                    PURPLE_CALLBACK(chat_buddy_leaving_cb), users);
	purple_signal_connect(conv_handle, "received-chat-msg", plugin,
	                    PURPLE_CALLBACK(received_chat_msg_cb), users);
	/* Cleanup every 5 minutes */
	id = purple_timeout_add_seconds(60 * 5, (GSourceFunc)clean_users_hash, users);
	data = g_new(gpointer, 2);
	data[0] = users;
	data[1] = GUINT_TO_POINTER(id);
	plugin->extra = data;
	return TRUE;
}
