static void
clear_cb(GtkWidget *w, GevoAssociateBuddyDialog *dialog)
{
	static gboolean lock = FALSE;
	if (lock)
		return;
	lock = TRUE;
	gtk_entry_set_text(GTK_ENTRY(dialog->search_field), "");
	lock = FALSE;
}
