static void
pack_prpl_icon_start(GtkWidget *box,
                     PurpleAccount *account)
{
	GdkPixbuf *pixbuf;
	GtkWidget *image;
	pixbuf = pidgin_create_prpl_icon(account, PIDGIN_PRPL_ICON_SMALL);
	if (pixbuf != NULL) {
		image = gtk_image_new_from_pixbuf(pixbuf);
		g_object_unref(pixbuf);
		gtk_box_pack_start(GTK_BOX(box), image, FALSE, FALSE, 0);
	}
}
