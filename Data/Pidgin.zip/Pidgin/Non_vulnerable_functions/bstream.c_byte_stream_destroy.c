}
void byte_stream_destroy(ByteStream *bs)
{
	g_free(bs->data);
}
