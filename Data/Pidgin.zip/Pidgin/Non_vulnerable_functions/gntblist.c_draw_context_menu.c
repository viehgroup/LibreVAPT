static void
draw_context_menu(FinchBlist *ggblist)
{
	PurpleBlistNode *node = NULL;
	GntWidget *context = NULL;
	GntTree *tree = NULL;
	int x, y, top, width;
	char *title = NULL;
	if (ggblist->context)
		return;
	tree = GNT_TREE(ggblist->tree);
	node = gnt_tree_get_selection_data(tree);
	if (node && purple_blist_node_get_type(node) == PURPLE_BLIST_OTHER_NODE)
		return;
	if (ggblist->tooltip)
		remove_tooltip(ggblist);
	ggblist->cnode = node;
	ggblist->context = context = gnt_menu_new(GNT_MENU_POPUP);
	g_signal_connect(G_OBJECT(context), "destroy", G_CALLBACK(context_menu_destroyed), ggblist);
	g_signal_connect(G_OBJECT(context), "hide", G_CALLBACK(gnt_widget_destroy), NULL);
	if (!node) {
		create_group_menu(GNT_MENU(context), NULL);
		title = g_strdup(_("Buddy List"));
	} else if (PURPLE_BLIST_NODE_IS_CONTACT(node)) {
		ggblist->cnode = PURPLE_BLIST_NODE(purple_contact_get_priority_buddy(PURPLE_CONTACT(node)));
		create_buddy_menu(GNT_MENU(context), (PurpleBuddy*)ggblist->cnode);
		title = g_strdup(purple_contact_get_alias((PurpleContact*)node));
	} else if (PURPLE_BLIST_NODE_IS_BUDDY(node)) {
		PurpleBuddy *buddy = (PurpleBuddy *)node;
		create_buddy_menu(GNT_MENU(context), buddy);
		title = g_strdup(purple_buddy_get_name(buddy));
	} else if (PURPLE_BLIST_NODE_IS_CHAT(node)) {
		PurpleChat *chat = (PurpleChat*)node;
		create_chat_menu(GNT_MENU(context), chat);
		title = g_strdup(purple_chat_get_name(chat));
	} else if (PURPLE_BLIST_NODE_IS_GROUP(node)) {
		PurpleGroup *group = (PurpleGroup *)node;
		create_group_menu(GNT_MENU(context), group);
		title = g_strdup(purple_group_get_name(group));
	}
	append_extended_menu(GNT_MENU(context), node);
	/* These are common for everything */
	if (node) {
		add_custom_action(GNT_MENU(context),
				PURPLE_BLIST_NODE_IS_GROUP(node) ? _("Rename") : _("Alias"),
				PURPLE_CALLBACK(finch_blist_rename_node_cb), node);
		add_custom_action(GNT_MENU(context), _("Remove"),
				PURPLE_CALLBACK(finch_blist_remove_node_cb), node);
		if (ggblist->tagged && (PURPLE_BLIST_NODE_IS_CONTACT(node)
				|| PURPLE_BLIST_NODE_IS_GROUP(node))) {
			add_custom_action(GNT_MENU(context), _("Place tagged"),
					PURPLE_CALLBACK(finch_blist_place_tagged), node);
		}
		if (PURPLE_BLIST_NODE_IS_BUDDY(node) || PURPLE_BLIST_NODE_IS_CONTACT(node)) {
			add_custom_action(GNT_MENU(context), _("Toggle Tag"),
					PURPLE_CALLBACK(finch_blist_toggle_tag_buddy), node);
		}
		if (!PURPLE_BLIST_NODE_IS_GROUP(node)) {
			add_custom_action(GNT_MENU(context), _("View Log"),
					PURPLE_CALLBACK(showlog_cb), node);
		}
	}
	/* Set the position for the popup */
	gnt_widget_get_position(GNT_WIDGET(tree), &x, &y);
	gnt_widget_get_size(GNT_WIDGET(tree), &width, NULL);
	top = gnt_tree_get_selection_visible_line(tree);
	x += width;
	y += top - 1;
	gnt_widget_set_position(context, x, y);
	gnt_screen_menu_show(GNT_MENU(context));
	g_free(title);
}
