static gboolean
displaying_im_msg_cb(PurpleAccount *account, const char *who, char **buffer,
				PurpleConversation *conv, PurpleMessageFlags flags, void *data)
{
	purple_debug_misc("gtk-signals test", "displaying-im-msg (%s, %s)\n",
					purple_conversation_get_name(conv), *buffer);
	return FALSE;
}
