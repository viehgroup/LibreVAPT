void
nm_release_conference(NMConference * conference)
{
	GSList *node;
	g_return_if_fail(conference != NULL);
	purple_debug(PURPLE_DEBUG_INFO, "novell",
			   "In release conference %p, refs=%d\n",
			   conference, conference->ref_count);
	if (--conference->ref_count == 0) {
		purple_debug(PURPLE_DEBUG_INFO, "novell",
				   "Releasing conference %p, total=%d\n",
				   conference, --conf_count);
		if (conference->guid)
			g_free(conference->guid);
		if (conference->participants) {
			for (node = conference->participants; node; node = node->next) {
				if (node->data) {
					NMUserRecord *user_record = node->data;
					nm_release_user_record(user_record);
					node->data = NULL;
				}
			}
			g_slist_free(conference->participants);
		}
		g_free(conference);
	}
}
