static void
resolve_host(PurpleDnsQueryData *query_data)
{
	queued_requests = g_slist_append(queued_requests, query_data);
	handle_next_queued_request();
}
static void
resolve_host(PurpleDnsQueryData *query_data)
{
	GError *err = NULL;
	/*
	 * Spin off a separate thread to perform the DNS lookup so
	 * that we don't block the UI.
	 */
	query_data->resolver = g_thread_create(dns_thread,
			query_data, FALSE, &err);
	if (query_data->resolver == NULL)
	{
		char message[1024];
		g_snprintf(message, sizeof(message), _("Thread creation failure: %s"),
				(err && err->message) ? err->message : _("Unknown reason"));
		g_error_free(err);
		purple_dnsquery_failed(query_data, message);
	}
}
static void
resolve_host(PurpleDnsQueryData *query_data)
{
	struct sockaddr_in sin;
	GSList *hosts = NULL;
	struct hostent *hp;
	gchar *hostname;
#ifdef USE_IDN
	if (!dns_str_is_ascii(query_data->hostname)) {
		int ret = purple_network_convert_idn_to_ascii(query_data->hostname,
				&hostname);
		if (ret != 0) {
			char message[1024];
			g_snprintf(message, sizeof(message), _("Error resolving %s: %d"),
					query_data->hostname, ret);
			purple_dnsquery_failed(query_data, message);
			return;
		}
	} else /* fallthrough is intentional to the g_strdup */
#endif
	hostname = g_strdup(query_data->hostname);
	if(!(hp = gethostbyname(hostname))) {
		char message[1024];
		g_snprintf(message, sizeof(message), _("Error resolving %s: %d"),
				query_data->hostname, h_errno);
		purple_dnsquery_failed(query_data, message);
		g_free(hostname);
		return;
	}
	memset(&sin, 0, sizeof(struct sockaddr_in));
	memcpy(&sin.sin_addr.s_addr, hp->h_addr, hp->h_length);
	sin.sin_family = hp->h_addrtype;
	g_free(hostname);
	sin.sin_port = htons(query_data->port);
	hosts = g_slist_append(hosts, GINT_TO_POINTER(sizeof(sin)));
	hosts = g_slist_append(hosts, g_memdup(&sin, sizeof(sin)));
	purple_dnsquery_resolved(query_data, hosts);
}
