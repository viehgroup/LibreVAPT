}
GList *purple_conversation_get_message_history(PurpleConversation *conv)
{
	return conv->message_history;
}
