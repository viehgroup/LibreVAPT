static void
purple_media_backend_fs2_add_remote_candidates(PurpleMediaBackend *self,
		const gchar *sess_id, const gchar *participant,
		GList *remote_candidates)
{
	PurpleMediaBackendFs2Private *priv;
	PurpleMediaBackendFs2Stream *stream;
	GError *err = NULL;
	g_return_if_fail(PURPLE_IS_MEDIA_BACKEND_FS2(self));
	priv = PURPLE_MEDIA_BACKEND_FS2_GET_PRIVATE(self);
	stream = get_stream(PURPLE_MEDIA_BACKEND_FS2(self),
			sess_id, participant);
	if (stream == NULL) {
		purple_debug_error("backend-fs2",
				"purple_media_add_remote_candidates: "
				"couldn't find stream %s %s.\n",
				sess_id ? sess_id : "(null)",
				participant ? participant : "(null)");
		return;
	}
	stream->remote_candidates = g_list_concat(stream->remote_candidates,
			candidate_list_to_fs(remote_candidates));
	if (purple_media_is_initiator(priv->media, sess_id, participant) ||
			purple_media_accepted(
			priv->media, sess_id, participant)) {
#ifdef HAVE_FARSIGHT
		fs_stream_set_remote_candidates(stream->stream,
				stream->remote_candidates, &err);
#else
		if (stream->supports_add)
			fs_stream_add_remote_candidates(stream->stream,
					stream->remote_candidates, &err);
		else
			fs_stream_force_remote_candidates(stream->stream,
					stream->remote_candidates, &err);
#endif
		if (err) {
			purple_debug_error("backend-fs2", "Error adding remote"
					" candidates: %s\n", err->message);
			g_error_free(err);
		}
	}
}
