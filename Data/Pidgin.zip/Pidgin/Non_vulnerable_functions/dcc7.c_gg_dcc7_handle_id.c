 */
int gg_dcc7_handle_id(struct gg_session *sess, struct gg_event *e, const void *payload, int len)
{
	const struct gg_dcc7_id_reply *p = payload;
	struct gg_dcc7 *tmp;
	gg_debug_session(sess, GG_DEBUG_FUNCTION, "** gg_dcc7_handle_id(%p, %p, %p, %d)\n", sess, e, payload, len);
	for (tmp = sess->dcc7_list; tmp; tmp = tmp->next) {
		gg_debug_session(sess, GG_DEBUG_MISC, "// checking dcc %p, "
			"state %d, type %d\n", tmp, tmp->state, tmp->dcc_type);
		if (tmp->state != GG_STATE_REQUESTING_ID || tmp->dcc_type != (int) gg_fix32(p->type))
			continue;
		tmp->cid = p->id;
		switch (tmp->dcc_type) {
			case GG_DCC7_TYPE_FILE:
			{
				struct gg_dcc7_new s;
				memset(&s, 0, sizeof(s));
				s.id = tmp->cid;
				s.type = gg_fix32(GG_DCC7_TYPE_FILE);
				s.uin_from = gg_fix32(tmp->uin);
				s.uin_to = gg_fix32(tmp->peer_uin);
				s.size = gg_fix32(tmp->size);
				/* Uwaga: To nie jest ciąg kończony zerem.
				 * Note: This is not a null-terminated string. */
				GG_STATIC_ASSERT(
					sizeof(s.filename) == sizeof(tmp->filename) - 1,
					filename_sizes_does_not_match);
				memcpy((char*)s.filename, (char*)tmp->filename, sizeof(s.filename));
				tmp->state = GG_STATE_WAITING_FOR_ACCEPT;
				tmp->timeout = GG_DCC7_TIMEOUT_FILE_ACK;
				return gg_send_packet(sess, GG_DCC7_NEW, &s, sizeof(s), NULL);
			}
		}
	}
	return 0;
}
