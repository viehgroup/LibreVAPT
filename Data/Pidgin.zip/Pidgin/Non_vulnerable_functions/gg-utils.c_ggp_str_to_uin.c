#include "gg-utils.h"
/* uin_t ggp_str_to_uin(const char *str) {{{ */
uin_t ggp_str_to_uin(const char *str)
{
	char *tmp;
	long num;
	if (!str)
		return 0;
	errno = 0;
	num = strtol(str, &tmp, 10);
	if (*str == '\0' || *tmp != '\0')
		return 0;
	if ((errno == ERANGE || (num == LONG_MAX || num == LONG_MIN))
#if (LONG_MAX > UINT_MAX)
	    || num > (long)UINT_MAX
#endif
	    || num < 0)
		return 0;
	return (uin_t) num;
}
/* }}} */
#include "gg-utils.h"
/* uin_t ggp_str_to_uin(const char *str) {{{ */
uin_t ggp_str_to_uin(const char *str)
{
	char *tmp;
	long num;
	if (!str)
		return 0;
	errno = 0;
	num = strtol(str, &tmp, 10);
	if (*str == '\0' || *tmp != '\0')
		return 0;
	if ((errno == ERANGE || (num == LONG_MAX || num == LONG_MIN))
#if (LONG_MAX > UINT_MAX)
	    || num > (long)UINT_MAX
#endif
	    || num < 0)
		return 0;
	return (uin_t) num;
}
/* }}} */
/* uin_t ggp_str_to_uin(const char *str) {{{ */
uin_t ggp_str_to_uin(const char *str)
{
	char *tmp;
	long num;
	if (!str)
		return 0;
	errno = 0;
	num = strtol(str, &tmp, 10);
	if (*str == '\0' || *tmp != '\0')
		return 0;
	if ((errno == ERANGE || (num == LONG_MAX || num == LONG_MIN))
#if (LONG_MAX > UINT_MAX)
	    || num > (long)UINT_MAX
#endif
	    || num < 0)
		return 0;
	return (uin_t) num;
}
