}
static void handle_buzz(JabberMessage *jm) {
	PurpleAccount *account;
	/* Delayed buzz MUST NOT be accepted */
	if(jm->delayed)
		return;
	/* Reject buzz when it's not enabled */
	if(!jm->js->allowBuzz)
		return;
	account = purple_connection_get_account(jm->js->gc);
	if (purple_find_buddy(account, jm->from) == NULL)
		return; /* Do not accept buzzes from unknown people */
	/* xmpp only has 1 attention type, so index is 0 */
	purple_prpl_got_attention(jm->js->gc, jm->from, 0);
}
