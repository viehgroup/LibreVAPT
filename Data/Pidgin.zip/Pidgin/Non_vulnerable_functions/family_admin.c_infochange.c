static void
infochange(OscarData *od, FlapConnection *conn, aim_module_t *mod, FlapFrame *frame, aim_modsnac_t *snac, ByteStream *bs)
{
	aim_rxcallback_t userfunc;
	char *url=NULL, *sn=NULL, *email=NULL;
	guint16 perms, tlvcount, err=0;
	perms = byte_stream_get16(bs);
	tlvcount = byte_stream_get16(bs);
	while (tlvcount && byte_stream_bytes_left(bs)) {
		guint16 type, length;
		type = byte_stream_get16(bs);
		length = byte_stream_get16(bs);
		switch (type) {
			case 0x0001: {
				g_free(sn);
				sn = byte_stream_getstr(bs, length);
			} break;
			case 0x0004: {
				g_free(url);
				url = byte_stream_getstr(bs, length);
			} break;
			case 0x0008: {
				err = byte_stream_get16(bs);
			} break;
			case 0x0011: {
				g_free(email);
				if (length == 0)
					email = g_strdup("*suppressed");
				else
					email = byte_stream_getstr(bs, length);
			} break;
		}
		tlvcount--;
	}
	if ((userfunc = aim_callhandler(od, snac->family, snac->subtype)))
		userfunc(od, conn, frame, (snac->subtype == 0x0005) ? 1 : 0, perms, err, url, sn, email);
	g_free(sn);
	g_free(url);
	g_free(email);
}
