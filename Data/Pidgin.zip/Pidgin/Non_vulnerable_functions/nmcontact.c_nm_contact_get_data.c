gpointer
nm_contact_get_data(NMContact * contact)
{
	if (contact == NULL)
		return NULL;
	return contact->data;
}
