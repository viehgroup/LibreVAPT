static void
jabber_do_uninit(void)
{
	/* reverse order of jabber_do_init */
	jabber_bosh_uninit();
	jabber_data_uninit();
	jabber_si_uninit();
	jabber_ibb_uninit();
	/* PEP things should be uninit via jabber_pep_uninit, not here */
	jabber_pep_uninit();
	jabber_caps_uninit();
	jabber_presence_uninit();
	jabber_iq_uninit();
#ifdef USE_VV
	g_signal_handlers_disconnect_by_func(G_OBJECT(purple_media_manager_get()),
			G_CALLBACK(jabber_caps_broadcast_change), NULL);
#endif
	jabber_auth_uninit();
	jabber_features_destroy();
	jabber_identities_destroy();
	g_hash_table_destroy(jabber_cmds);
	jabber_cmds = NULL;
}
