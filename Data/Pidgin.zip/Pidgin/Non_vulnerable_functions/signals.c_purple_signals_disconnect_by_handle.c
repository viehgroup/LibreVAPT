void
purple_signals_disconnect_by_handle(void *handle)
{
	g_return_if_fail(handle != NULL);
	g_hash_table_foreach(instance_table,
						 (GHFunc)disconnect_handle_from_instance, handle);
}
