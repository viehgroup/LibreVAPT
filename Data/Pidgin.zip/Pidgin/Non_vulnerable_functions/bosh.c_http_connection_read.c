static void
http_connection_read(PurpleHTTPConnection *conn)
{
	char buffer[1025];
	int cnt;
	if (!conn->read_buf)
		conn->read_buf = g_string_new(NULL);
	do {
		if (conn->psc)
			cnt = purple_ssl_read(conn->psc, buffer, sizeof(buffer));
		else
			cnt = read(conn->fd, buffer, sizeof(buffer));
		if (cnt > 0) {
			g_string_append_len(conn->read_buf, buffer, cnt);
		}
	} while (cnt > 0);
	if (cnt == 0 || (cnt < 0 && errno != EAGAIN)) {
		if (cnt < 0)
			purple_debug_info("jabber", "BOSH (%p) read=%d, errno=%d, error=%s\n",
			                  conn, cnt, errno, g_strerror(errno));
		else
			purple_debug_info("jabber", "BOSH server closed the connection (%p)\n",
			                  conn);
		/*
		 * If the socket is closed, the processing really needs to know about
		 * it. Handle that now.
		 */
		http_connection_disconnected(conn);
		/* Process what we do have */
	}
	if (conn->read_buf->len > 0) {
		while (jabber_bosh_http_connection_process(conn));
	}
}
