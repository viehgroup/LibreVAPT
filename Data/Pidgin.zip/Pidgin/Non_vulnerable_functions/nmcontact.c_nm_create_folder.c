NMFolder *
nm_create_folder(const char *name)
{
	NMFolder *folder = g_new0(NMFolder, 1);
	if (name)
		folder->name = g_strdup(name);
	folder->ref_count = 1;
	return folder;
}
