static protobuf_c_boolean
parse_required_member(ScannedMember *scanned_member,
		      void *member,
		      ProtobufCAllocator *allocator,
		      protobuf_c_boolean maybe_clear)
{
	unsigned len = scanned_member->len;
	const uint8_t *data = scanned_member->data;
	ProtobufCWireType wire_type = scanned_member->wire_type;
	switch (scanned_member->field->type) {
	case PROTOBUF_C_TYPE_INT32:
		if (wire_type != PROTOBUF_C_WIRE_TYPE_VARINT)
			return FALSE;
		*(uint32_t *) member = parse_int32(len, data);
		return TRUE;
	case PROTOBUF_C_TYPE_UINT32:
		if (wire_type != PROTOBUF_C_WIRE_TYPE_VARINT)
			return FALSE;
		*(uint32_t *) member = parse_uint32(len, data);
		return TRUE;
	case PROTOBUF_C_TYPE_SINT32:
		if (wire_type != PROTOBUF_C_WIRE_TYPE_VARINT)
			return FALSE;
		*(int32_t *) member = unzigzag32(parse_uint32(len, data));
		return TRUE;
	case PROTOBUF_C_TYPE_SFIXED32:
	case PROTOBUF_C_TYPE_FIXED32:
	case PROTOBUF_C_TYPE_FLOAT:
		if (wire_type != PROTOBUF_C_WIRE_TYPE_32BIT)
			return FALSE;
		*(uint32_t *) member = parse_fixed_uint32(data);
		return TRUE;
	case PROTOBUF_C_TYPE_INT64:
	case PROTOBUF_C_TYPE_UINT64:
		if (wire_type != PROTOBUF_C_WIRE_TYPE_VARINT)
			return FALSE;
		*(uint64_t *) member = parse_uint64(len, data);
		return TRUE;
	case PROTOBUF_C_TYPE_SINT64:
		if (wire_type != PROTOBUF_C_WIRE_TYPE_VARINT)
			return FALSE;
		*(int64_t *) member = unzigzag64(parse_uint64(len, data));
		return TRUE;
	case PROTOBUF_C_TYPE_SFIXED64:
	case PROTOBUF_C_TYPE_FIXED64:
	case PROTOBUF_C_TYPE_DOUBLE:
		if (wire_type != PROTOBUF_C_WIRE_TYPE_64BIT)
			return FALSE;
		*(uint64_t *) member = parse_fixed_uint64(data);
		return TRUE;
	case PROTOBUF_C_TYPE_BOOL:
		*(protobuf_c_boolean *) member = parse_boolean(len, data);
		return TRUE;
	case PROTOBUF_C_TYPE_ENUM:
		if (wire_type != PROTOBUF_C_WIRE_TYPE_VARINT)
			return FALSE;
		*(uint32_t *) member = parse_uint32(len, data);
		return TRUE;
	case PROTOBUF_C_TYPE_STRING: {
		char **pstr = member;
		unsigned pref_len = scanned_member->length_prefix_len;
		if (wire_type != PROTOBUF_C_WIRE_TYPE_LENGTH_PREFIXED)
			return FALSE;
		if (maybe_clear && *pstr != NULL) {
			const char *def = scanned_member->field->default_value;
			if (*pstr != NULL && *pstr != def)
				do_free(allocator, *pstr);
		}
		*pstr = do_alloc(allocator, len - pref_len + 1);
		if (*pstr == NULL)
			return FALSE;
		memcpy(*pstr, data + pref_len, len - pref_len);
		(*pstr)[len - pref_len] = 0;
		return TRUE;
	}
	case PROTOBUF_C_TYPE_BYTES: {
		ProtobufCBinaryData *bd = member;
		const ProtobufCBinaryData *def_bd;
		unsigned pref_len = scanned_member->length_prefix_len;
		if (wire_type != PROTOBUF_C_WIRE_TYPE_LENGTH_PREFIXED)
			return FALSE;
		def_bd = scanned_member->field->default_value;
		if (maybe_clear &&
		    bd->data != NULL &&
		    (def_bd == NULL || bd->data != def_bd->data))
		{
			do_free(allocator, bd->data);
		}
		if (len - pref_len > 0) {
			bd->data = do_alloc(allocator, len - pref_len);
			if (bd->data == NULL)
				return FALSE;
			memcpy(bd->data, data + pref_len, len - pref_len);
		} else {
			bd->data = NULL;
		}
		bd->len = len - pref_len;
		return TRUE;
	}
	case PROTOBUF_C_TYPE_MESSAGE: {
		ProtobufCMessage **pmessage = member;
		ProtobufCMessage *subm;
		const ProtobufCMessage *def_mess;
		protobuf_c_boolean merge_successful = TRUE;
		unsigned pref_len = scanned_member->length_prefix_len;
		if (wire_type != PROTOBUF_C_WIRE_TYPE_LENGTH_PREFIXED)
			return FALSE;
		def_mess = scanned_member->field->default_value;
		subm = protobuf_c_message_unpack(scanned_member->field->descriptor,
						 allocator,
						 len - pref_len,
						 data + pref_len);
		if (maybe_clear &&
		    *pmessage != NULL &&
		    *pmessage != def_mess)
		{
			if (subm != NULL)
				merge_successful = merge_messages(*pmessage, subm, allocator);
			/* Delete the previous message */
			protobuf_c_message_free_unpacked(*pmessage, allocator);
		}
		*pmessage = subm;
		if (subm == NULL || !merge_successful)
			return FALSE;
		return TRUE;
	}
	}
	return FALSE;
}
