static gboolean
plugin_load(PurplePlugin *plugin)
{
	purple_plugin_ipc_register(plugin, "add", PURPLE_CALLBACK(add_func),
							 purple_marshal_INT__INT_INT,
							 purple_value_new(PURPLE_TYPE_INT), 2,
							 purple_value_new(PURPLE_TYPE_INT),
							 purple_value_new(PURPLE_TYPE_INT));
	purple_plugin_ipc_register(plugin, "sub", PURPLE_CALLBACK(sub_func),
							 purple_marshal_INT__INT_INT,
							 purple_value_new(PURPLE_TYPE_INT), 2,
							 purple_value_new(PURPLE_TYPE_INT),
							 purple_value_new(PURPLE_TYPE_INT));
	return TRUE;
}
