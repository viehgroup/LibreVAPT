 */
void jabber_close(PurpleConnection *gc)
{
	JabberStream *js = purple_connection_get_protocol_data(gc);
	/* Close all of the open Jingle sessions on this stream */
	jingle_terminate_sessions(js);
	if (js->bosh)
		jabber_bosh_connection_close(js->bosh);
	else if ((js->gsc && js->gsc->fd > 0) || js->fd > 0)
		jabber_send_raw(js, "</stream:stream>", -1);
	if (js->srv_query_data)
		purple_srv_cancel(js->srv_query_data);
	if(js->gsc) {
		purple_ssl_close(js->gsc);
	} else if (js->fd > 0) {
		if(js->gc->inpa)
			purple_input_remove(js->gc->inpa);
		close(js->fd);
	}
	if (js->bosh)
		jabber_bosh_connection_destroy(js->bosh);
	jabber_buddy_remove_all_pending_buddy_info_requests(js);
	jabber_parser_free(js);
	if(js->iq_callbacks)
		g_hash_table_destroy(js->iq_callbacks);
	if(js->buddies)
		g_hash_table_destroy(js->buddies);
	if(js->chats)
		g_hash_table_destroy(js->chats);
	while(js->chat_servers) {
		g_free(js->chat_servers->data);
		js->chat_servers = g_list_delete_link(js->chat_servers, js->chat_servers);
	}
	while(js->user_directories) {
		g_free(js->user_directories->data);
		js->user_directories = g_list_delete_link(js->user_directories, js->user_directories);
	}
	while(js->bs_proxies) {
		JabberBytestreamsStreamhost *sh = js->bs_proxies->data;
		g_free(sh->jid);
		g_free(sh->host);
		g_free(sh->zeroconf);
		g_free(sh);
		js->bs_proxies = g_list_delete_link(js->bs_proxies, js->bs_proxies);
	}
	while(js->url_datas) {
		purple_util_fetch_url_cancel(js->url_datas->data);
		js->url_datas = g_slist_delete_link(js->url_datas, js->url_datas);
	}
	g_free(js->stream_id);
	if(js->user)
		jabber_id_free(js->user);
	g_free(js->initial_avatar_hash);
	g_free(js->avatar_hash);
	g_free(js->caps_hash);
	if (js->write_buffer)
		purple_circ_buffer_destroy(js->write_buffer);
	if(js->writeh)
		purple_input_remove(js->writeh);
	if (js->auth_mech && js->auth_mech->dispose)
		js->auth_mech->dispose(js);
#ifdef HAVE_CYRUS_SASL
	if(js->sasl)
		sasl_dispose(&js->sasl);
	if(js->sasl_mechs)
		g_string_free(js->sasl_mechs, TRUE);
	g_free(js->sasl_cb);
	/* Note: _not_ g_free.  See auth_cyrus.c:jabber_sasl_cb_secret */
	free(js->sasl_secret);
#endif
	g_free(js->serverFQDN);
	while(js->commands) {
		JabberAdHocCommands *cmd = js->commands->data;
		g_free(cmd->jid);
		g_free(cmd->node);
		g_free(cmd->name);
		g_free(cmd);
		js->commands = g_list_delete_link(js->commands, js->commands);
	}
	g_free(js->server_name);
	g_free(js->certificate_CN);
	g_free(js->gmail_last_time);
	g_free(js->gmail_last_tid);
	g_free(js->old_msg);
	g_free(js->old_avatarhash);
	g_free(js->old_artist);
	g_free(js->old_title);
	g_free(js->old_source);
	g_free(js->old_uri);
	g_free(js->old_track);
	if (js->vcard_timer != 0)
		purple_timeout_remove(js->vcard_timer);
	if (js->keepalive_timeout != 0)
		purple_timeout_remove(js->keepalive_timeout);
	if (js->inactivity_timer != 0)
		purple_timeout_remove(js->inactivity_timer);
	g_free(js->srv_rec);
	js->srv_rec = NULL;
	g_free(js->stun_ip);
	js->stun_ip = NULL;
	/* cancel DNS query for STUN, if one is ongoing */
	if (js->stun_query) {
		purple_dnsquery_destroy(js->stun_query);
		js->stun_query = NULL;
	}
	/* remove Google relay-related stuff */
	g_free(js->google_relay_token);
	g_free(js->google_relay_host);
	if (js->google_relay_requests) {
		while (js->google_relay_requests) {
			PurpleUtilFetchUrlData *url_data =
				(PurpleUtilFetchUrlData *) js->google_relay_requests->data;
			purple_util_fetch_url_cancel(url_data);
			g_free(url_data);
			js->google_relay_requests =
				g_list_delete_link(js->google_relay_requests,
					js->google_relay_requests);
		}
	}
	g_free(js);
	gc->proto_data = NULL;
}
