}
void gnt_slider_set_value(GntSlider *slider, int value)
{
	int old;
	if (slider->current == value)
		return;
	old = slider->current;
	slider->current = value;
	sanitize_value(slider);
	if (old == slider->current)
		return;
	redraw_slider(slider);
	slider_value_changed(slider);
}
