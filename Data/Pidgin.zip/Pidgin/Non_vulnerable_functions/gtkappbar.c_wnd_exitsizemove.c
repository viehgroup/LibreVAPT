}
static GdkFilterReturn wnd_exitsizemove(GtkAppBar *ab, GdkXEvent *xevent) {
        MSG *msg = (MSG*)xevent;
        purple_debug(PURPLE_DEBUG_INFO, "gtkappbar", "wnd_exitsizemove\n");
        if(ab->docking) {
		gtk_appbar_setpos(ab, msg->hwnd);
		ab->docking = FALSE;
		ab->docked = TRUE;
		ShowWindow(msg->hwnd, SW_HIDE);
		set_toolbar(msg->hwnd, TRUE);
		ShowWindow(msg->hwnd, SW_SHOW);
		gtk_appbar_dispatch_dock_cbs(ab, TRUE);
	} else if(ab->undocking) {
		ShowWindow(msg->hwnd, SW_HIDE);
		set_toolbar(msg->hwnd, FALSE);
		ShowWindow(msg->hwnd, SW_SHOW);
		gtk_appbar_dispatch_dock_cbs(ab, FALSE);
		ab->undocking = FALSE;
        }
        return GDK_FILTER_CONTINUE;
}
