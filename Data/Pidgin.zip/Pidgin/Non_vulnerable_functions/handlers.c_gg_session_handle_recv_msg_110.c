}
static int gg_session_handle_recv_msg_110(struct gg_session *gs, uint32_t type,
	const char *ptr, size_t len, struct gg_event *ge)
{
	GG110RecvMessage *msg = gg110_recv_message__unpack(NULL, len, (uint8_t*)ptr);
	uint8_t ack_type;
	uin_t sender = 0;
	uint32_t seq;
	int succ = 1;
	struct gg_event_msg *ev = &ge->event.msg;
	gg_debug_session(gs, GG_DEBUG_FUNCTION,
		"** gg_session_handle_recv_msg_110(%p, %" GG_SIZE_FMT
		", %p);\n", ptr, len, ge);
	if (!GG_PROTOBUF_VALID(gs, "GG110RecvMessage", msg))
		return -1;
	seq = msg->seq;
	if (type == GG_CHAT_RECV_MSG || type == GG_CHAT_RECV_OWN_MSG)
		ack_type = GG110_ACK__TYPE__CHAT;
	else
		ack_type = GG110_ACK__TYPE__MSG;
	if (msg->has_msg_id || msg->has_conv_id) {
		msg->msg_id = msg->has_msg_id ? msg->msg_id : 0;
		msg->conv_id = msg->has_conv_id ? msg->conv_id : 0;
		gg_debug_session(gs, GG_DEBUG_VERBOSE,
			"// gg_session_handle_recv_msg_110() "
			"msg_id=%016" PRIx64 " conv_id=%016" PRIx64 "\n",
			msg->msg_id, msg->conv_id);
	}
	if (msg->has_sender)
		sender = gg_protobuf_get_uin(msg->sender);
	else if (type == GG_CHAT_RECV_OWN_MSG)
		sender = gs->uin;
	if (msg->has_data && msg->msg_plain[0] == '\0') {
		if (msg->data.len < sizeof(struct gg_msg_image_reply)) {
			gg_debug_session(gs, GG_DEBUG_ERROR,
				"// gg_session_handle_recv_msg_110() "
				"packet too small (%" GG_SIZE_FMT " < %"
				GG_SIZE_FMT ")\n", msg->data.len,
				sizeof(struct gg_msg_image_reply));
		} else {
			gg_image_queue_parse(ge, (char *)msg->data.data,
				msg->data.len, gs, sender, type);
		}
		gg110_recv_message__free_unpacked(msg, NULL);
		return gg_ack_110(gs, GG110_ACK__TYPE__MSG, seq, ge);
	}
	if (type == GG_RECV_OWN_MSG110 || type == GG_CHAT_RECV_OWN_MSG)
		ge->type = GG_EVENT_MULTILOGON_MSG;
	else
		ge->type = GG_EVENT_MSG;
	ev->msgclass = GG_CLASS_CHAT;
	ev->seq = seq;
	ev->sender = sender;
	ev->flags = msg->flags;
	ev->seq = seq;
	ev->time = msg->time;
	if (abs(msg->time - gg_server_time(gs)) > 2)
		ev->msgclass |= GG_CLASS_QUEUED;
	ev->message = NULL;
	if (msg->msg_plain[0] != '\0') {
		ev->message = (unsigned char*)gg_encoding_convert(
			msg->msg_plain, GG_ENCODING_UTF8, gs->encoding, -1, -1);
		succ = succ && (ev->message != NULL);
	}
	ev->xhtml_message = NULL;
	if (msg->msg_xhtml != NULL) {
		ev->xhtml_message = gg_encoding_convert(
			msg->msg_xhtml, GG_ENCODING_UTF8, gs->encoding, -1, -1);
		succ = succ && (ev->xhtml_message != NULL);
	}
	/* wiadomości wysłane z mobilnego gg nie posiadają wersji xhtml */
	if (ev->message == NULL && ev->xhtml_message == NULL) {
		ev->message = (unsigned char*)strdup("");
		succ = succ && (ev->message != NULL);
	} else if (ev->message == NULL) {
		ev->message = (unsigned char*)gg_message_html_to_text_110(
			ev->xhtml_message);
		succ = succ && (ev->message != NULL);
	} else if (ev->xhtml_message == NULL) {
		ev->xhtml_message = gg_message_text_to_html_110(
			(char*)ev->message, -1);
		succ = succ && (ev->xhtml_message != NULL);
	}
	/* otrzymywane tylko od gg <= 10.5 */
	ev->formats = NULL;
	ev->formats_length = 0;
	if (msg->has_data && succ) {
		ev->formats_length = msg->data.len;
		ev->formats = malloc(msg->data.len);
		if (ev->formats == NULL)
			succ = 0;
		else
			memcpy(ev->formats, msg->data.data, msg->data.len);
	}
	if (msg->has_chat_id && succ) {
		gg_chat_list_t *chat;
		ev->chat_id = msg->chat_id;
		chat = gg_chat_find(gs, msg->chat_id);
		if (chat) {
			size_t rcpt_size = chat->participants_count *
				sizeof(uin_t);
			ev->recipients = malloc(rcpt_size);
			ev->recipients_count = chat->participants_count;
			if (ev->recipients == NULL)
				succ = 0;
			else {
				memcpy(ev->recipients, chat->participants,
					rcpt_size);
			}
		}
	}
	gg110_recv_message__free_unpacked(msg, NULL);
	if (gg_ack_110(gs, ack_type, seq, ge) != 0)
		succ = 0;
	if (succ)
		return 0;
	else {
		free(ev->message);
		free(ev->xhtml_message);
		free(ev->formats);
		free(ev->recipients);
		return -1;
	}
}
