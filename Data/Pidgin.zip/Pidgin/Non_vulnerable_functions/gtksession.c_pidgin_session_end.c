void
pidgin_session_end()
{
#ifdef USE_SM
	if (session == NULL) /* no session to close */
		return;
	SmcCloseConnection(session, 0, NULL);
	purple_debug(PURPLE_DEBUG_INFO, "Session Management",
			   "Connection closed.\n");
#endif /* USE_SM */
}
