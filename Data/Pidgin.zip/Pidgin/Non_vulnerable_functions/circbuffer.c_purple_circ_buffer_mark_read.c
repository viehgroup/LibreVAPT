}
gboolean purple_circ_buffer_mark_read(PurpleCircBuffer *buf, gsize len) {
	g_return_val_if_fail(buf != NULL, FALSE);
	g_return_val_if_fail(purple_circ_buffer_get_max_read(buf) >= len, FALSE);
	buf->outptr += len;
	buf->bufused -= len;
	/* wrap to the start if we're at the end */
	if ((gsize)(buf->outptr - buf->buffer) == buf->buflen)
		buf->outptr = buf->buffer;
	return TRUE;
}
