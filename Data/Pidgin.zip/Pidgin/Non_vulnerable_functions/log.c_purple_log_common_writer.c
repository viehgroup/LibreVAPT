}
void purple_log_common_writer(PurpleLog *log, const char *ext)
{
	PurpleLogCommonLoggerData *data = log->logger_data;
	if (data == NULL)
	{
		/* This log is new */
		char *dir;
		struct tm *tm;
		const char *tz;
		const char *date;
		char *filename;
		char *path;
		dir = purple_log_get_log_dir(log->type, log->name, log->account);
		if (dir == NULL)
			return;
		purple_build_dir (dir, S_IRUSR | S_IWUSR | S_IXUSR);
		tm = localtime(&log->time);
		tz = purple_escape_filename(purple_utf8_strftime("%Z", tm));
		date = purple_utf8_strftime("%Y-%m-%d.%H%M%S%z", tm);
		filename = g_strdup_printf("%s%s%s", date, tz, ext ? ext : "");
		path = g_build_filename(dir, filename, NULL);
		g_free(dir);
		g_free(filename);
		log->logger_data = data = g_slice_new0(PurpleLogCommonLoggerData);
		data->file = g_fopen(path, "a");
		if (data->file == NULL)
		{
			purple_debug(PURPLE_DEBUG_ERROR, "log",
					"Could not create log file %s\n", path);
			if (log->conv != NULL)
				purple_conversation_write(log->conv, NULL, _("Logging of this conversation failed."),
										PURPLE_MESSAGE_ERROR, time(NULL));
			g_free(path);
			return;
		}
		g_free(path);
	}
}
