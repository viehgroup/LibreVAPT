static char *
get_conversation_title(PurpleConversation *conv, PurpleAccount *account)
{
	return g_strdup_printf(_("%s (%s -- %s)"), purple_conversation_get_title(conv),
		purple_account_get_username(account), purple_account_get_protocol_name(account));
}
