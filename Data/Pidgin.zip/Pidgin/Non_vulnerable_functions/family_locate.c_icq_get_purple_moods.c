PurpleMood*
icq_get_purple_moods(PurpleAccount *account)
{
	return icq_purple_moods;
}
