static void
_sync_privacy_lists(NMUser *user)
{
	GSList *node = NULL, *rem_list = NULL;
	PurpleConnection *gc;
	const char *name, *dn;
	NMUserRecord *user_record;
	if (user == NULL)
		return;
	gc = purple_account_get_connection(user->client_data);
	if (gc == NULL)
		return;
	/* Set the Purple privacy setting */
	if (user->default_deny) {
		if (user->allow_list == NULL) {
			gc->account->perm_deny = PURPLE_PRIVACY_DENY_ALL;
		} else {
			gc->account->perm_deny = PURPLE_PRIVACY_ALLOW_USERS;
		}
	} else {
		if (user->deny_list == NULL) {
			gc->account->perm_deny = PURPLE_PRIVACY_ALLOW_ALL;
		} else {
			gc->account->perm_deny = PURPLE_PRIVACY_DENY_USERS;
		}
	}
	/* Add stuff */
	for (node = user->allow_list; node; node = node->next) {
		user_record = nm_find_user_record(user, (char *)node->data);
		if (user_record)
			name = nm_user_record_get_display_id(user_record);
		else
			name =(char *)node->data;
		if (!g_slist_find_custom(gc->account->permit,
								 name, (GCompareFunc)purple_utf8_strcasecmp)) {
			purple_privacy_permit_add(gc->account, name , TRUE);
		}
	}
	for (node = user->deny_list; node; node = node->next) {
		user_record = nm_find_user_record(user, (char *)node->data);
		if (user_record)
			name = nm_user_record_get_display_id(user_record);
		else
			name =(char *)node->data;
		if (!g_slist_find_custom(gc->account->deny,
								 name, (GCompareFunc)purple_utf8_strcasecmp)) {
			purple_privacy_deny_add(gc->account, name, TRUE);
		}
	}
	/*  Remove stuff */
	for (node = gc->account->permit; node; node = node->next) {
		dn = nm_lookup_dn(user, (char *)node->data);
		if (dn != NULL &&
			!g_slist_find_custom(user->allow_list,
								 dn, (GCompareFunc)purple_utf8_strcasecmp)) {
			rem_list = g_slist_append(rem_list, node->data);
		}
	}
	if (rem_list) {
		for (node = rem_list; node; node = node->next) {
			purple_privacy_permit_remove(gc->account, (char *)node->data, TRUE);
		}
		g_slist_free(rem_list);
		rem_list = NULL;
	}
	for (node = gc->account->deny; node; node = node->next) {
		dn = nm_lookup_dn(user, (char *)node->data);
		if (dn != NULL &&
			!g_slist_find_custom(user->deny_list,
								 dn, (GCompareFunc)purple_utf8_strcasecmp)) {
			rem_list = g_slist_append(rem_list, node->data);
		}
	}
	if (rem_list) {
		for (node = rem_list; node; node = node->next) {
			purple_privacy_deny_remove(gc->account, (char *)node->data, TRUE);
		}
		g_slist_free(rem_list);
	}
}
