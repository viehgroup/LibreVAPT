GSList *
purple_certificates_import(PurpleCertificateScheme *scheme, const gchar *filename)
{
	g_return_val_if_fail(scheme, NULL);
	g_return_val_if_fail(scheme->import_certificates, NULL);
	g_return_val_if_fail(filename, NULL);
	return (scheme->import_certificates)(filename);
}
