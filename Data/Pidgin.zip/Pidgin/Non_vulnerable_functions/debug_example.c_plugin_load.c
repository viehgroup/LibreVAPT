static gboolean
plugin_load(PurplePlugin *plugin)
{
	/* Define these for convenience--we're just using them to show the
	 * similarities of the debug functions to the standard printf(). */
	gint i = 256;
	gfloat f = 512.1024;
	const gchar *s = "example string";
	/* Introductory message */
	purple_debug_info(PLUGIN_ID,
		"Called plugin_load.  Beginning debug demonstration\n");
	/* Show off the debug API a bit */
	purple_debug_misc(PLUGIN_ID,
		"MISC level debug message.  i = %d, f = %f, s = %s\n", i, f, s);
	purple_debug_info(PLUGIN_ID,
		"INFO level debug message.  i = %d, f = %f, s = %s\n", i, f, s);
	purple_debug_warning(PLUGIN_ID,
		"WARNING level debug message.  i = %d, f = %f, s = %s\n", i, f, s);
	purple_debug_error(PLUGIN_ID,
		"ERROR level debug message.  i = %d, f = %f, s = %s\n", i, f, s);
	purple_debug_fatal(PLUGIN_ID,
		"FATAL level debug message. i = %d, f = %f, s = %s\n", i, f, s);
	/* Now just return TRUE to tell libpurple to finish loading. */
	return TRUE;
}
