void
purple_account_disconnect(PurpleAccount *account)
{
	PurpleConnection *gc;
	const char *username;
	g_return_if_fail(account != NULL);
	g_return_if_fail(!purple_account_is_disconnected(account));
	username = purple_account_get_username(account);
	purple_debug_info("account", "Disconnecting account %s (%p)\n",
	                  username ? username : "(null)", account);
	account->disconnecting = TRUE;
	gc = purple_account_get_connection(account);
	_purple_connection_destroy(gc);
	if (!purple_account_get_remember_password(account))
		purple_account_set_password(account, NULL);
	purple_account_set_connection(account, NULL);
	account->disconnecting = FALSE;
}
