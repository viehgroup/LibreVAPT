}
static void pidgin_menu_deactivate(GtkWidget *menu, GtkToggleButton *button)
{
	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(button), FALSE);
}
