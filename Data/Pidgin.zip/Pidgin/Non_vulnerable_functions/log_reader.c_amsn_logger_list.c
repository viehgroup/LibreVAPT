/* `log_dir`/username@hotmail.com/logs/Month Year/buddyname@hotmail.com.log */
static GList *amsn_logger_list(PurpleLogType type, const char *sn, PurpleAccount *account)
{
	GList *list = NULL;
	const char *logdir;
	char *username;
	char *log_path;
	char *buddy_log;
	char *filename;
	GDir *dir;
	const char *name;
	logdir = purple_prefs_get_string("/plugins/core/log_reader/amsn/log_directory");
	/* By clearing the log directory path, this logger can be (effectively) disabled. */
	if (!logdir || !*logdir)
		return NULL;
	/* aMSN only works with MSN/WLM */
	if (strcmp(account->protocol_id, "prpl-msn"))
		return NULL;
	username = g_strdup(purple_normalize(account, account->username));
	buddy_log = g_strdup_printf("%s.log", purple_normalize(account, sn));
	log_path = g_build_filename(logdir, username, "logs", NULL);
	/* First check in the top-level */
	filename = g_build_filename(log_path, buddy_log, NULL);
	if (g_file_test(filename, G_FILE_TEST_EXISTS))
		list = amsn_logger_parse_file(filename, sn, account);
	else
		g_free(filename);
	/* Check in previous months */
	dir = g_dir_open(log_path, 0, NULL);
	if (dir) {
		while ((name = g_dir_read_name(dir)) != NULL) {
			filename = g_build_filename(log_path, name, buddy_log, NULL);
			if (g_file_test(filename, G_FILE_TEST_EXISTS))
				list = g_list_concat(list, amsn_logger_parse_file(filename, sn, account));
			g_free(filename);
		}
		g_dir_close(dir);
	}
	g_free(log_path);
	/* New versions use 'friendlier' directory names */
	purple_util_chrreplace(username, '@', '_');
	purple_util_chrreplace(username, '.', '_');
	log_path = g_build_filename(logdir, username, "logs", NULL);
	/* First check in the top-level */
	filename = g_build_filename(log_path, buddy_log, NULL);
	if (g_file_test(filename, G_FILE_TEST_EXISTS))
		list = g_list_concat(list, amsn_logger_parse_file(filename, sn, account));
	g_free(filename);
	/* Check in previous months */
	dir = g_dir_open(log_path, 0, NULL);
	if (dir) {
		while ((name = g_dir_read_name(dir)) != NULL) {
			filename = g_build_filename(log_path, name, buddy_log, NULL);
			if (g_file_test(filename, G_FILE_TEST_EXISTS))
				list = g_list_concat(list, amsn_logger_parse_file(filename, sn, account));
			g_free(filename);
		}
		g_dir_close(dir);
	}
	g_free(log_path);
	g_free(username);
	g_free(buddy_log);
	return list;
}
