gboolean
purple_privacy_permit_add(PurpleAccount *account, const char *who,
						gboolean local_only)
{
	GSList *l;
	char *name;
	PurpleBuddy *buddy;
	PurpleBlistUiOps *blist_ops;
	g_return_val_if_fail(account != NULL, FALSE);
	g_return_val_if_fail(who     != NULL, FALSE);
	name = g_strdup(purple_normalize(account, who));
	for (l = account->permit; l != NULL; l = l->next) {
		if (g_str_equal(name, l->data))
			/* This buddy already exists */
			break;
	}
	if (l != NULL)
	{
		/* This buddy already exists, so bail out */
		g_free(name);
		return FALSE;
	}
	account->permit = g_slist_append(account->permit, name);
	if (!local_only && purple_account_is_connected(account))
		serv_add_permit(purple_account_get_connection(account), who);
	if (privacy_ops != NULL && privacy_ops->permit_added != NULL)
		privacy_ops->permit_added(account, who);
	blist_ops = purple_blist_get_ui_ops();
	if (blist_ops != NULL && blist_ops->save_account != NULL)
		blist_ops->save_account(account);
	/* This lets the UI know a buddy has had its privacy setting changed */
	buddy = purple_find_buddy(account, name);
	if (buddy != NULL) {
		purple_signal_emit(purple_blist_get_handle(),
                "buddy-privacy-changed", buddy);
	}
	return TRUE;
}
