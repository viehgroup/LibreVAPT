static void
global_buddyicon_changed(const char *name, PurplePrefType type,
			gconstpointer value, gpointer window)
{
	GList *list;
	for (list = purple_accounts_get_all(); list; list = list->next) {
		account_modified_cb(list->data, window);
	}
}
