/* GGPSearchForm *ggp_search_get(GGPSearches *searches, seq) {{{ */
GGPSearchForm *ggp_search_get(GGPSearches *searches, guint32 seq)
{
	g_return_val_if_fail(searches != NULL, NULL);
	return g_hash_table_lookup(searches, &seq);
}
