}
void jabber_keepalive_ping(JabberStream *js)
{
	JabberIq *iq;
	xmlnode *ping;
	iq = jabber_iq_new(js, JABBER_IQ_GET);
	ping = xmlnode_new_child(iq->node, "ping");
	xmlnode_set_namespace(ping, NS_PING);
	jabber_iq_set_callback(iq, jabber_keepalive_pong_cb, NULL);
	jabber_iq_send(iq);
}
