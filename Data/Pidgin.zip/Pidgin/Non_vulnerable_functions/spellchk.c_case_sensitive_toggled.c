}
static void case_sensitive_toggled(GtkCellRendererToggle *cellrenderertoggle,
						gchar *path, gpointer data){
	GtkTreeIter iter;
	gboolean enabled;
	g_return_if_fail(gtk_tree_model_get_iter_from_string(GTK_TREE_MODEL(model), &iter, path));
	/* Prevent the case sensitive column from changing on non-whole word replacements.
	 * Ideally, the column would be set insensitive in the word_only_toggled callback. */
	gtk_tree_model_get(GTK_TREE_MODEL(model), &iter,
					   WORD_ONLY_COLUMN, &enabled,
					   -1);
	if (!enabled)
		return;
	gtk_tree_model_get(GTK_TREE_MODEL(model), &iter,
					   CASE_SENSITIVE_COLUMN, &enabled,
					   -1);
	gtk_list_store_set(GTK_LIST_STORE(model), &iter,
					   CASE_SENSITIVE_COLUMN, !enabled,
					   -1);
	save_list();
}
