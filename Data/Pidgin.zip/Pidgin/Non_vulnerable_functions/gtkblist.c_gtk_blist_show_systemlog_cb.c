}
static void gtk_blist_show_systemlog_cb(void)
{
	pidgin_syslog_show();
}
