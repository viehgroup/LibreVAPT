static void
free_pounce(PurplePounce *pounce)
{
	update_pounces();
}
