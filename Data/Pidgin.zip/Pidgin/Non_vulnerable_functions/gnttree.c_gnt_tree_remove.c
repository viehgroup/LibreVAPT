}
void gnt_tree_remove(GntTree *tree, gpointer key)
{
	GntTreeRow *row = g_hash_table_lookup(tree->hash, key);
	static int depth = 0; /* Only redraw after all child nodes are removed */
	if (row)
	{
		gboolean redraw = FALSE;
		if (row->child) {
			depth++;
			while (row->child) {
				gnt_tree_remove(tree, row->child->key);
			}
			depth--;
		}
		if (get_distance(tree->top, row) >= 0 && get_distance(row, tree->bottom) >= 0)
			redraw = TRUE;
		/* Update root/top/current/bottom if necessary */
		if (tree->root == row)
			tree->root = get_next(row);
		if (tree->top == row)
		{
			if (tree->top != tree->root)
				tree->top = get_prev(row);
			else
				tree->top = get_next(row);
		}
		if (tree->current == row)
		{
			if (tree->current != tree->root)
				tree->current = get_prev(row);
			else
				tree->current = get_next(row);
			tree_selection_changed(tree, row, tree->current);
		}
		if (tree->bottom == row)
		{
			tree->bottom = get_prev(row);
		}
		/* Fix the links */
		if (row->next)
			row->next->prev = row->prev;
		if (row->parent && row->parent->child == row)
			row->parent->child = row->next;
		if (row->prev)
			row->prev->next = row->next;
		g_hash_table_remove(tree->hash, key);
		tree->list = g_list_remove(tree->list, key);
		if (redraw && depth == 0)
		{
			redraw_tree(tree);
		}
	}
}
