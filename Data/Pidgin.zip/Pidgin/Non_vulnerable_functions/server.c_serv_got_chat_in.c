}
void serv_got_chat_in(PurpleConnection *g, int id, const char *who,
					  PurpleMessageFlags flags, const char *message, time_t mtime)
{
	GSList *bcs;
	PurpleConversation *conv = NULL;
	PurpleConvChat *chat = NULL;
	char *buffy, *angel;
	int plugin_return;
	g_return_if_fail(who != NULL);
	g_return_if_fail(message != NULL);
	if (mtime < 0) {
		purple_debug_error("server",
				"serv_got_chat_in ignoring negative timestamp\n");
		/* TODO: Would be more appropriate to use a value that indicates
		   that the timestamp is unknown, and surface that in the UI. */
		mtime = time(NULL);
	}
	for (bcs = g->buddy_chats; bcs != NULL; bcs = bcs->next) {
		conv = (PurpleConversation *)bcs->data;
		chat = PURPLE_CONV_CHAT(conv);
		if (purple_conv_chat_get_id(chat) == id)
			break;
		conv = NULL;
	}
	if (!conv)
		return;
	/* Did I send the message? */
	if (purple_strequal(purple_conv_chat_get_nick(chat),
				purple_normalize(purple_conversation_get_account(conv), who))) {
		flags |= PURPLE_MESSAGE_SEND;
		flags &= ~PURPLE_MESSAGE_RECV; /* Just in case some prpl sets it! */
	} else {
		flags |= PURPLE_MESSAGE_RECV;
	}
	/*
	 * Make copies of the message and the sender in case plugins want
	 * to free these strings and replace them with a modifed version.
	 */
	buffy = g_strdup(message);
	angel = g_strdup(who);
	plugin_return = GPOINTER_TO_INT(
		purple_signal_emit_return_1(purple_conversations_get_handle(),
								  "receiving-chat-msg", g->account,
								  &angel, &buffy, conv, &flags));
	if (!buffy || !angel || plugin_return) {
		g_free(buffy);
		g_free(angel);
		return;
	}
	who = angel;
	message = buffy;
	purple_signal_emit(purple_conversations_get_handle(), "received-chat-msg", g->account,
					 who, message, conv, flags);
	purple_conv_chat_write(chat, who, message, flags, mtime);
	g_free(angel);
	g_free(buffy);
}
