void
purple_prefs_add_string(const char *name, const char *value)
{
	struct purple_pref *pref;
	if(value != NULL && !g_utf8_validate(value, -1, NULL)) {
		purple_debug_error("prefs", "purple_prefs_add_string: Cannot store invalid UTF8 for string pref %s\n", name);
		return;
	}
	PURPLE_PREFS_UI_OP_CALL(add_string, name, value);
	pref = add_pref(PURPLE_PREF_STRING, name);
	if(!pref)
		return;
	pref->value.string = g_strdup(value);
}
