}
char *purple_buddy_icon_get_full_path(PurpleBuddyIcon *icon)
{
	char *path;
	g_return_val_if_fail(icon != NULL, NULL);
	if (icon->img == NULL)
		return NULL;
	path = g_build_filename(purple_buddy_icons_get_cache_dir(),
	                        purple_imgstore_get_filename(icon->img), NULL);
	if (!g_file_test(path, G_FILE_TEST_EXISTS))
	{
		g_free(path);
		return NULL;
	}
	return path;
}
