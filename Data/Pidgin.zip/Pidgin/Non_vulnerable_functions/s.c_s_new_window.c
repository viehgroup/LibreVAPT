static void
s_new_window(GntWM *wm, GntWidget *win)
{
	int x, y, w, h;
	int maxx, maxy;
	const char *name;
	gboolean blist = FALSE;
	if (!GNT_IS_MENU(win)) {
		getmaxyx(stdscr, maxy, maxx);
		gnt_widget_get_position(win, &x, &y);
		gnt_widget_get_size(win, &w, &h);
		name = gnt_widget_get_name(win);
		if (name && strcmp(name, "buddylist") == 0) {
			/* The buddylist doesn't have no border nor nothing! */
			x = 0;
			y = 0;
			h = maxy - 1;
			blist = TRUE;
			gnt_box_set_toplevel(GNT_BOX(win), FALSE);
			GNT_WIDGET_SET_FLAGS(win, GNT_WIDGET_CAN_TAKE_FOCUS);
			gnt_widget_set_position(win, x, y);
			mvwin(win->window, y, x);
			gnt_widget_set_size(win, -1, h + 2);  /* XXX: Why is the +2 needed here? -- sadrul */
		} else if (!GNT_WIDGET_IS_FLAG_SET(win, GNT_WIDGET_TRANSIENT)) {
			const char *title = GNT_BOX(win)->title;
			if (title == NULL || !g_hash_table_lookup(wm->positions, title)) {
				/* In the middle of the screen */
				x = (maxx - w) / 2;
				y = (maxy - h) / 2;
				gnt_widget_set_position(win, x, y);
				mvwin(win->window, y, x);
			}
		}
	}
	org_new_window(wm, win);
	if (blist)
		gnt_wm_raise_window(wm, win);
}
