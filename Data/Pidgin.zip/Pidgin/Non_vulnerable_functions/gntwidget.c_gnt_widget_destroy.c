void
gnt_widget_destroy(GntWidget *obj)
{
	g_return_if_fail(GNT_IS_WIDGET(obj));
	if(!(GNT_WIDGET_FLAGS(obj) & GNT_WIDGET_DESTROYING)) {
		GNT_WIDGET_SET_FLAGS(obj, GNT_WIDGET_DESTROYING);
		gnt_widget_hide(obj);
		delwin(obj->window);
		g_object_run_dispose(G_OBJECT(obj));
	}
	GNTDEBUG;
}
