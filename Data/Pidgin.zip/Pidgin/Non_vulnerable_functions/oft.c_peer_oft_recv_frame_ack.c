static void
peer_oft_recv_frame_ack(PeerConnection *conn, OftFrame *frame)
{
	if (memcmp(conn->cookie, frame->cookie, 8) != 0)
	{
		purple_debug_info("oscar", "Received an incorrect cookie.  "
				"Closing connection.\n");
		peer_connection_destroy(conn, OSCAR_DISCONNECT_INVALID_DATA, NULL);
		return;
	}
	/* Remove our watchers and use the file transfer watchers in the core */
	purple_input_remove(conn->watcher_incoming);
	conn->watcher_incoming = 0;
	conn->sending_data_timer = purple_timeout_add(100,
			start_transfer_when_done_sending_data, conn);
}
