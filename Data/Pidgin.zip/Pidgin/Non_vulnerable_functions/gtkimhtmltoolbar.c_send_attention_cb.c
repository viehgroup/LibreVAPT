}
static void send_attention_cb(GtkWidget *attention, GtkIMHtmlToolbar *toolbar)
{
	PurpleConversation *conv =
		g_object_get_data(G_OBJECT(toolbar), "active_conv");
	const gchar *who = purple_conversation_get_name(conv);
	PurpleConnection *gc = purple_conversation_get_gc(conv);
	toggle_button_set_active_block(GTK_TOGGLE_BUTTON(attention), FALSE, toolbar);
	purple_prpl_send_attention(gc, who, 0);
	gtk_widget_grab_focus(toolbar->imhtml);
}
