GList *
purple_prefs_get_path_list(const char *name)
{
	struct purple_pref *pref;
	GList *ret = NULL, *tmp;
	PURPLE_PREFS_UI_OP_CALL_RETURN(get_string_list, name);
	pref = find_pref(name);
	if(!pref) {
		purple_debug_error("prefs",
				"purple_prefs_get_path_list: Unknown pref %s\n", name);
		return NULL;
	} else if(pref->type != PURPLE_PREF_PATH_LIST) {
		purple_debug_error("prefs",
				"purple_prefs_get_path_list: %s not a path list pref\n", name);
		return NULL;
	}
	for(tmp = pref->value.stringlist; tmp; tmp = tmp->next)
		ret = g_list_prepend(ret, g_strdup(tmp->data));
	ret = g_list_reverse(ret);
	return ret;
}
