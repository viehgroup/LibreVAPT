static void
purple_media_backend_fs2_set_params(PurpleMediaBackend *self,
		guint num_params, GParameter *params)
{
	PurpleMediaBackendFs2Private *priv;
	guint i;
#ifndef HAVE_FARSIGHT
	GstStructure *sdes;
#endif
	g_return_if_fail(PURPLE_IS_MEDIA_BACKEND_FS2(self));
	priv = PURPLE_MEDIA_BACKEND_FS2_GET_PRIVATE(self);
	if (priv->conference == NULL &&
		!init_conference(PURPLE_MEDIA_BACKEND_FS2(self))) {
		purple_debug_error("backend-fs2",
				"Error initializing the conference.\n");
		return;
	}
#ifdef HAVE_FARSIGHT
	for (i = 0; i != num_params; ++i) {
		if (param_to_sdes_type(params[i].name)) {
			g_object_set(priv->conference,
			             params[i].name, g_value_get_string(&params[i].value),
			             NULL);
		}
	}
#else
	g_object_get(G_OBJECT(priv->conference), "sdes", &sdes, NULL);
	for (i = 0; i != num_params; ++i) {
		const gchar *sdes_type = param_to_sdes_type(params[i].name);
		if (!sdes_type)
			continue;
		gst_structure_set(sdes, sdes_type,
		                  G_TYPE_STRING, g_value_get_string(&params[i].value),
		                  NULL);
	}
	g_object_set(G_OBJECT(priv->conference), "sdes", sdes, NULL);
	gst_structure_free(sdes);
#endif /* HAVE_FARSIGHT */
}
