 */
gboolean bonjour_dns_sd_start(BonjourDnsSd *data) {
	/* Initialize the dns-sd data and session */
	if (!_mdns_init_session(data))
		return FALSE;
	/* Publish our bonjour IM client at the mDNS daemon */
	if (!publish_presence(data, PUBLISH_START))
		return FALSE;
	/* Advise the daemon that we are waiting for connections */
	if (!_mdns_browse(data)) {
		purple_debug_error("bonjour", "Unable to get service.\n");
		return FALSE;
	}
	return TRUE;
}
