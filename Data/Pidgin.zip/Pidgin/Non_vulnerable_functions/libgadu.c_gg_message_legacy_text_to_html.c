static char *
gg_message_legacy_text_to_html(const char *src, gg_encoding_t encoding,
	const unsigned char *format, size_t format_len)
{
	size_t len;
	char *dst;
	if (format == NULL || format_len <= 3) {
		format = NULL;
		format_len = 0;
	} else {
		format += 3;
		format_len -= 3;
	}
	len = gg_message_text_to_html(NULL, src, encoding, format, format_len);
	dst = malloc(len + 1);
	if (dst == NULL)
		return NULL;
	gg_message_text_to_html(dst, src, encoding, format, format_len);
	return dst;
}
