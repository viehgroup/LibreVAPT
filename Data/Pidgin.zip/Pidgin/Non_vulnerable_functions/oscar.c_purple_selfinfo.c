}
static int purple_selfinfo(OscarData *od, FlapConnection *conn, FlapFrame *fr, ...) {
	va_list ap;
	aim_userinfo_t *info;
	va_start(ap, fr);
	info = va_arg(ap, aim_userinfo_t *);
	va_end(ap);
	purple_connection_set_display_name(od->gc, info->bn);
	return 1;
}
