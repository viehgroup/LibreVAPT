/* Purple plugin specific code */
static gboolean plugin_load(PurplePlugin *plugin) {
	_plugin_pointer = plugin;
	_signals_connected = FALSE;
	/* buddy_stats is a hashtable where strings are keys
	 * and the keys are a buddies account id (PurpleBuddy.name).
	 * keys/values are automatically deleted */
	_buddy_stats = g_hash_table_new_full(g_str_hash, g_str_equal, g_free, destroy_stats);
	/* ? - Can't remember at the moment
	 */
	_my_offline_times = g_hash_table_new_full(g_str_hash, g_str_equal, g_free, g_free);
	if(create_database_connection()) {
		add_plugin_functionality(plugin);
	}
	return TRUE;
}
