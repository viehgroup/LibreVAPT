static void
peer_connection_common_established_cb(gpointer data, gint source, const gchar *error_message, gboolean verified)
{
	PeerConnection *conn;
	conn = data;
	if (verified)
		conn->verified_connect_data = NULL;
	else
		conn->client_connect_data = NULL;
	if (source < 0)
	{
		if ((conn->verified_connect_data == NULL) &&
			(conn->client_connect_data == NULL))
		{
			/* Our parallel connection attemps have both failed. */
			peer_connection_trynext(conn);
		}
		return;
	}
	purple_timeout_remove(conn->connect_timeout_timer);
	conn->connect_timeout_timer = 0;
	if (conn->client_connect_data != NULL)
	{
		purple_proxy_connect_cancel(conn->client_connect_data);
		conn->client_connect_data = NULL;
	}
	if (conn->verified_connect_data != NULL)
	{
		purple_proxy_connect_cancel(conn->verified_connect_data);
		conn->verified_connect_data = NULL;
	}
	conn->fd = source;
	peer_connection_finalize_connection(conn);
}
