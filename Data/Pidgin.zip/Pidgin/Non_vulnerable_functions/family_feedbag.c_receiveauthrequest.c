 */
static int receiveauthrequest(OscarData *od, FlapConnection *conn, aim_module_t *mod, FlapFrame *frame, aim_modsnac_t *snac, ByteStream *bs)
{
	int ret = 0;
	aim_rxcallback_t userfunc;
	guint16 tmp;
	char *bn, *msg, *tmpstr;
	/* Read buddy name */
	tmp = byte_stream_get8(bs);
	if (!tmp) {
		purple_debug_warning("oscar", "Dropping auth request SNAC "
				"because username was empty\n");
		return 0;
	}
	bn = byte_stream_getstr(bs, tmp);
	if (!g_utf8_validate(bn, -1, NULL)) {
		purple_debug_warning("oscar", "Dropping auth request SNAC "
				"because the username was not valid UTF-8\n");
		g_free(bn);
	}
	/* Read message */
	tmp = byte_stream_get16(bs);
	if (tmp) {
		msg = byte_stream_getstr(bs, tmp);
		if (!g_utf8_validate(msg, -1, NULL)) {
			/* Ugh, msg isn't UTF8.  Let's salvage. */
			purple_debug_warning("oscar", "Got non-UTF8 message in auth "
					"request from %s\n", bn);
			tmpstr = purple_utf8_salvage(msg);
			g_free(msg);
			msg = tmpstr;
		}
	} else
		msg = NULL;
	/* Unknown */
	tmp = byte_stream_get16(bs);
	if ((userfunc = aim_callhandler(od, snac->family, snac->subtype)))
		ret = userfunc(od, conn, frame, bn, msg);
	g_free(bn);
	g_free(msg);
	return ret;
}
