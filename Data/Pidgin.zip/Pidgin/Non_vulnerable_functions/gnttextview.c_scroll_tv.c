static gboolean
scroll_tv(GntWidget *wid, const char *key, GntTextView *tv)
{
	if (strcmp(key, GNT_KEY_PGUP) == 0) {
		gnt_text_view_scroll(tv, -(GNT_WIDGET(tv)->priv.height - 2));
	} else if (strcmp(key, GNT_KEY_PGDOWN) == 0) {
		gnt_text_view_scroll(tv, GNT_WIDGET(tv)->priv.height - 2);
	} else if (strcmp(key, GNT_KEY_DOWN) == 0) {
		gnt_text_view_scroll(tv, 1);
	} else if (strcmp(key, GNT_KEY_UP) == 0) {
		gnt_text_view_scroll(tv, -1);
	} else {
		return FALSE;
	}
	return TRUE;
}
