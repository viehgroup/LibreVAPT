PidginThemeFont *
pidgin_blist_theme_get_online_text_info(PidginBlistTheme *theme)
{
	PidginBlistThemePrivate *priv;
	g_return_val_if_fail(PIDGIN_IS_BLIST_THEME(theme), NULL);
	priv = PIDGIN_BLIST_THEME_GET_PRIVATE(G_OBJECT(theme));
	return priv->online;
}
