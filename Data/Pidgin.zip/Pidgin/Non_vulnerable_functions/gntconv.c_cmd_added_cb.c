static void
cmd_added_cb(const char *cmd, PurpleCmdPriority prior, PurpleCmdFlag flags,
		FinchConv *fconv)
{
	gg_setup_commands(fconv, TRUE);
}
