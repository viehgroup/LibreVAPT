GType
gnt_widget_get_gtype(void)
{
	static GType type = 0;
	if(type == 0) {
		static const GTypeInfo info = {
			sizeof(GntWidgetClass),
			NULL,					/* base_init		*/
			NULL,					/* base_finalize	*/
			(GClassInitFunc)gnt_widget_class_init,
			NULL,
			NULL,					/* class_data		*/
			sizeof(GntWidget),
			0,						/* n_preallocs		*/
			gnt_widget_init,					/* instance_init	*/
			NULL					/* value_table		*/
		};
		type = g_type_register_static(GNT_TYPE_BINDABLE,
									  "GntWidget",
									  &info, G_TYPE_FLAG_ABSTRACT);
	}
	return type;
}
