const char *
nm_contact_get_display_name(NMContact * contact)
{
	if (contact == NULL)
		return NULL;
	if (contact->user_record != NULL && contact->display_name == NULL) {
		const char *full_name, *lname, *fname, *cn, *display_id;
		full_name = nm_user_record_get_full_name(contact->user_record);
		fname = nm_user_record_get_first_name(contact->user_record);
		lname = nm_user_record_get_last_name(contact->user_record);
		cn = nm_user_record_get_userid(contact->user_record);
		display_id = nm_user_record_get_display_id(contact->user_record);
		/* Try to build a display name. */
		if (full_name) {
			contact->display_name = g_strdup(full_name);
		} else if (fname && lname) {
			contact->display_name = g_strdup_printf("%s %s", fname, lname);
		} else {
			/* If auth attribute is set use it */
			if (nm_user_record_get_auth_attr(contact->user_record) &&
				display_id != NULL)	{
				contact->display_name = g_strdup(display_id);
			} else {
				/* Use CN or display id */
				if (cn) {
					contact->display_name = g_strdup(cn);
				} else if (display_id) {
					contact->display_name = g_strdup(display_id);
				}
			}
		}
	}
	return contact->display_name;
}
