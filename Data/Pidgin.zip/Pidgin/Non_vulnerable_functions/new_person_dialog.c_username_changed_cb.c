static void
username_changed_cb(GtkEntry *entry, GevoNewPersonDialog *dialog)
{
	gtk_widget_set_sensitive(dialog->add_button,
							 *gtk_entry_get_text(entry) != '\0');
}
