}
void gnt_menuitem_set_trigger(GntMenuItem *item, char trigger)
{
	item->priv.trigger = trigger;
}
