 */
IcbmCookie *aim_uncachecookie(OscarData *od, guint8 *cookie, int type)
{
	IcbmCookie *cur, **prev;
	if (!cookie || !od->msgcookies)
		return NULL;
	for (prev = &od->msgcookies; (cur = *prev); ) {
		if ((cur->type == type) &&
				(memcmp(cur->cookie, cookie, 8) == 0)) {
			*prev = cur->next;
			return cur;
		}
		prev = &cur->next;
	}
	return NULL;
}
