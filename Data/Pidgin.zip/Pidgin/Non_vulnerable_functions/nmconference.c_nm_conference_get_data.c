gpointer
nm_conference_get_data(NMConference * conference)
{
	if (conference == NULL)
		return NULL;
	return conference->data;
}
