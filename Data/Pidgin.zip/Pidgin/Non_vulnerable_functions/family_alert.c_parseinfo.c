static int
parseinfo(OscarData *od, FlapConnection *conn, aim_module_t *mod, FlapFrame *frame, aim_modsnac_t *snac, ByteStream *bs)
{
	int ret = 0;
	aim_rxcallback_t userfunc;
	struct aim_emailinfo *new;
	GSList *tlvlist;
	guint8 *cookie8, *cookie16;
	int tmp, havenewmail = 0; /* Used to tell the client we have _new_ mail */
	char *alertitle = NULL, *alerturl = NULL;
	cookie8 = byte_stream_getraw(bs, 8); /* Possibly the code used to log you in to mail? */
	cookie16 = byte_stream_getraw(bs, 16); /* Mail cookie sent above */
	/* See if we already have some info associated with this cookie */
	for (new = od->emailinfo; (new && memcmp(cookie16, new->cookie16, 16)); new = new->next);
	if (new) {
		/* Free some of the old info, if it exists */
		g_free(new->cookie8);
		g_free(new->cookie16);
		g_free(new->url);
		g_free(new->domain);
	} else {
		/* We don't already have info, so create a new struct for it */
		new = g_new0(struct aim_emailinfo, 1);
		new->next = od->emailinfo;
		od->emailinfo = new;
	}
	new->cookie8 = cookie8;
	new->cookie16 = cookie16;
	tlvlist = aim_tlvlist_readnum(bs, byte_stream_get16(bs));
	tmp = aim_tlv_get16(tlvlist, 0x0080, 1);
	if (tmp) {
		if (new->nummsgs < tmp)
			havenewmail = 1;
		new->nummsgs = tmp;
	} else {
		/* If they don't send a 0x0080 TLV, it means we definitely have new mail */
		/* (ie. this is not just another status update) */
		havenewmail = 1;
		new->nummsgs++; /* We know we have at least 1 new email */
	}
	new->url = aim_tlv_getstr(tlvlist, 0x0007, 1);
	if (!(new->unread = aim_tlv_get8(tlvlist, 0x0081, 1))) {
		havenewmail = 0;
		new->nummsgs = 0;
	}
	new->domain = aim_tlv_getstr(tlvlist, 0x0082, 1);
	new->flag = aim_tlv_get16(tlvlist, 0x0084, 1);
	alertitle = aim_tlv_getstr(tlvlist, 0x0005, 1);
	alerturl  = aim_tlv_getstr(tlvlist, 0x000d, 1);
	if ((userfunc = aim_callhandler(od, snac->family, snac->subtype)))
		ret = userfunc(od, conn, frame, new, havenewmail, alertitle, (alerturl ? alerturl + 2 : NULL));
	aim_tlvlist_free(tlvlist);
	g_free(alertitle);
	g_free(alerturl);
	return ret;
}
