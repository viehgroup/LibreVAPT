static void
gnt_file_sel_size_request(GntWidget *widget)
{
	GntFileSel *sel;
	if (widget->priv.height > 0)
		return;
	sel = GNT_FILE_SEL(widget);
	sel->dirs->priv.height = 16;
	sel->files->priv.height = 16;
	orig_size_request(widget);
}
