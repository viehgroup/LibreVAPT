static gboolean
action_move_parent(GntBindable *bind, GList *null)
{
	GntTree *tree = GNT_TREE(bind);
	GntTreeRow *row = tree->current;
	int dist;
	if (!row || !row->parent || SEARCHING(tree))
		return FALSE;
	tree->current = row->parent;
	if ((dist = get_distance(tree->current, tree->top)) > 0)
		gnt_tree_scroll(tree, -dist);
	else
		redraw_tree(tree);
	tree_selection_changed(tree, row, tree->current);
	return TRUE;
}
