GList *
purple_get_chats(void)
{
	return chats;
}
