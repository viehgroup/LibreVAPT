static void
regex_filter_toggled_cb(GtkToggleToolButton *button, DebugWindow *win) {
	gboolean active;
	active = gtk_toggle_tool_button_get_active(button);
	purple_prefs_set_bool(PIDGIN_PREFS_ROOT "/debug/filter", active);
	if(!GTK_IS_IMHTML(win->text))
		return;
	if(active)
		regex_filter_all(win);
	else
		regex_show_all(win);
}
