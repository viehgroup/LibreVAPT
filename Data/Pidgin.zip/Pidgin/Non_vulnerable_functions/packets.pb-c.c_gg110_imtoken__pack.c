}
size_t gg110_imtoken__pack
                     (const GG110Imtoken *message,
                      uint8_t       *out)
{
  assert(message->base.descriptor == &gg110_imtoken__descriptor);
  return protobuf_c_message_pack ((const ProtobufCMessage*)message, out);
}
}
size_t gg110_imtoken__pack_to_buffer
                     (const GG110Imtoken *message,
                      ProtobufCBuffer *buffer)
{
  assert(message->base.descriptor == &gg110_imtoken__descriptor);
  return protobuf_c_message_pack_to_buffer ((const ProtobufCMessage*)message, buffer);
}
