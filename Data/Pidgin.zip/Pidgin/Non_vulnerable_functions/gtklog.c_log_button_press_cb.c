}
static gboolean log_button_press_cb(GtkWidget *treeview, GdkEventButton *event, PidginLogViewer *lv)
{
	if (event->type == GDK_BUTTON_PRESS && event->button == 3)
	{
		GtkTreePath *path;
		GtkTreeIter *iter;
		GValue val;
		PurpleLog *log;
		gpointer *data;
		if (!gtk_tree_view_get_path_at_pos(GTK_TREE_VIEW(treeview), event->x, event->y, &path, NULL, NULL, NULL))
			return FALSE;
		iter = g_new(GtkTreeIter, 1);
		gtk_tree_model_get_iter(GTK_TREE_MODEL(lv->treestore), iter, path);
		val.g_type = 0;
		gtk_tree_model_get_value(GTK_TREE_MODEL(lv->treestore), iter, 1, &val);
		gtk_tree_path_free(path);
		log = g_value_get_pointer(&val);
		if (log == NULL)
		{
			g_free(iter);
			return FALSE;
		}
		data = g_new(gpointer, 4);
		data[0] = lv;
		data[1] = log;
		data[2] = NULL;
		data[3] = iter;
		log_show_popup_menu(treeview, event, data);
		return TRUE;
	}
	return FALSE;
}
