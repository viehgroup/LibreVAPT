static gboolean
plugin_load(PurplePlugin *plugin)
{
	/* migrate the old pref (we should only care if the plugin is actually *used*) */
	/*
	 * TODO: We should eventually call purple_prefs_remove(PREFS_STRANGER_OLD)
	 *       to clean up after ourselves, but we don't want to do it yet
	 *       so that we don't break users who share a .purple directory
	 *       between old libpurple clients and new libpurple clients.
	 *                                             --Mark Doliner, 2011-01-03
	 */
	if (!purple_prefs_exists(PREF_STRANGER)) {
		if (purple_prefs_get_bool(PREF_STRANGER_OLD))
			purple_prefs_add_int(PREF_STRANGER, FT_REJECT);
		else
			purple_prefs_set_int(PREF_STRANGER, FT_ASK);
	}
	purple_signal_connect(purple_xfers_get_handle(), "file-recv-request", plugin,
						PURPLE_CALLBACK(file_recv_request_cb), plugin);
	purple_signal_connect(purple_blist_get_handle(), "blist-node-extended-menu", plugin,
						PURPLE_CALLBACK(context_menu), plugin);
	return TRUE;
}
