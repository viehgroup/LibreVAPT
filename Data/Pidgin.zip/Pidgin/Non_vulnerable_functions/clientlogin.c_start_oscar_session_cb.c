}
static void start_oscar_session_cb(PurpleUtilFetchUrlData *url_data, gpointer user_data, const gchar *url_text, gsize len, const gchar *error_message)
{
	OscarData *od;
	PurpleConnection *gc;
	char *host, *cookie;
	char *tls_certname = NULL;
	unsigned short port;
	guint8 *cookiedata;
	gsize cookiedata_len = 0;
	od = user_data;
	gc = od->gc;
	od->url_data = NULL;
	if (error_message != NULL || len == 0) {
		gchar *tmp;
		/* Note to translators: The first %s is a URL, the second is an
		   error message. */
		tmp = g_strdup_printf(_("Error requesting %s: %s"),
				get_start_oscar_session_url(od), error_message ?
				error_message : _("The server returned an empty response"));
		purple_connection_error_reason(gc,
				PURPLE_CONNECTION_ERROR_NETWORK_ERROR, tmp);
		g_free(tmp);
		return;
	}
	if (!parse_start_oscar_session_response(gc, url_text, len, &host, &port, &cookie, &tls_certname))
		return;
	cookiedata = purple_base64_decode(cookie, &cookiedata_len);
	oscar_connect_to_bos(gc, od, host, port, cookiedata, cookiedata_len, tls_certname);
	g_free(cookiedata);
	g_free(host);
	g_free(cookie);
	g_free(tls_certname);
}
