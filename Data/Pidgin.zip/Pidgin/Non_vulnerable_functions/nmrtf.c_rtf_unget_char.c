static int
rtf_unget_char(NMRtfContext *ctx, guchar ch)
{
	ctx->nextch = ch;
	ctx->nextch_available = TRUE;
	return NMRTF_OK;
}
