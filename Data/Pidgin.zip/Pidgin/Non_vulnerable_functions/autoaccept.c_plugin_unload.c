static gboolean
plugin_unload(PurplePlugin *plugin)
{
	return TRUE;
}
