static void
toggle_something(const char *prefix, int format)
{
	int f;
	char tmp[128];
	g_snprintf(tmp, sizeof(tmp), "%s/format", prefix);
	f = purple_prefs_get_int(tmp);
	f ^= format;
	purple_prefs_set_int(tmp, f);
}
