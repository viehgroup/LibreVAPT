void
oscar_keepalive(PurpleConnection *gc)
{
	OscarData *od;
	GSList *l;
	od = purple_connection_get_protocol_data(gc);
	for (l = od->oscar_connections; l; l = l->next) {
		flap_connection_send_keepalive(od, l->data);
	}
}
