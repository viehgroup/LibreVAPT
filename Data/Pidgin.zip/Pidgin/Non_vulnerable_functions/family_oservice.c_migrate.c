static int
migrate(OscarData *od, FlapConnection *conn, aim_module_t *mod, FlapFrame *frame, aim_modsnac_t *snac, ByteStream *bs)
{
	aim_rxcallback_t userfunc;
	int ret = 0;
	guint16 groupcount, i;
	GSList *tlvlist;
	char *ip = NULL;
	aim_tlv_t *cktlv;
	/*
	 * Apparently there's some fun stuff that can happen right here. The
	 * migration can actually be quite selective about what groups it
	 * moves to the new server.  When not all the groups for a connection
	 * are migrated, or they are all migrated but some groups are moved
	 * to a different server than others, it is called a bifurcated
	 * migration.
	 *
	 * Let's play dumb and not support that.
	 *
	 */
	groupcount = byte_stream_get16(bs);
	for (i = 0; i < groupcount; i++) {
		guint16 group;
		group = byte_stream_get16(bs);
		purple_debug_misc("oscar", "bifurcated migration unsupported -- group 0x%04x\n", group);
	}
	tlvlist = aim_tlvlist_read(bs);
	if (aim_tlv_gettlv(tlvlist, 0x0005, 1))
		ip = aim_tlv_getstr(tlvlist, 0x0005, 1);
	cktlv = aim_tlv_gettlv(tlvlist, 0x0006, 1);
	if ((userfunc = aim_callhandler(od, snac->family, snac->subtype)))
		ret = userfunc(od, conn, frame, ip, cktlv ? cktlv->value : NULL);
	aim_tlvlist_free(tlvlist);
	g_free(ip);
	return ret;
}
