static gboolean
close_button_entered_cb(GtkWidget *widget, GdkEventCrossing *event, GtkLabel *label)
{
	static GdkCursor *hand = NULL;
	if (hand == NULL) {
		hand = gdk_cursor_new(GDK_HAND2);
	}
	gtk_label_set_markup(label, "<u>×</u>");
	gdk_window_set_cursor(event->window, hand);
	return FALSE;
}
