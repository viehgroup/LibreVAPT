gboolean
purple_blist_node_get_bool(PurpleBlistNode* node, const char *key)
{
	PurpleValue *value;
	g_return_val_if_fail(node != NULL, FALSE);
	g_return_val_if_fail(node->settings != NULL, FALSE);
	g_return_val_if_fail(key != NULL, FALSE);
	value = g_hash_table_lookup(node->settings, key);
	if (value == NULL)
		return FALSE;
	g_return_val_if_fail(purple_value_get_type(value) == PURPLE_TYPE_BOOLEAN, FALSE);
	return purple_value_get_boolean(value);
}
