}
static GtkIMHtmlSmiley *smiley_purple_to_gtkimhtml(PurpleSmiley *smiley)
{
	GtkIMHtmlSmiley *gtksmiley;
	gchar *filename;
	const gchar *file;
	file = purple_imgstore_get_filename(purple_smiley_get_stored_image(smiley));
	filename = g_build_filename(purple_smileys_get_storing_dir(), file, NULL);
	gtksmiley = gtk_imhtml_smiley_create(filename, purple_smiley_get_shortcut(smiley),
			FALSE, GTK_IMHTML_SMILEY_CUSTOM);
	g_free(filename);
	/* Make sure the shortcut for the GtkIMHtmlSmiley is updated with the PurpleSmiley */
	g_signal_connect(G_OBJECT(smiley), "notify::shortcut",
			G_CALLBACK(shortcut_changed_cb), gtksmiley);
	/* And update the pixbuf too when the image is changed */
	g_signal_connect(G_OBJECT(smiley), "notify::image",
			G_CALLBACK(image_changed_cb), gtksmiley);
	return gtksmiley;
}
