PurpleSslOps *
purple_ssl_get_ops(void)
{
	return _ssl_ops;
}
