static void
_evt_conference_joined(NMUser * user, NMEvent * event)
{
	PurpleConversation *chat = NULL;
	PurpleConnection *gc;
	NMConference *conference = NULL;
	NMUserRecord *ur = NULL;
	const char *name;
	const char *conf_name;
	gc = purple_account_get_connection(user->client_data);
	if (gc == NULL)
		return;
	conference = nm_event_get_conference(event);
	if (conference) {
		chat = nm_conference_get_data(conference);
		if (nm_conference_get_participant_count(conference) == 2 && chat == NULL) {
			ur = nm_conference_get_participant(conference, 0);
			if (ur) {
				conf_name = _get_conference_name(++user->conference_count);
				chat =
					serv_got_joined_chat(gc, user->conference_count, conf_name);
				if (chat) {
					nm_conference_set_data(conference, (gpointer) chat);
					name = nm_user_record_get_display_id(ur);
					purple_conv_chat_add_user(PURPLE_CONV_CHAT(chat), name, NULL,
											PURPLE_CBFLAGS_NONE, TRUE);
				}
			}
		}
		if (chat != NULL) {
			ur = nm_find_user_record(user, nm_event_get_source(event));
			if (ur) {
				name = nm_user_record_get_display_id(ur);
				if (!purple_conv_chat_find_user(PURPLE_CONV_CHAT(chat), name)) {
					purple_conv_chat_add_user(PURPLE_CONV_CHAT(chat), name, NULL,
											PURPLE_CBFLAGS_NONE, TRUE);
				}
			}
		}
	}
}
