static gboolean
plugin_unload(PurplePlugin *plugin)
{
	void *jabber_handle = purple_plugins_find_with_id("prpl-jabber");
	purple_signals_disconnect_by_handle(plugin);
	if (jabber_handle) {
		/* Unregister watched namespaces */
		purple_signal_emit(jabber_handle, "jabber-unregister-namespace-watcher",
		                   "bogus_node", "super-duper-namespace");
		/* The above is equivalent to doing:
		   int result = GPOINTER_TO_INT(purple_plugin_ipc_call(jabber_handle, "unregister_namespace_watcher", &ok, "bogus_node", "super-duper-namespace"));
		 */
	}
	return TRUE;
}
