};
void purple_tcl_ref_init()
{
	Tcl_RegisterObjType(&purple_tcl_ref);
}
