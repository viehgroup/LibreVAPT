gboolean
gnt_wm_switch_workspace_prev(GntWM *wm)
{
	int n = g_list_index(wm->workspaces, wm->cws);
	return gnt_wm_switch_workspace(wm, --n);
}
