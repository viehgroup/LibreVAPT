}
static GdkFilterReturn wnd_showwindow(GtkAppBar *ab, GdkXEvent *xevent) {
	MSG *msg = (MSG*)xevent;
	purple_debug_info("gtkappbar", "wnd_showwindow\n");
	if(msg->wParam && ab->docked) {
		show_hide(ab, FALSE);
	} else if(!msg->wParam && ab->docked) {
		show_hide(ab, TRUE);
	}
	return GDK_FILTER_CONTINUE;
}
