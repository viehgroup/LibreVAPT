}
size_t gg110_options__pack_to_buffer
                     (const GG110Options *message,
                      ProtobufCBuffer *buffer)
{
  assert(message->base.descriptor == &gg110_options__descriptor);
  return protobuf_c_message_pack_to_buffer ((const ProtobufCMessage*)message, buffer);
}
