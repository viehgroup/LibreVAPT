}
static void read_input(struct irc_conn *irc, int len)
{
	char *cur, *end;
	irc->account->gc->last_received = time(NULL);
	irc->inbufused += len;
	irc->inbuf[irc->inbufused] = '\0';
	cur = irc->inbuf;
	/* This is a hack to work around the fact that marv gets messages
	 * with null bytes in them while using some weird irc server at work
	 */
	while ((cur < (irc->inbuf + irc->inbufused)) && !*cur)
		cur++;
	while (cur < irc->inbuf + irc->inbufused &&
	       ((end = strstr(cur, "\r\n")) || (end = strstr(cur, "\n")))) {
		int step = (*end == '\r' ? 2 : 1);
		*end = '\0';
		irc_parse_msg(irc, cur);
		cur = end + step;
	}
	if (cur != irc->inbuf + irc->inbufused) { /* leftover */
		irc->inbufused -= (cur - irc->inbuf);
		memmove(irc->inbuf, cur, irc->inbufused);
	} else {
		irc->inbufused = 0;
	}
}
