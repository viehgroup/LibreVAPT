static int
redirect(OscarData *od, FlapConnection *conn, aim_module_t *mod, FlapFrame *frame, aim_modsnac_t *snac, ByteStream *bs)
{
	struct aim_redirect_data redir;
	aim_rxcallback_t userfunc;
	GSList *tlvlist;
	aim_snac_t *origsnac = NULL;
	int ret = 0;
	memset(&redir, 0, sizeof(redir));
	tlvlist = aim_tlvlist_read(bs);
	if (!aim_tlv_gettlv(tlvlist, 0x000d, 1) ||
			!aim_tlv_gettlv(tlvlist, 0x0005, 1) ||
			!aim_tlv_gettlv(tlvlist, 0x0006, 1)) {
		aim_tlvlist_free(tlvlist);
		return 0;
	}
	redir.group = aim_tlv_get16(tlvlist, 0x000d, 1);
	redir.ip = aim_tlv_getstr(tlvlist, 0x0005, 1);
	redir.cookielen = aim_tlv_gettlv(tlvlist, 0x0006, 1)->length;
	redir.cookie = (guchar *)aim_tlv_getstr(tlvlist, 0x0006, 1);
	redir.ssl_cert_cn = aim_tlv_getstr(tlvlist, 0x008d, 1);
	redir.use_ssl = aim_tlv_get8(tlvlist, 0x008e, 1);
	/* Fetch original SNAC so we can get csi if needed */
	origsnac = aim_remsnac(od, snac->id);
	if ((redir.group == SNAC_FAMILY_CHAT) && origsnac) {
		struct chatsnacinfo *csi = (struct chatsnacinfo *)origsnac->data;
		redir.chat.exchange = csi->exchange;
		redir.chat.room = csi->name;
		redir.chat.instance = csi->instance;
	}
	if ((userfunc = aim_callhandler(od, snac->family, snac->subtype)))
		ret = userfunc(od, conn, frame, &redir);
	g_free((void *)redir.ip);
	g_free((void *)redir.cookie);
	g_free((void *)redir.ssl_cert_cn);
	if (origsnac)
		g_free(origsnac->data);
	g_free(origsnac);
	aim_tlvlist_free(tlvlist);
	return ret;
}
