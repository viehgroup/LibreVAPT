static xmlnode *
jingle_rtp_to_xml_internal(JingleContent *rtp, xmlnode *content, JingleActionType action)
{
	xmlnode *node = parent_class->to_xml(rtp, content, action);
	xmlnode *description = xmlnode_get_child(node, "description");
	if (description != NULL) {
		JingleSession *session = jingle_content_get_session(rtp);
		PurpleMedia *media = jingle_rtp_get_media(session);
		gchar *media_type = jingle_rtp_get_media_type(rtp);
		gchar *ssrc = jingle_rtp_get_ssrc(rtp);
		gchar *name = jingle_content_get_name(rtp);
		GList *codecs = purple_media_get_codecs(media, name);
		xmlnode_set_attrib(description, "media", media_type);
		if (ssrc != NULL)
			xmlnode_set_attrib(description, "ssrc", ssrc);
		g_free(media_type);
		g_free(name);
		g_object_unref(session);
		jingle_rtp_add_payloads(description, codecs);
		purple_media_codec_list_free(codecs);
	}
	return node;
}
