void
jingle_content_accept_transport(JingleContent *content)
{
	if (content->priv->transport)
		g_object_unref(content->priv->transport);
	content->priv->transport = content->priv->pending_transport;
	content->priv->pending_transport = NULL;
}
