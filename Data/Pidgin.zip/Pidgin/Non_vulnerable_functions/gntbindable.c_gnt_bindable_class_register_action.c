}
void gnt_bindable_class_register_action(GntBindableClass *klass, const char *name,
			GntBindableActionCallback callback, const char *trigger, ...)
{
	void *data;
	va_list args;
	GntBindableAction *action = g_new0(GntBindableAction, 1);
	GList *list;
	action->name = g_strdup(name);
	action->u.action = callback;
	g_hash_table_replace(klass->actions, g_strdup(name), action);
	if (trigger && *trigger) {
		list = NULL;
		va_start(args, trigger);
		while ((data = va_arg(args, void *))) {
			list = g_list_append(list, data);
		}
		va_end(args);
		register_binding(klass, name, trigger, list);
	}
}
