void
purple_prefs_set_string(const char *name, const char *value)
{
	struct purple_pref *pref;
	if(value != NULL && !g_utf8_validate(value, -1, NULL)) {
		purple_debug_error("prefs", "purple_prefs_set_string: Cannot store invalid UTF8 for string pref %s\n", name);
		return;
	}
	PURPLE_PREFS_UI_OP_CALL(set_string, name, value);
	pref = find_pref(name);
	if(pref) {
		if(pref->type != PURPLE_PREF_STRING && pref->type != PURPLE_PREF_PATH) {
			purple_debug_error("prefs",
					"purple_prefs_set_string: %s not a string pref\n", name);
			return;
		}
		if (!purple_strequal(pref->value.string, value)) {
			g_free(pref->value.string);
			pref->value.string = g_strdup(value);
			do_callbacks(name, pref);
		}
	} else {
		purple_prefs_add_string(name, value);
	}
}
