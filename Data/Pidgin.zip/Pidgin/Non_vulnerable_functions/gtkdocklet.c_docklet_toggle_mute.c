static void
docklet_toggle_mute(GtkWidget *toggle, void *data)
{
	purple_prefs_set_bool(PIDGIN_PREFS_ROOT "/sound/mute", GTK_CHECK_MENU_ITEM(toggle)->active);
}
