GList *
purple_get_conversations(void)
{
	return conversations;
}
