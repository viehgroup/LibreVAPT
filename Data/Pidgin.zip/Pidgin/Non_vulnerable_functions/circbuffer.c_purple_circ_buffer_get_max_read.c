}
gsize purple_circ_buffer_get_max_read(const PurpleCircBuffer *buf) {
	gsize max_read;
	g_return_val_if_fail(buf != NULL, 0);
	if (buf->bufused == 0)
		max_read = 0;
	else if ((buf->outptr - buf->inptr) >= 0)
		max_read = buf->buflen - (buf->outptr - buf->buffer);
	else
		max_read = buf->inptr - buf->outptr;
	return max_read;
}
