}
size_t byte_stream_bytes_left(ByteStream *bs)
{
	return bs->len - bs->offset;
}
