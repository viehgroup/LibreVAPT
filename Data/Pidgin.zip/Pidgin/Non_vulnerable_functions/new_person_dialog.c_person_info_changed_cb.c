static void
person_info_changed_cb(GtkEntry *entry, GevoNewPersonDialog *dialog)
{
	gtk_widget_set_sensitive(dialog->add_button,
		(*gtk_entry_get_text(GTK_ENTRY(dialog->firstname)) != '\0' ||
		 *gtk_entry_get_text(GTK_ENTRY(dialog->lastname))  != '\0'));
}
