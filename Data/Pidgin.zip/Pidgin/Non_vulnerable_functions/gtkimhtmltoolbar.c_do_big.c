static void
do_big(GtkWidget *large, GtkIMHtmlToolbar *toolbar)
{
	g_return_if_fail(toolbar);
	/* Only grow the font on activation, not deactivation as well */
	if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(large)))
		gtk_imhtml_font_grow(GTK_IMHTML(toolbar->imhtml));
	gtk_widget_grab_focus(toolbar->imhtml);
}
