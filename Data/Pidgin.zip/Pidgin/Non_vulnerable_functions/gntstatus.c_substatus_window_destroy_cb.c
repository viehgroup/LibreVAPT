static void
substatus_window_destroy_cb(GntWidget *window, EditSubStatus *sub)
{
	g_hash_table_remove(sub->parent->hash, sub->key->account);
	g_free(sub);
}
