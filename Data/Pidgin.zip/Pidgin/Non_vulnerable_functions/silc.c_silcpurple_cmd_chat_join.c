}
static PurpleCmdRet silcpurple_cmd_chat_join(PurpleConversation *conv,
        const char *cmd, char **args, char **error, void *data)
{
	GHashTable *comp;
	if(!args || !args[0])
		return PURPLE_CMD_RET_FAILED;
	comp = g_hash_table_new_full(g_str_hash, g_str_equal, NULL, NULL);
	g_hash_table_replace(comp, "channel", args[0]);
	if(args[1])
		g_hash_table_replace(comp, "passphrase", args[1]);
	silcpurple_chat_join(purple_conversation_get_gc(conv), comp);
	g_hash_table_destroy(comp);
	return PURPLE_CMD_RET_OK;
}
