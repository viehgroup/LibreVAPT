}
static void gtk_blist_row_collapsed_cb(GtkTreeView *tv, GtkTreeIter *iter, GtkTreePath *path, gpointer user_data)
{
	PurpleBlistNode *node;
	gtk_tree_model_get(GTK_TREE_MODEL(gtkblist->treemodel), iter, NODE_COLUMN, &node, -1);
	if (PURPLE_BLIST_NODE_IS_GROUP(node)) {
		char *title;
		struct _pidgin_blist_node *gtknode;
		PurpleBlistNode *cnode;
		title = pidgin_get_group_title(node, FALSE);
		gtk_tree_store_set(gtkblist->treemodel, iter,
		   NAME_COLUMN, title,
		   -1);
		g_free(title);
		purple_blist_node_set_bool(node, "collapsed", TRUE);
		for(cnode = purple_blist_node_get_first_child(node); cnode; cnode = purple_blist_node_get_sibling_next(cnode)) {
			if (PURPLE_BLIST_NODE_IS_CONTACT(cnode)) {
				gtknode = purple_blist_node_get_ui_data(cnode);
				if (!gtknode->contact_expanded)
					continue;
				gtknode->contact_expanded = FALSE;
				pidgin_blist_update_contact(NULL, cnode);
			}
		}
		pidgin_blist_tooltip_destroy();
	} else if(PURPLE_BLIST_NODE_IS_CONTACT(node)) {
		pidgin_blist_collapse_contact_cb(NULL, node);
	}
}
