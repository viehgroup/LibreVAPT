}
const struct gg_search_request *gg_search_request_mode_3(uin_t uin, int active, int start)
{
	return NULL;
}
