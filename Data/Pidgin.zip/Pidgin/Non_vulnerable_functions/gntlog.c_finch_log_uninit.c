void
finch_log_uninit(void)
{
	purple_signals_unregister_by_instance(finch_log_get_handle());
}
