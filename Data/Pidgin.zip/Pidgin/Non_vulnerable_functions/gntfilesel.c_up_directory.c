static gboolean
up_directory(GntBindable *bind, GList *null)
{
	char *path, *dir;
	GntFileSel *sel = GNT_FILE_SEL(bind);
	if (!gnt_widget_has_focus(sel->dirs) &&
			!gnt_widget_has_focus(sel->files))
		return FALSE;
	if (gnt_tree_is_searching(GNT_TREE(sel->dirs)) ||
			gnt_tree_is_searching(GNT_TREE(sel->files)))
		return FALSE;
	path = g_build_filename(sel->current, "..", NULL);
	dir = g_path_get_basename(sel->current);
	if (gnt_file_sel_set_current_location(sel, path))
		gnt_tree_set_selected(GNT_TREE(sel->dirs), dir);
	g_free(dir);
	g_free(path);
	return TRUE;
}
