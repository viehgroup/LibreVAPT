static void
silcpurple_ftp_request_denied(PurpleXfer *x)
{
}
