 */
static int aim_ssi_addmoddel(OscarData *od)
{
	FlapConnection *conn;
	ByteStream bs;
	aim_snacid_t snacid;
	int bslen;
	struct aim_ssi_tmp *cur;
	if (!od || !(conn = flap_connection_findbygroup(od, SNAC_FAMILY_FEEDBAG)) || !od->ssi.pending || !od->ssi.pending->item)
		return -EINVAL;
	/* Calculate total SNAC size */
	bslen = 0;
	for (cur=od->ssi.pending; cur; cur=cur->next) {
		bslen += 10; /* For length, GID, BID, type, and length */
		if (cur->item->name)
			bslen += strlen(cur->item->name);
		if (cur->item->data)
			bslen += aim_tlvlist_size(cur->item->data);
	}
	byte_stream_new(&bs, bslen);
	for (cur=od->ssi.pending; cur; cur=cur->next) {
		byte_stream_put16(&bs, cur->item->name ? strlen(cur->item->name) : 0);
		if (cur->item->name)
			byte_stream_putstr(&bs, cur->item->name);
		byte_stream_put16(&bs, cur->item->gid);
		byte_stream_put16(&bs, cur->item->bid);
		byte_stream_put16(&bs, cur->item->type);
		byte_stream_put16(&bs, cur->item->data ? aim_tlvlist_size(cur->item->data) : 0);
		if (cur->item->data)
			aim_tlvlist_write(&bs, &cur->item->data);
	}
	snacid = aim_cachesnac(od, SNAC_FAMILY_FEEDBAG, od->ssi.pending->action, 0x0000, NULL, 0);
	flap_connection_send_snac(od, conn, SNAC_FAMILY_FEEDBAG, od->ssi.pending->action, snacid, &bs);
	byte_stream_destroy(&bs);
	return 0;
}
