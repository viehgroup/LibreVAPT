static void
rebuild_block_list(PidginPrivacyDialog *dialog)
{
	GSList *l;
	GtkTreeIter iter;
	gtk_list_store_clear(dialog->block_store);
	for (l = dialog->account->deny; l != NULL; l = l->next) {
		gtk_list_store_append(dialog->block_store, &iter);
		gtk_list_store_set(dialog->block_store, &iter, 0, l->data, -1);
	}
}
static GtkWidget *
build_block_list(PidginPrivacyDialog *dialog)
{
	GtkWidget *widget;
	GtkWidget *list;
	dialog->block_store = gtk_list_store_new(1, G_TYPE_STRING);
	gtk_tree_sortable_set_sort_column_id(GTK_TREE_SORTABLE(dialog->block_store), 0, GTK_SORT_ASCENDING);
	widget = build_list(dialog, dialog->block_store, &list);
	dialog->block_list = list;
	rebuild_block_list(dialog);
	return widget;
}
