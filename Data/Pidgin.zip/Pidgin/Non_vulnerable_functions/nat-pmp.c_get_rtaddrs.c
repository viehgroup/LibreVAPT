static void
get_rtaddrs(int bitmask, struct sockaddr *sa, struct sockaddr *addrs[])
{
	int i;
	for (i = 0; i < RTAX_MAX; i++)
	{
		if (bitmask & (1 << i))
		{
			addrs[i] = sa;
#ifdef HAVE_STRUCT_SOCKADDR_SA_LEN
			sa = (struct sockaddr *)(ROUNDUP(sa->sa_len) + (char *)sa);
#else
			if (sa->sa_family == AF_INET)
				sa = (struct sockaddr*)(sizeof(struct sockaddr_in) + (char *)sa);
#ifdef AF_INET6
			else if (sa->sa_family == AF_INET6)
				sa = (struct sockaddr*)(sizeof(struct sockaddr_in6) + (char *)sa);
#endif
#endif
		}
		else
		{
			addrs[i] = NULL;
		}
	}
}
