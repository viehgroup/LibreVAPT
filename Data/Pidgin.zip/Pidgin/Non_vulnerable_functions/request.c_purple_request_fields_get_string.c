const char *
purple_request_fields_get_string(const PurpleRequestFields *fields, const char *id)
{
	PurpleRequestField *field;
	g_return_val_if_fail(fields != NULL, NULL);
	g_return_val_if_fail(id     != NULL, NULL);
	if ((field = purple_request_fields_get_field(fields, id)) == NULL)
		return NULL;
	return purple_request_field_string_get_value(field);
}
