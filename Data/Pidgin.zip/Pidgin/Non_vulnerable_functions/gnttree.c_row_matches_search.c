static gboolean
row_matches_search(GntTreeRow *row)
{
	GntTree *t = row->tree;
	if (t->priv->search && t->priv->search->len > 0) {
		GntTreeCol *col = (col = g_list_nth_data(row->columns, t->priv->search_column)) ? col : row->columns->data;
		char *one, *two, *z;
		if (t->priv->search_func)
			return t->priv->search_func(t, row->key, t->priv->search->str, col->text);
		one = g_utf8_casefold(col->text, -1);
		two = g_utf8_casefold(t->priv->search->str, -1);
		z = strstr(one, two);
		g_free(one);
		g_free(two);
		if (z == NULL)
			return FALSE;
	}
	return TRUE;
}
