static void
blist_node_extended_menu_cb(PurpleBlistNode *node, GList **menu)
{
	PurpleMenuAction *act;
	PurpleBuddy *buddy;
	PurpleAccount *account;
	EContact *contact;
	char *mail;
	if (!PURPLE_BLIST_NODE_IS_BUDDY(node))
		return;
	buddy = (PurpleBuddy *)node;
	account = purple_buddy_get_account(buddy);
	if (!gevo_prpl_is_supported(account, buddy))
		return;
	contact = gevo_search_buddy_in_contacts(buddy, NULL);
	if (contact == NULL)
	{
		act = purple_menu_action_new(_("Add to Address Book"),
		                           PURPLE_CALLBACK(menu_item_activate_cb),
		                           NULL, NULL);
		*menu = g_list_append(*menu, act);
	}
	else
		g_object_unref(contact);
	mail = gevo_get_email_for_buddy(buddy);
	if (mail != NULL)
	{
		act = purple_menu_action_new(_("Send Email"),
			PURPLE_CALLBACK(menu_item_send_mail_activate_cb), NULL, NULL);
		*menu = g_list_append(*menu, act);
		g_free(mail);
	}
}
