}
PurpleStoredImage *purple_imgstore_find_by_id(int id)
{
	PurpleStoredImage *img = g_hash_table_lookup(imgstore, &id);
	if (img != NULL)
		purple_debug_misc("imgstore", "retrieved image id %d\n", img->id);
	return img;
}
