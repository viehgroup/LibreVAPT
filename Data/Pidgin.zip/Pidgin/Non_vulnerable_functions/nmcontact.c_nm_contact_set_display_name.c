void
nm_contact_set_display_name(NMContact * contact, const char *display_name)
{
	if (contact == NULL)
		return;
	if (contact->display_name) {
		g_free(contact->display_name);
		contact->display_name = NULL;
	}
	if (display_name)
		contact->display_name = g_strdup(display_name);
}
