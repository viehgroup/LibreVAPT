static void
purple_icq_buddyadd(struct name_data *data)
{
	PurpleConnection *gc = data->gc;
	purple_blist_request_add_buddy(purple_connection_get_account(gc), data->name, NULL, data->nick);
	oscar_free_name_data(data);
}
