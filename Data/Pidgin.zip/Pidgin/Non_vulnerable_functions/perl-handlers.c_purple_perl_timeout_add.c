guint
purple_perl_timeout_add(PurplePlugin *plugin, int seconds, SV *callback, SV *data)
{
	PurplePerlTimeoutHandler *handler;
	if (plugin == NULL) {
		croak("Invalid handle in adding perl timeout handler.\n");
		return 0;
	}
	handler = g_new0(PurplePerlTimeoutHandler, 1);
	handler->plugin   = plugin;
	handler->callback = (callback != NULL && callback != &PL_sv_undef
	                     ? newSVsv(callback) : NULL);
	handler->data     = (data != NULL && data != &PL_sv_undef
	                     ? newSVsv(data) : NULL);
	timeout_handlers = g_slist_append(timeout_handlers, handler);
	handler->iotag = purple_timeout_add_seconds(seconds, perl_timeout_cb, handler);
	return handler->iotag;
}
