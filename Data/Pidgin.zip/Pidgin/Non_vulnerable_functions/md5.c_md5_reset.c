static void
md5_reset(PurpleCipherContext *context, gpointer extra) {
	struct MD5Context *md5_context;
	md5_context = purple_cipher_context_get_data(context);
	md5_context->total[0] = 0;
	md5_context->total[1] = 0;
	md5_context->state[0] = 0x67452301;
	md5_context->state[1] = 0xEFCDAB89;
	md5_context->state[2] = 0x98BADCFE;
	md5_context->state[3] = 0x10325476;
	memset(md5_context->buffer, 0, sizeof(md5_context->buffer));
}
