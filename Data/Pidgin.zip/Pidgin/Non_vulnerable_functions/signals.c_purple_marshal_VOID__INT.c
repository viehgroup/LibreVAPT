void
purple_marshal_VOID__INT(PurpleCallback cb, va_list args, void *data,
					   void **return_val)
{
	gint arg1 = va_arg(args, gint);
	((void (*)(gint, void *))cb)(arg1, data);
}
