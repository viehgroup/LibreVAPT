}
int byte_stream_putbs(ByteStream *bs, ByteStream *srcbs, size_t len)
{
	g_return_val_if_fail(byte_stream_bytes_left(srcbs) >= len, 0);
	g_return_val_if_fail(byte_stream_bytes_left(bs) >= len, 0);
	memcpy(bs->data + bs->offset, srcbs->data + srcbs->offset, len);
	bs->offset += len;
	srcbs->offset += len;
	return len;
}
