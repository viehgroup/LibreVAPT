}
static void gtk_source_undo_manager_insert_anchor_handler (GtkTextBuffer *buffer,
			                   GtkTextIter            *pos,
			                   GtkTextChildAnchor     *anchor,
			                   GtkSourceUndoManager   *um)
{
	GtkSourceUndoAction undo_action;
	if (um->priv->running_not_undoable_actions > 0)
		return;
	undo_action.action_type = GTK_SOURCE_UNDO_ACTION_INSERT_ANCHOR;
	undo_action.action.insert_anchor.pos    = gtk_text_iter_get_offset (pos);
	undo_action.action.insert_anchor.anchor = g_object_ref (anchor);
	undo_action.mergeable = FALSE;
	undo_action.modified = FALSE;
	gtk_source_undo_manager_add_action (um, &undo_action);
}
