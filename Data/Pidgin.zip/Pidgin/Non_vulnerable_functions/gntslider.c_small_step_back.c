static gboolean
small_step_back(GntBindable *bindable, GList *null)
{
	GntSlider *slider = GNT_SLIDER(bindable);
	gnt_slider_set_value(slider, slider->current - slider->smallstep);
	return TRUE;
}
