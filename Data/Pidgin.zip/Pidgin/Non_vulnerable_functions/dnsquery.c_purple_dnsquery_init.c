void
purple_dnsquery_init(void)
{
}
