static void
jabber_google_relay_response_session_initiate_cb(GoogleSession *session,
    const gchar *relay_ip, guint relay_udp, guint relay_tcp, guint relay_ssltcp,
    const gchar *relay_username, const gchar *relay_password)
{
	GParameter *params;
	guint num_params;
	JabberStream *js = session->js;
	GoogleAVSessionData *session_data =
		(GoogleAVSessionData *) session->session_data;
	session_data->media = purple_media_manager_create_media(
			purple_media_manager_get(),
			purple_connection_get_account(js->gc),
			"fsrtpconference", session->remote_jid, TRUE);
	purple_media_set_prpl_data(session_data->media, session);
	g_signal_connect_swapped(G_OBJECT(session_data->media),
			"candidates-prepared",
			G_CALLBACK(google_session_ready), session);
	g_signal_connect_swapped(G_OBJECT(session_data->media), "codecs-changed",
			G_CALLBACK(google_session_ready), session);
	g_signal_connect(G_OBJECT(session_data->media), "state-changed",
			G_CALLBACK(google_session_state_changed_cb), session);
	g_signal_connect(G_OBJECT(session_data->media), "stream-info",
			G_CALLBACK(google_session_stream_info_cb), session);
	params =
		jabber_google_session_get_params(js, relay_ip, relay_udp, relay_tcp,
			relay_ssltcp, relay_username, relay_password, &num_params);
	if (purple_media_add_stream(session_data->media, "google-voice",
			session->remote_jid, PURPLE_MEDIA_AUDIO,
			TRUE, "nice", num_params, params) == FALSE ||
			(session_data->video && purple_media_add_stream(
			session_data->media, "google-video",
			session->remote_jid, PURPLE_MEDIA_VIDEO,
			TRUE, "nice", num_params, params) == FALSE)) {
		purple_media_error(session_data->media, "Error adding stream.");
		purple_media_end(session_data->media, NULL, NULL);
	} else {
		session_data->added_streams = TRUE;
	}
	g_free(params);
}
