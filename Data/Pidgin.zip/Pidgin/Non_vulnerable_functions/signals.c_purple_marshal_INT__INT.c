void
purple_marshal_INT__INT(PurpleCallback cb, va_list args, void *data,
					  void **return_val)
{
	gint ret_val;
	gint arg1 = va_arg(args, gint);
	ret_val = ((gint (*)(gint, void *))cb)(arg1, data);
	if (return_val != NULL)
		*return_val = GINT_TO_POINTER(ret_val);
}
