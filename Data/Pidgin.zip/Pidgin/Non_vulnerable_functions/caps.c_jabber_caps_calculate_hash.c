}
gchar *jabber_caps_calculate_hash(JabberCapsClientInfo *info, const char *hash)
{
	GList *node;
	PurpleCipherContext *context;
	guint8 checksum[20];
	gsize checksum_size = 20;
	gboolean success;
	if (!info || !(context = purple_cipher_context_new_by_name(hash, NULL)))
		return NULL;
	/* sort identities, features and x-data forms */
	info->identities = g_list_sort(info->identities, jabber_identity_compare);
	info->features = g_list_sort(info->features, (GCompareFunc)strcmp);
	info->forms = g_list_sort(info->forms, jabber_xdata_compare);
	/* Add identities to the hash data */
	for (node = info->identities; node; node = node->next) {
		JabberIdentity *id = (JabberIdentity*)node->data;
		char *category = g_markup_escape_text(id->category, -1);
		char *type = g_markup_escape_text(id->type, -1);
		char *lang = NULL;
		char *name = NULL;
		char *tmp;
		if (id->lang)
			lang = g_markup_escape_text(id->lang, -1);
		if (id->name)
			name = g_markup_escape_text(id->name, -1);
		tmp = g_strconcat(category, "/", type, "/", lang ? lang : "",
		                  "/", name ? name : "", "<", NULL);
		purple_cipher_context_append(context, (const guchar *)tmp, strlen(tmp));
		g_free(tmp);
		g_free(category);
		g_free(type);
		g_free(lang);
		g_free(name);
	}
	/* concat features to the verification string */
	for (node = info->features; node; node = node->next) {
		append_escaped_string(context, node->data);
	}
	/* concat x-data forms to the verification string */
	for(node = info->forms; node; node = node->next) {
		xmlnode *data = (xmlnode *)node->data;
		gchar *formtype = jabber_x_data_get_formtype(data);
		GList *fields = jabber_caps_xdata_get_fields(data);
		/* append FORM_TYPE's field value to the verification string */
		append_escaped_string(context, formtype);
		g_free(formtype);
		while (fields) {
			GList *value;
			JabberDataFormField *field = (JabberDataFormField*)fields->data;
			if (!g_str_equal(field->var, "FORM_TYPE")) {
				/* Append the "var" attribute */
				append_escaped_string(context, field->var);
				/* Append <value/> elements' cdata */
				for (value = field->values; value; value = value->next) {
					append_escaped_string(context, value->data);
					g_free(value->data);
				}
			}
			g_free(field->var);
			g_list_free(field->values);
			fields = g_list_delete_link(fields, fields);
		}
	}
	/* generate hash */
	success = purple_cipher_context_digest(context, checksum_size,
	                                       checksum, &checksum_size);
	purple_cipher_context_destroy(context);
	return (success ? purple_base64_encode(checksum, checksum_size) : NULL);
}
