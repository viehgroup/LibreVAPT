static gboolean
jingle_rtp_init_media(JingleContent *content)
{
	JingleSession *session = jingle_content_get_session(content);
	PurpleMedia *media = jingle_rtp_get_media(session);
	gchar *creator;
	gchar *media_type;
	gchar *remote_jid;
	gchar *senders;
	gchar *name;
	const gchar *transmitter;
	gboolean is_audio;
	gboolean is_creator;
	PurpleMediaSessionType type;
	JingleTransport *transport;
	GParameter *params = NULL;
	guint num_params;
	/* maybe this create ought to just be in initiate and handle initiate */
	if (media == NULL) {
		media = jingle_rtp_create_media(content);
		if (media == NULL)
			return FALSE;
	}
	name = jingle_content_get_name(content);
	media_type = jingle_rtp_get_media_type(content);
	remote_jid = jingle_session_get_remote_jid(session);
	senders = jingle_content_get_senders(content);
	transport = jingle_content_get_transport(content);
	if (media_type == NULL) {
		g_free(name);
		g_free(remote_jid);
		g_free(senders);
		g_free(params);
		g_object_unref(transport);
		g_object_unref(session);
		return FALSE;
	}
	if (JINGLE_IS_RAWUDP(transport))
		transmitter = "rawudp";
	else if (JINGLE_IS_ICEUDP(transport))
		transmitter = "nice";
	else
		transmitter = "notransmitter";
	g_object_unref(transport);
	is_audio = g_str_equal(media_type, "audio");
	if (purple_strequal(senders, "both"))
		type = is_audio ? PURPLE_MEDIA_AUDIO
				: PURPLE_MEDIA_VIDEO;
	else if (purple_strequal(senders, "initiator") ==
			jingle_session_is_initiator(session))
		type = is_audio ? PURPLE_MEDIA_SEND_AUDIO
				: PURPLE_MEDIA_SEND_VIDEO;
	else
		type = is_audio ? PURPLE_MEDIA_RECV_AUDIO
				: PURPLE_MEDIA_RECV_VIDEO;
	params =
		jingle_get_params(jingle_session_get_js(session), NULL, 0, 0, 0,
			NULL, NULL, &num_params);
	creator = jingle_content_get_creator(content);
	if (creator == NULL) {
		g_free(name);
		g_free(media_type);
		g_free(remote_jid);
		g_free(senders);
		g_free(params);
		g_object_unref(session);
		return FALSE;
	}
	if (g_str_equal(creator, "initiator"))
		is_creator = jingle_session_is_initiator(session);
	else
		is_creator = !jingle_session_is_initiator(session);
	g_free(creator);
	if(!purple_media_add_stream(media, name, remote_jid,
			type, is_creator, transmitter, num_params, params)) {
		purple_media_end(media, NULL, NULL);
		/* TODO: How much clean-up is necessary here? (does calling
		         purple_media_end lead to cleaning up Jingle structs?) */
		return FALSE;
	}
	g_free(name);
	g_free(media_type);
	g_free(remote_jid);
	g_free(senders);
	g_free(params);
	g_object_unref(session);
	return TRUE;
}
