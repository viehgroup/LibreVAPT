static void
purple_srv_query_failed(PurpleSrvTxtQueryData *query_data, const gchar *error_message)
{
	purple_debug_error("dnssrv", "%s\n", error_message);
	if (query_data->cb.srv != NULL)
		query_data->cb.srv(NULL, 0, query_data->extradata);
	purple_srv_txt_query_destroy(query_data);
}
