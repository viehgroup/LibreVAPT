static gint
delete_win_cb(GtkWidget *w, GdkEventAny *e, PidginPounceDialog *dialog)
{
	gtk_widget_destroy(dialog->window);
	g_free(dialog);
	return TRUE;
}
