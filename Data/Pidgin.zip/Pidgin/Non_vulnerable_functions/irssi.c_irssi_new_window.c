static void
irssi_new_window(GntWM *wm, GntWidget *win)
{
	const char *name;
	int x, y, w, h;
	name = gnt_widget_get_name(win);
	if (!name || !strstr(name, "conversation-window")) {
		if (!GNT_IS_MENU(win) && !GNT_WIDGET_IS_FLAG_SET(win, GNT_WIDGET_TRANSIENT)) {
			if ((!name || strcmp(name, "buddylist"))) {
				gnt_widget_get_size(win, &w, &h);
				x = (getmaxx(stdscr) - w) / 2;
				y = (getmaxy(stdscr) - h) / 2;
				gnt_widget_set_position(win, x, y);
				mvwin(win->window, y, x);
			} else {
				gnt_window_set_maximize(GNT_WINDOW(win), GNT_WINDOW_MAXIMIZE_Y);
				remove_border_set_position_size(wm, win, 0, 0, -1, getmaxy(stdscr) - 1);
				gnt_widget_get_size(win, &((Irssi*)wm)->buddylistwidth, NULL);
				draw_line_separators((Irssi*)wm);
			}
		}
		org_new_window(wm, win);
		return;
	}
	/* The window we have here is a conversation window. */
	/* XXX: There should be some way to remember which frame a conversation window
	 * was in the last time. Perhaps save them in some ~/.gntpositionirssi or some
	 * such. */
	get_xywh_for_frame((Irssi*)wm, 0, 0, &x, &y, &w, &h);
	remove_border_set_position_size(wm, win, x, y, w, h);
	org_new_window(wm, win);
}
