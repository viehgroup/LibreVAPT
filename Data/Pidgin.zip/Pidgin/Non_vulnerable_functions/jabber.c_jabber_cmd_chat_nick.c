}
static PurpleCmdRet jabber_cmd_chat_nick(PurpleConversation *conv,
		const char *cmd, char **args, char **error, void *data)
{
	JabberChat *chat = jabber_chat_find_by_conv(conv);
	if(!chat || !args || !args[0])
		return PURPLE_CMD_RET_FAILED;
	if (!jabber_resourceprep_validate(args[0])) {
		*error = g_strdup(_("Invalid nickname"));
		return PURPLE_CMD_RET_FAILED;
	}
	if (jabber_chat_change_nick(chat, args[0]))
		return PURPLE_CMD_RET_OK;
	else
		return PURPLE_CMD_RET_FAILED;
}
