static gboolean
nested_group_can_add_node(PurpleBlistNode *node)
{
	PurpleBlistNode *group;
	int len;
	if (!PURPLE_BLIST_NODE_IS_GROUP(node))
		return default_manager->can_add_node(node);
	if (default_manager->can_add_node(node))
		return TRUE;
	len = strlen(purple_group_get_name((PurpleGroup*)node));
	group = purple_blist_get_root();
	for (; group; group = purple_blist_node_get_sibling_next(group)) {
		if (group == node)
			continue;
		if (strncmp(purple_group_get_name((PurpleGroup *)node),
					purple_group_get_name((PurpleGroup *)group), len) == 0 &&
				default_manager->can_add_node(group))
			return TRUE;
	}
	return FALSE;
}
