const char *
purple_savedstatus_get_title(const PurpleSavedStatus *saved_status)
{
	const char *message;
	g_return_val_if_fail(saved_status != NULL, NULL);
	/* If we have a title then return it */
	if (saved_status->title != NULL)
		return saved_status->title;
	/* Otherwise, this is a transient status and we make up a title on the fly */
	message = purple_savedstatus_get_message(saved_status);
	if ((message == NULL) || (*message == '\0'))
	{
		PurpleStatusPrimitive primitive;
		primitive = purple_savedstatus_get_type(saved_status);
		return purple_primitive_get_name_from_type(primitive);
	}
	else
	{
		char *stripped;
		static char buf[64];
		stripped = purple_markup_strip_html(message);
		purple_util_chrreplace(stripped, '\n', ' ');
		strncpy(buf, stripped, sizeof(buf));
		buf[sizeof(buf) - 1] = '\0';
		if ((strlen(stripped) + 1) > sizeof(buf))
		{
			/* Truncate and ellipsize */
			char *tmp = g_utf8_find_prev_char(buf, &buf[sizeof(buf) - 4]);
			strcpy(tmp, "...");
		}
		g_free(stripped);
		return buf;
	}
}
