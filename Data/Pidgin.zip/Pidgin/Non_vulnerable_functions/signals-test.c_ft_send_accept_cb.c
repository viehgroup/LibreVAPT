static void
ft_send_accept_cb(PurpleXfer *xfer, gpointer data) {
	purple_debug_misc("signals test", "file send accepted\n");
}
