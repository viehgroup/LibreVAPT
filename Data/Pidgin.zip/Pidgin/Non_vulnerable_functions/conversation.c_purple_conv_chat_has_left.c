gboolean
purple_conv_chat_has_left(PurpleConvChat *chat)
{
	g_return_val_if_fail(chat != NULL, TRUE);
	return chat->left;
}
