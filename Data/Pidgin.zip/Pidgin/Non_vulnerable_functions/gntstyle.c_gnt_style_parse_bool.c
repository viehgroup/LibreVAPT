}
gboolean gnt_style_parse_bool(const char *str)
{
	gboolean def = FALSE;
	int i;
	if (str)
	{
		if (g_ascii_strcasecmp(str, "false") == 0)
			def = FALSE;
		else if (g_ascii_strcasecmp(str, "true") == 0)
			def = TRUE;
		else if (sscanf(str, "%d", &i) == 1)
		{
			if (i)
				def = TRUE;
			else
				def = FALSE;
		}
	}
	return def;
}
