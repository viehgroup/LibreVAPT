static void
send_im_cb(PidginMiniDialog *mini_dialog,
           GtkButton *button,
           gpointer data)
{
	struct auth_request *ar = data;
	pidgin_dialogs_im_with_user(ar->account, ar->username);
}
