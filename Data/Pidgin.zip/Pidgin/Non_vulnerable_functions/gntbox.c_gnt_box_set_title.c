}
void gnt_box_set_title(GntBox *b, const char *title)
{
	char *prev = b->title;
	GntWidget *w = GNT_WIDGET(b);
	b->title = g_strdup(title);
	if (w->window && !GNT_WIDGET_IS_FLAG_SET(w, GNT_WIDGET_NO_BORDER)) {
		/* Erase the old title */
		int pos, right;
		get_title_thingies(b, prev, &pos, &right);
		mvwhline(w->window, 0, pos - 1, ACS_HLINE | gnt_color_pair(GNT_COLOR_NORMAL),
				right - pos + 2);
	}
	g_free(prev);
}
