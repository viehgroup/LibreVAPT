static void
silcpurple_ftp_ask_name(SilcClient client,
		      SilcClientConnection conn,
		      SilcUInt32 session_id,
		      const char *remote_filename,
		      SilcClientFileName completion,
		      void *completion_context,
		      void *context)
{
	SilcPurpleXfer xfer = context;
	xfer->completion = completion;
	xfer->completion_context = completion_context;
	purple_xfer_set_init_fnc(xfer->xfer, silcpurple_ftp_ask_name_ok);
	purple_xfer_set_request_denied_fnc(xfer->xfer, silcpurple_ftp_ask_name_cancel);
	/* Request to save the file */
	purple_xfer_set_filename(xfer->xfer, remote_filename);
	purple_xfer_request(xfer->xfer);
}
