static void
setup_buddy_list_suggestion(GntEntry *entry, gboolean offline)
{
	PurpleBlistNode *node = purple_blist_get_root();
	for (; node; node = purple_blist_node_next(node, offline)) {
		if (!PURPLE_BLIST_NODE_IS_BUDDY(node))
			continue;
		gnt_entry_add_suggest(entry, purple_buddy_get_name((PurpleBuddy*)node));
	}
}
