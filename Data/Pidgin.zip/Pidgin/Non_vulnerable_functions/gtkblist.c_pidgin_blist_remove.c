}
static void pidgin_blist_remove(PurpleBuddyList *list, PurpleBlistNode *node)
{
	struct _pidgin_blist_node *gtknode = node->ui_data;
	purple_request_close_with_handle(node);
	pidgin_blist_hide_node(list, node, TRUE);
	if(node->parent)
		pidgin_blist_update(list, node->parent);
	/* There's something I don't understand here - Ethan */
	/* Ethan said that back in 2003, but this g_free has been left commented
	 * out ever since. I can't find any reason at all why this is bad and
	 * valgrind found several reasons why it's good. If this causes problems
	 * comment it out again. Stu */
	/* Of course it still causes problems - this breaks dragging buddies into
	 * contacts, the dragged buddy mysteriously 'disappears'. Stu. */
	/* I think it's fixed now. Stu. */
	if(gtknode) {
		if(gtknode->recent_signonoff_timer > 0)
			purple_timeout_remove(gtknode->recent_signonoff_timer);
		purple_signals_disconnect_by_handle(node->ui_data);
		g_free(node->ui_data);
		node->ui_data = NULL;
	}
}
