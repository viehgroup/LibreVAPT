static gboolean
widget_motion_cb(GtkWidget *widget, GdkEvent *event, gpointer data)
{
	initialize_tooltip_delay();
	pidgin_tooltip_destroy();
	if (!enable_tooltips)
		return FALSE;
	pidgin_tooltip.timeout = g_timeout_add(tooltip_delay, (GSourceFunc)pidgin_tooltip_timeout, data);
	return FALSE;
}
