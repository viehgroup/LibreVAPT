gboolean
pidgin_roomlist_is_showable()
{
	GList *c;
	PurpleConnection *gc;
	for (c = purple_connections_get_all(); c != NULL; c = c->next) {
		gc = c->data;
		if (account_filter_func(purple_connection_get_account(gc)))
			return TRUE;
	}
	return FALSE;
}
