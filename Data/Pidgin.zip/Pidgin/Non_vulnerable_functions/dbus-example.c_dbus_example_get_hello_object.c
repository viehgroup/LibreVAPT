/* Here come the definitions of the four exported functions. */
PurpleText* dbus_example_get_hello_object(void)
{
	return &hello;
}
