const char *
null_to_empty(const char *s)
{
	if (s)
		return s;
	else
		return "";
}
