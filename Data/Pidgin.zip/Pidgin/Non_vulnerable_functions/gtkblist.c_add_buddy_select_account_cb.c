static void
add_buddy_select_account_cb(GObject *w, PurpleAccount *account,
							PidginAddBuddyData *data)
{
	PurpleConnection *pc = NULL;
	PurplePlugin *prpl = NULL;
	PurplePluginProtocolInfo *prpl_info = NULL;
	gboolean invite_enabled = TRUE;
	/* Save our account */
	data->rq_data.account = account;
	if (account)
		pc = purple_account_get_connection(account);
	if (pc)
		prpl = purple_connection_get_prpl(pc);
	if (prpl)
		prpl_info = PURPLE_PLUGIN_PROTOCOL_INFO(prpl);
	if (prpl_info && !(prpl_info->options & OPT_PROTO_INVITE_MESSAGE))
		invite_enabled = FALSE;
	gtk_widget_set_sensitive(data->entry_for_invite, invite_enabled);
}
