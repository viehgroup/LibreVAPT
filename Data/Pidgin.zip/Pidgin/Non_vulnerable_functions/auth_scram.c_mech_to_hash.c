};
static const JabberScramHash *mech_to_hash(const char *mech)
{
	gsize i;
	g_return_val_if_fail(mech != NULL && *mech != '\0', NULL);
	for (i = 0; i < G_N_ELEMENTS(hashes); ++i) {
		if (strstr(mech, hashes[i].mech_substr))
			return &(hashes[i]);
	}
	purple_debug_error("jabber", "Unknown SCRAM mechanism %s\n", mech);
	g_return_val_if_reached(NULL);
}
