/* }}} */
/* const char *ggp_confer_find_by_participants(PurpleConnection *gc, const uin_t *recipients, int count) {{{ */
const char *ggp_confer_find_by_participants(PurpleConnection *gc,
					    const uin_t *recipients, int count)
{
	GGPInfo *info = gc->proto_data;
	GGPChat *chat = NULL;
	GList *l;
	int matches;
	g_return_val_if_fail(info->chats != NULL, NULL);
	for (l = info->chats; l != NULL; l = l->next) {
		GList *m;
		chat = l->data;
		matches = 0;
		for (m = chat->participants; m != NULL; m = m->next) {
			uin_t uin = GPOINTER_TO_INT(m->data);
			int i;
			for (i = 0; i < count; i++)
				if (uin == recipients[i])
					matches++;
		}
		if (matches == count)
			break;
		chat = NULL;
	}
	if (chat == NULL)
		return NULL;
	else
		return chat->name;
}
/* }}} */
/* }}} */
/* const char *ggp_confer_find_by_participants(PurpleConnection *gc, const uin_t *recipients, int count) {{{ */
const char *ggp_confer_find_by_participants(PurpleConnection *gc,
					    const uin_t *recipients, int count)
{
	GGPInfo *info = gc->proto_data;
	GGPChat *chat = NULL;
	GList *l;
	int matches;
	g_return_val_if_fail(info->chats != NULL, NULL);
	for (l = info->chats; l != NULL; l = l->next) {
		GList *m;
		chat = l->data;
		matches = 0;
		for (m = chat->participants; m != NULL; m = m->next) {
			uin_t uin = GPOINTER_TO_INT(m->data);
			int i;
			for (i = 0; i < count; i++)
				if (uin == recipients[i])
					matches++;
		}
		if (matches == count)
			break;
		chat = NULL;
	}
	if (chat == NULL)
		return NULL;
	else
		return chat->name;
}
/* }}} */
/* const char *ggp_confer_find_by_participants(PurpleConnection *gc, const uin_t *recipients, int count) {{{ */
const char *ggp_confer_find_by_participants(PurpleConnection *gc,
					    const uin_t *recipients, int count)
{
	GGPInfo *info = gc->proto_data;
	GGPChat *chat = NULL;
	GList *l;
	int matches;
	g_return_val_if_fail(info->chats != NULL, NULL);
	for (l = info->chats; l != NULL; l = l->next) {
		GList *m;
		chat = l->data;
		matches = 0;
		for (m = chat->participants; m != NULL; m = m->next) {
			uin_t uin = GPOINTER_TO_INT(m->data);
			int i;
			for (i = 0; i < count; i++)
				if (uin == recipients[i])
					matches++;
		}
		if (matches == count)
			break;
		chat = NULL;
	}
	if (chat == NULL)
		return NULL;
	else
		return chat->name;
}
