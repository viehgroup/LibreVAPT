static void
sound_changed2_cb(const char *name, PurplePrefType type,
				  gconstpointer value, gpointer data)
{
	GtkWidget *vbox = data;
	const char *method = value;
	gtk_widget_set_sensitive(vbox, strcmp(method, "none"));
}
