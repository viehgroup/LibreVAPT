static const char *
lookup_locale (const PurpleDesktopItem *item, const char *key, const char *locale)
{
	if (locale == NULL ||
	    purple_strequal (locale, "C")) {
		return lookup (item, key);
	} else {
		const char *ret;
		char *full = g_strdup_printf ("%s[%s]", key, locale);
		ret = lookup (item, full);
		g_free (full);
		return ret;
	}
}
