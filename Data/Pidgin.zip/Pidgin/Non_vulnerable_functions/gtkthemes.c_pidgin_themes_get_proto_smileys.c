}
GSList *pidgin_themes_get_proto_smileys(const char *id) {
	PurplePlugin *proto;
	struct smiley_list *list, *def;
	if ((current_smiley_theme == NULL) || (current_smiley_theme->list == NULL))
		return NULL;
	def = list = current_smiley_theme->list;
	if (id == NULL)
		return def->smileys;
	proto = purple_find_prpl(id);
	while (list) {
		if (!strcmp(list->sml, "default"))
			def = list;
		else if (proto && !strcmp(proto->info->name, list->sml))
			break;
		list = list->next;
	}
	return list ? list->smileys : def->smileys;
}
