void
purple_account_set_int(PurpleAccount *account, const char *name, int value)
{
	PurpleAccountSetting *setting;
	PurpleAccountPrefsUiOps *ui_ops;
	g_return_if_fail(account != NULL);
	g_return_if_fail(name    != NULL);
	setting = g_new0(PurpleAccountSetting, 1);
	setting->type          = PURPLE_PREF_INT;
	setting->value.integer = value;
	g_hash_table_insert(account->settings, g_strdup(name), setting);
	ui_ops = purple_account_prefs_get_ui_ops();
	if (ui_ops != NULL && ui_ops->set_int != NULL) {
		ui_ops->set_int(account, name, value);
	}
	schedule_accounts_save();
}
