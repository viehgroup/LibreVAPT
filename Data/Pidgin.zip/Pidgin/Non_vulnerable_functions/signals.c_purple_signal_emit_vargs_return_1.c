void *
purple_signal_emit_vargs_return_1(void *instance, const char *signal,
								va_list args)
{
	PurpleInstanceData *instance_data;
	PurpleSignalData *signal_data;
	PurpleSignalHandlerData *handler_data;
	GList *l, *l_next;
	va_list tmp;
	g_return_val_if_fail(instance != NULL, NULL);
	g_return_val_if_fail(signal   != NULL, NULL);
	instance_data =
		(PurpleInstanceData *)g_hash_table_lookup(instance_table, instance);
	g_return_val_if_fail(instance_data != NULL, NULL);
	signal_data =
		(PurpleSignalData *)g_hash_table_lookup(instance_data->signals, signal);
	if (signal_data == NULL)
	{
		purple_debug(PURPLE_DEBUG_ERROR, "signals",
				   "Signal data for %s not found!\n", signal);
		return 0;
	}
#ifdef HAVE_DBUS
	G_VA_COPY(tmp, args);
	purple_dbus_signal_emit_purple(signal, signal_data->num_values,
				   signal_data->values, tmp);
	va_end(tmp);
#endif	/* HAVE_DBUS */
	for (l = signal_data->handlers; l != NULL; l = l_next)
	{
		void *ret_val = NULL;
		l_next = l->next;
		handler_data = (PurpleSignalHandlerData *)l->data;
		G_VA_COPY(tmp, args);
		if (handler_data->use_vargs)
		{
			ret_val = ((void *(*)(va_list, void *))handler_data->cb)(
				tmp, handler_data->data);
		}
		else
		{
			signal_data->marshal(handler_data->cb, tmp,
								 handler_data->data, &ret_val);
		}
		va_end(tmp);
		if (ret_val != NULL)
			return ret_val;
	}
	return NULL;
}
