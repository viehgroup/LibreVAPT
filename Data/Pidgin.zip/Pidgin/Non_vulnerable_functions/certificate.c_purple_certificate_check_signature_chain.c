gboolean
purple_certificate_check_signature_chain(GList *chain)
{
	return purple_certificate_check_signature_chain_with_failing(chain, NULL);
}
