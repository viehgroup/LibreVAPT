const char *
purple_pounce_action_get_attribute(const PurplePounce *pounce,
								 const char *action, const char *attr)
{
	PurplePounceActionData *action_data;
	g_return_val_if_fail(pounce != NULL, NULL);
	g_return_val_if_fail(action != NULL, NULL);
	g_return_val_if_fail(attr   != NULL, NULL);
	action_data = find_action_data(pounce, action);
	g_return_val_if_fail(action_data != NULL, NULL);
	return g_hash_table_lookup(action_data->atts, attr);
}
