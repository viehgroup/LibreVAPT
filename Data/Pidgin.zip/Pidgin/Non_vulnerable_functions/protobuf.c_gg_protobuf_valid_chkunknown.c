}
int gg_protobuf_valid_chkunknown(struct gg_session *gs, const char *msg_name,
	ProtobufCMessage *base)
{
	if (base->n_unknown_fields > 0) {
		gg_debug_session(gs, GG_DEBUG_WARNING, "// gg_protobuf: message"
		" %s had %d unknown field(s)\n",
		msg_name, base->n_unknown_fields);
	}
	return 1;
}
