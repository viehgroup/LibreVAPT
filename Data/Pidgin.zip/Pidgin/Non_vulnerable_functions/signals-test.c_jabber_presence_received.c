static gboolean
jabber_presence_received(PurpleConnection *pc, const char *type,
                         const char *from, xmlnode *presence)
{
	purple_debug_misc("signals test", "jabber presence (type=%s, from=%s) %p\n",
	                  type ? type : "(null)", from ? from : "(null)", presence);
	/* We don't want the plugin to stop processing */
	return FALSE;
}
