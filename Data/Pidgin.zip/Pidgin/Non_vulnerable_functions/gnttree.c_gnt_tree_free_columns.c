static void
gnt_tree_free_columns(GntTree *tree)
{
	int i;
	for (i = 0; i < tree->ncol; i++) {
		g_free(tree->columns[i].title);
	}
	g_free(tree->columns);
}
