}
size_t gg110_access_info__pack_to_buffer
                     (const GG110AccessInfo *message,
                      ProtobufCBuffer *buffer)
{
  assert(message->base.descriptor == &gg110_access_info__descriptor);
  return protobuf_c_message_pack_to_buffer ((const ProtobufCMessage*)message, buffer);
}
