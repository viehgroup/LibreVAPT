#include "mono-glue.h"
MonoObject* purple_blist_get_handle_glue(void)
{
	void *handle = purple_blist_get_handle();
	return mono_value_box(ml_get_domain(), mono_get_intptr_class(), &handle);
}
