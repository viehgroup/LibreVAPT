static void
global_moods_for_each(gpointer key, gpointer value, gpointer user_data)
{
	GList **out_moods = (GList **) user_data;
	PurpleMood *mood = (PurpleMood *) value;
	*out_moods = g_list_append(*out_moods, mood);
}
