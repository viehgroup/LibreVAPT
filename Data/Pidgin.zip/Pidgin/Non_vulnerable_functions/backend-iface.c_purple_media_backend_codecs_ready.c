gboolean
purple_media_backend_codecs_ready(PurpleMediaBackend *self,
		const gchar *sess_id)
{
	g_return_val_if_fail(PURPLE_IS_MEDIA_BACKEND(self), FALSE);
	return PURPLE_MEDIA_BACKEND_GET_INTERFACE(self)->codecs_ready(self,
			sess_id);
}
