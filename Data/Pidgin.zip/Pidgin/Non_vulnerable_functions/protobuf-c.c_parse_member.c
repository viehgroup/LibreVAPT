static protobuf_c_boolean
parse_member(ScannedMember *scanned_member,
	     ProtobufCMessage *message,
	     ProtobufCAllocator *allocator)
{
	const ProtobufCFieldDescriptor *field = scanned_member->field;
	void *member;
	if (field == NULL) {
		ProtobufCMessageUnknownField *ufield =
			message->unknown_fields +
			(message->n_unknown_fields++);
		ufield->tag = scanned_member->tag;
		ufield->wire_type = scanned_member->wire_type;
		ufield->len = scanned_member->len;
		ufield->data = do_alloc(allocator, scanned_member->len);
		if (ufield->data == NULL)
			return FALSE;
		memcpy(ufield->data, scanned_member->data, ufield->len);
		return TRUE;
	}
	member = (char *) message + field->offset;
	switch (field->label) {
	case PROTOBUF_C_LABEL_REQUIRED:
		return parse_required_member(scanned_member, member,
					     allocator, TRUE);
	case PROTOBUF_C_LABEL_OPTIONAL:
		return parse_optional_member(scanned_member, member,
					     message, allocator);
	case PROTOBUF_C_LABEL_REPEATED:
		if (scanned_member->wire_type ==
		    PROTOBUF_C_WIRE_TYPE_LENGTH_PREFIXED &&
		    (0 != (field->flags & PROTOBUF_C_FIELD_FLAG_PACKED) ||
		     is_packable_type(field->type)))
		{
			return parse_packed_repeated_member(scanned_member,
							    member, message);
		} else {
			return parse_repeated_member(scanned_member,
						     member, message,
						     allocator);
		}
	}
	PROTOBUF_C__ASSERT_NOT_REACHED();
	return 0;
}
