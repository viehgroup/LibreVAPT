}
aim_userinfo_t *aim_locate_finduserinfo(OscarData *od, const char *bn) {
	aim_userinfo_t *cur = NULL;
	if (bn == NULL)
		return NULL;
	cur = od->locate.userinfo;
	while (cur != NULL) {
		if (oscar_util_name_compare(cur->bn, bn) == 0)
			return cur;
		cur = cur->next;
	}
	return NULL;
}
