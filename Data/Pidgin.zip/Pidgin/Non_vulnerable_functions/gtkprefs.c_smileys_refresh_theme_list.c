static void
smileys_refresh_theme_list(void)
{
	GdkPixbuf *pixbuf;
	GSList *themes;
	GtkTreeIter iter;
	pidgin_themes_smiley_theme_probe();
	if (!(themes = smiley_themes))
		return;
	while (themes) {
		struct smiley_theme *theme = themes->data;
		char *description = get_theme_markup(_(theme->name), FALSE,
		                                     _(theme->author), _(theme->desc));
		gtk_list_store_append(prefs_smiley_themes, &iter);
		/*
		 * LEAK - Gentoo memprof thinks pixbuf is leaking here... but it
		 * looks like it should be ok to me.  Anyone know what's up?  --Mark
		 */
		pixbuf = (theme->icon ? pidgin_pixbuf_new_from_file(theme->icon) : NULL);
		gtk_list_store_set(prefs_smiley_themes, &iter,
				   0, pixbuf,
				   1, description,
				   2, theme->name,
				   -1);
		if (pixbuf != NULL)
			g_object_unref(G_OBJECT(pixbuf));
		g_free(description);
		themes = themes->next;
	}
}
