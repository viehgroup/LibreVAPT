}
void purple_buddy_set_media_caps(PurpleBuddy *buddy, PurpleMediaCaps media_caps)
{
	g_return_if_fail(buddy != NULL);
	buddy->media_caps = media_caps;
}
