static void
jingle_content_set_property (GObject *object, guint prop_id, const GValue *value, GParamSpec *pspec)
{
	JingleContent *content;
	g_return_if_fail(object != NULL);
	g_return_if_fail(JINGLE_IS_CONTENT(object));
	content = JINGLE_CONTENT(object);
	switch (prop_id) {
		case PROP_SESSION:
			content->priv->session = g_value_get_object(value);
			break;
		case PROP_CREATOR:
			g_free(content->priv->creator);
			content->priv->creator = g_value_dup_string(value);
			break;
		case PROP_DISPOSITION:
			g_free(content->priv->disposition);
			content->priv->disposition = g_value_dup_string(value);
			break;
		case PROP_NAME:
			g_free(content->priv->name);
			content->priv->name = g_value_dup_string(value);
			break;
		case PROP_SENDERS:
			g_free(content->priv->senders);
			content->priv->senders = g_value_dup_string(value);
			break;
		case PROP_TRANSPORT:
			if (content->priv->transport)
				g_object_unref(content->priv->transport);
			content->priv->transport = g_value_get_object(value);
			break;
		case PROP_PENDING_TRANSPORT:
			if (content->priv->pending_transport)
				g_object_unref(content->priv->pending_transport);
			content->priv->pending_transport = g_value_get_object(value);
			break;
		default:
			G_OBJECT_WARN_INVALID_PROPERTY_ID (object, prop_id, pspec);
			break;
	}
}
