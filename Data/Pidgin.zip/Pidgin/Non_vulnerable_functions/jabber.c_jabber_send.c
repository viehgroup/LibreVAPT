}
void jabber_send(JabberStream *js, xmlnode *packet)
{
	purple_signal_emit(purple_connection_get_prpl(js->gc), "jabber-sending-xmlnode", js->gc, &packet);
}
