}
static void sendlater(PurpleConnection *gc, const char *buf) {
	struct simple_account_data *sip = gc->proto_data;
	if(!sip->connecting) {
		purple_debug_info("simple", "connecting to %s port %d\n", sip->realhostname ? sip->realhostname : "{NULL}", sip->realport);
		if (purple_proxy_connect(gc, sip->account, sip->realhostname, sip->realport, send_later_cb, gc) == NULL) {
			purple_connection_error_reason(gc, PURPLE_CONNECTION_ERROR_NETWORK_ERROR, _("Unable to connect"));
		}
		sip->connecting = TRUE;
	}
	if(purple_circ_buffer_get_max_read(sip->txbuf) > 0)
		purple_circ_buffer_append(sip->txbuf, "\r\n", 2);
	purple_circ_buffer_append(sip->txbuf, buf, strlen(buf));
}
