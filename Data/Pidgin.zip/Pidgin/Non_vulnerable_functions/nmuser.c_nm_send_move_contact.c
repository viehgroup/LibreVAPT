NMERR_T
nm_send_move_contact(NMUser * user, NMContact * contact, NMFolder * folder,
					 nm_response_cb callback, gpointer data)
{
	NMERR_T rc = NM_OK;
	NMField *field = NULL, *fields = NULL, *list = NULL;
	NMRequest *req = NULL;
	if (user == NULL || contact == NULL || folder == NULL)
		return NMERR_BAD_PARM;
	/* Create field list for the contact */
	field = nm_contact_to_fields(contact);
	if (field) {
		fields = nm_field_add_pointer(fields, NM_A_FA_CONTACT, 0, NMFIELD_METHOD_DELETE, 0,
									  field, NMFIELD_TYPE_ARRAY);
		field = NULL;
		/* Wrap the contact up and add it to the request field list */
		list = nm_field_add_pointer(list, NM_A_FA_CONTACT_LIST, 0, NMFIELD_METHOD_VALID, 0,
									fields, NMFIELD_TYPE_ARRAY);
		fields = NULL;
		/* Add sequence number */
		list = nm_field_add_pointer(list, NM_A_SZ_SEQUENCE_NUMBER, 0, NMFIELD_METHOD_VALID,
									0, g_strdup("-1"), NMFIELD_TYPE_UTF8);
		/* Add parent ID */
		list = nm_field_add_pointer(list, NM_A_SZ_PARENT_ID, 0, NMFIELD_METHOD_VALID, 0,
									g_strdup_printf("%d",  nm_folder_get_id(folder)),
									NMFIELD_TYPE_UTF8);
		/* Dispatch the request */
		rc = nm_send_request(user->conn, "movecontact", list, callback, data, &req);
		if (rc == NM_OK && req)
			nm_request_set_data(req, contact);
	}
	if (req)
		nm_release_request(req);
	if (list)
		nm_free_fields(&list);
	return rc;
}
