/* netdb.h */
struct hostent* wpurple_gethostbyname(const char *name) {
	struct hostent *hp;
	if((hp = gethostbyname(name)) == NULL) {
		errno = WSAGetLastError();
		return NULL;
	}
	return hp;
}
