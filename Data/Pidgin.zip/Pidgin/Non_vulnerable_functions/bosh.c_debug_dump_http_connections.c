static void
debug_dump_http_connections(PurpleBOSHConnection *conn)
{
	int i;
	g_return_if_fail(conn != NULL);
	for (i = 0; i < NUM_HTTP_CONNECTIONS; ++i) {
		PurpleHTTPConnection *httpconn = conn->connections[i];
		if (httpconn == NULL)
			purple_debug_misc("jabber", "BOSH %p->connections[%d] = (nil)\n",
			                  conn, i);
		else
			purple_debug_misc("jabber", "BOSH %p->connections[%d] = %p, state = %d"
			                  ", requests = %d\n", conn, i, httpconn,
			                  httpconn->state, httpconn->requests);
	}
}
