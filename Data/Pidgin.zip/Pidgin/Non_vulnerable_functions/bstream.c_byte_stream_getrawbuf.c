}
int byte_stream_getrawbuf(ByteStream *bs, guint8 *buf, size_t len)
{
	g_return_val_if_fail(byte_stream_bytes_left(bs) >= len, 0);
	byte_stream_getrawbuf_nocheck(bs, buf, len);
	return len;
}
