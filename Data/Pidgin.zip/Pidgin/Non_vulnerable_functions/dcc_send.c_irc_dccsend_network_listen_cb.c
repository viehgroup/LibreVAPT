static void
irc_dccsend_network_listen_cb(int sock, gpointer data)
{
	PurpleXfer *xfer = data;
	struct irc_xfer_send_data *xd;
	PurpleConnection *gc;
	struct irc_conn *irc;
	const char *arg[2];
	char *tmp;
	struct in_addr addr;
	unsigned short int port;
	xd = xfer->data;
	xd->listen_data = NULL;
	if (purple_xfer_get_status(xfer) == PURPLE_XFER_STATUS_CANCEL_LOCAL
			|| purple_xfer_get_status(xfer) == PURPLE_XFER_STATUS_CANCEL_REMOTE) {
		purple_xfer_unref(xfer);
		return;
	}
	xd = xfer->data;
	gc = purple_account_get_connection(purple_xfer_get_account(xfer));
	irc = gc->proto_data;
	purple_xfer_unref(xfer);
	if (sock < 0) {
		purple_notify_error(gc, NULL, _("File Transfer Failed"),
		                    _("Unable to open a listening port."));
		purple_xfer_cancel_local(xfer);
		return;
	}
	xd->fd = sock;
	port = purple_network_get_port_from_fd(sock);
	purple_debug_misc("irc", "port is %hu\n", port);
	/* Monitor the listening socket */
	xfer->watcher = purple_input_add(sock, PURPLE_INPUT_READ,
	                                 irc_dccsend_send_connected, xfer);
	/* Send the intended recipient the DCC request */
	arg[0] = xfer->who;
	inet_aton(purple_network_get_my_ip(irc->fd), &addr);
	arg[1] = tmp = g_strdup_printf("\001DCC SEND \"%s\" %u %hu %" G_GSIZE_FORMAT "\001",
	                               xfer->filename, ntohl(addr.s_addr),
	                               port, xfer->size);
	irc_cmd_privmsg(gc->proto_data, "msg", NULL, arg);
	g_free(tmp);
}
