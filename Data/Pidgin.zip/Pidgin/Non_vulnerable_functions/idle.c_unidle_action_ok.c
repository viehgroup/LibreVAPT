static void
unidle_action_ok(void *ignored, PurpleRequestFields *fields)
{
	PurpleAccount *acct = purple_request_fields_get_account(fields, "acct");
	set_idle_time(acct, 0); /* unidle the account */
	/* once the account has been unidled it shouldn't be in the list */
	idled_accts = g_list_remove(idled_accts, acct);
}
