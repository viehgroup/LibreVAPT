NMERR_T
nm_send_rename_contact(NMUser * user, NMContact * contact,
					   const char *new_name, nm_response_cb callback,
					   gpointer data)
{
	NMERR_T rc = NM_OK;
	NMField *field = NULL, *fields = NULL, *list = NULL;
	NMRequest *req = NULL;
	if (user == NULL || contact == NULL || new_name == NULL)
		return NMERR_BAD_PARM;
	/* Create field list for current contact */
	field = nm_contact_to_fields(contact);
	if (field) {
		fields =
			nm_field_add_pointer(fields, NM_A_FA_CONTACT, 0, NMFIELD_METHOD_DELETE, 0,
								 field, NMFIELD_TYPE_ARRAY);
		field = NULL;
		/* Update the contacts display name locally */
		nm_contact_set_display_name(contact, new_name);
		/* Create field list for updated contact */
		field = nm_contact_to_fields(contact);
		if (field) {
			fields =
				nm_field_add_pointer(fields, NM_A_FA_CONTACT, 0, NMFIELD_METHOD_ADD, 0,
									 field, NMFIELD_TYPE_ARRAY);
			field = NULL;
			/* Package it up */
			list =
				nm_field_add_pointer(list, NM_A_FA_CONTACT_LIST, 0, NMFIELD_METHOD_VALID,
									 0, fields, NMFIELD_TYPE_ARRAY);
			fields = NULL;
			rc = nm_send_request(user->conn, "updateitem", list, callback, data, &req);
			if (rc == NM_OK && req)
				nm_request_set_data(req, contact);
		}
	}
	if (req)
		nm_release_request(req);
	if (list)
		nm_free_fields(&list);
	return rc;
}
