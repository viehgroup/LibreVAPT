static void
pidgin_status_box_size_allocate(GtkWidget *widget,
				  GtkAllocation *allocation)
{
	PidginStatusBox *status_box = PIDGIN_STATUS_BOX(widget);
	GtkRequisition req = {0,0};
	GtkAllocation parent_alc, box_alc, icon_alc;
	gint border_width = GTK_CONTAINER (widget)->border_width;
	gtk_widget_size_request(status_box->toggle_button, &req);
	/* Make this icon the same size as other buddy icons in the list; unless it already wants to be bigger */
	req.height = MAX(req.height, 34);
	req.height += border_width * 2;
	box_alc = *allocation;
	box_alc.width -= (border_width * 2);
	box_alc.height = MAX(1, ((allocation->height - req.height) - (border_width*2)));
	box_alc.x += border_width;
	box_alc.y += req.height + border_width;
	gtk_widget_size_allocate(status_box->vbox, &box_alc);
	parent_alc = *allocation;
	parent_alc.height = MAX(1,req.height - (border_width *2));
	parent_alc.width -= (border_width * 2);
	parent_alc.x += border_width;
	parent_alc.y += border_width;
	if (status_box->icon_box)
	{
		parent_alc.width -= (parent_alc.height + border_width);
		icon_alc = parent_alc;
		icon_alc.height = MAX(1, icon_alc.height) - 2;
		icon_alc.width = icon_alc.height;
		icon_alc.x += allocation->width - (icon_alc.width + border_width + 1);
		icon_alc.y += 1;
		if (status_box->icon_size != icon_alc.height)
		{
			status_box->icon_size = icon_alc.height;
			pidgin_status_box_redisplay_buddy_icon(status_box);
		}
		gtk_widget_size_allocate(status_box->icon_box, &icon_alc);
	}
	gtk_widget_size_allocate(status_box->toggle_button, &parent_alc);
	widget->allocation = *allocation;
}
