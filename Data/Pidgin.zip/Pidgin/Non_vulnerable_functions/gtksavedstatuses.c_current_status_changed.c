static void
current_status_changed(PurpleSavedStatus *old, PurpleSavedStatus *new_status,
		StatusWindow *dialog)
{
	status_selected_cb(gtk_tree_view_get_selection(GTK_TREE_VIEW(dialog->treeview)), dialog);
}
