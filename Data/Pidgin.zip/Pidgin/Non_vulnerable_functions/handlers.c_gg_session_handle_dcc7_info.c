 */
static int gg_session_handle_dcc7_info(struct gg_session *gs, uint32_t type,
	const char *ptr, size_t len, struct gg_event *ge)
{
	gg_debug_session(gs, GG_DEBUG_MISC, "// gg_watch_fd_connected() received dcc7 info\n");
	return gg_dcc7_handle_info(gs, ge, ptr, len);
}
