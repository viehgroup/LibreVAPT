}
void finch_log_show_contact(PurpleContact *contact)
{
	struct log_viewer_hash_t *ht;
	PurpleBlistNode *child;
	FinchLogViewer *lv = NULL;
	GList *logs = NULL;
	const char *name = NULL;
	char *title;
	int total_log_size = 0;
	g_return_if_fail(contact != NULL);
	ht = g_new0(struct log_viewer_hash_t, 1);
	ht->type = PURPLE_LOG_IM;
	ht->contact = contact;
	if (log_viewers == NULL) {
		log_viewers = g_hash_table_new(log_viewer_hash, log_viewer_equal);
	} else if ((lv = g_hash_table_lookup(log_viewers, ht))) {
		gnt_window_present(lv->window);
		g_free(ht);
		return;
	}
	for (child = purple_blist_node_get_first_child((PurpleBlistNode*)contact); child;
			child = purple_blist_node_get_sibling_next(child)) {
		const char *name;
		PurpleAccount *account;
		if (!PURPLE_BLIST_NODE_IS_BUDDY(child))
			continue;
		name = purple_buddy_get_name((PurpleBuddy *)child);
		account = purple_buddy_get_account((PurpleBuddy *)child);
		logs = g_list_concat(purple_log_get_logs(PURPLE_LOG_IM, name,
						account), logs);
		total_log_size += purple_log_get_total_size(PURPLE_LOG_IM, name, account);
	}
	logs = g_list_sort(logs, purple_log_compare);
	name = purple_contact_get_alias(contact);
	if (!name)
		name = purple_buddy_get_contact_alias(purple_contact_get_priority_buddy(contact));
	/* This will happen if the contact doesn't have an alias,
	 * and none of the contact's buddies are online.
	 * There is probably a better way to deal with this. */
	if (name == NULL) {
		child = purple_blist_node_get_first_child((PurpleBlistNode*)contact);
		if (child != NULL && PURPLE_BLIST_NODE_IS_BUDDY(child))
			name = purple_buddy_get_contact_alias((PurpleBuddy *)child);
		if (name == NULL)
			name = "";
	}
	title = g_strdup_printf(_("Conversations with %s"), name);
	display_log_viewer(ht, logs, title, total_log_size);
	g_free(title);
}
