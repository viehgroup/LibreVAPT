PurpleStoredImage *
purple_imgstore_unref(PurpleStoredImage *img)
{
	if (img == NULL)
		return NULL;
	g_return_val_if_fail(img->refcount > 0, NULL);
	img->refcount--;
	if (img->refcount == 0)
	{
		purple_signal_emit(purple_imgstore_get_handle(),
		                   "image-deleting", img);
		if (img->id)
			g_hash_table_remove(imgstore, &img->id);
		g_free(img->data);
		g_free(img->filename);
		PURPLE_DBUS_UNREGISTER_POINTER(img);
		g_free(img);
		img = NULL;
	}
	return img;
}
