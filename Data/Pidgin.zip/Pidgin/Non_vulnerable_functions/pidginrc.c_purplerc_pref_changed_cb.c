static void
purplerc_pref_changed_cb(const char *name, PurplePrefType type,
                         gconstpointer value, gpointer data)
{
	purplerc_make_changes();
}
