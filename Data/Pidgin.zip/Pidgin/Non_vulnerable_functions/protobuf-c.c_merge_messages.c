static protobuf_c_boolean
merge_messages(ProtobufCMessage *earlier_msg,
	       ProtobufCMessage *latter_msg,
	       ProtobufCAllocator *allocator)
{
	unsigned i;
	const ProtobufCFieldDescriptor *fields =
		earlier_msg->descriptor->fields;
	for (i = 0; i < latter_msg->descriptor->n_fields; i++) {
		if (fields[i].label == PROTOBUF_C_LABEL_REPEATED) {
			size_t *n_earlier =
				STRUCT_MEMBER_PTR(size_t, earlier_msg,
						  fields[i].quantifier_offset);
			uint8_t **p_earlier =
				STRUCT_MEMBER_PTR(uint8_t *, earlier_msg,
						  fields[i].offset);
			size_t *n_latter =
				STRUCT_MEMBER_PTR(size_t, latter_msg,
						  fields[i].quantifier_offset);
			uint8_t **p_latter =
				STRUCT_MEMBER_PTR(uint8_t *, latter_msg,
						  fields[i].offset);
			if (*n_earlier > 0) {
				if (*n_latter > 0) {
					/* Concatenate the repeated field */
					size_t el_size =
						sizeof_elt_in_repeated_array(fields[i].type);
					uint8_t *new_field;
					new_field = do_alloc(allocator,
						(*n_earlier + *n_latter) * el_size);
					if (!new_field)
						return FALSE;
					memcpy(new_field, *p_earlier,
					       *n_earlier * el_size);
					memcpy(new_field +
					       *n_earlier * el_size,
					       *p_latter,
					       *n_latter * el_size);
					do_free(allocator, *p_latter);
					do_free(allocator, *p_earlier);
					*p_latter = new_field;
					*n_latter = *n_earlier + *n_latter;
				} else {
					/* Zero copy the repeated field from the earlier message */
					*n_latter = *n_earlier;
					*p_latter = *p_earlier;
				}
				/* Make sure the field does not get double freed */
				*n_earlier = 0;
				*p_earlier = 0;
			}
		} else if (fields[i].type == PROTOBUF_C_TYPE_MESSAGE) {
			ProtobufCMessage **em =
				STRUCT_MEMBER_PTR(ProtobufCMessage *,
						  earlier_msg,
						  fields[i].offset);
			ProtobufCMessage **lm =
				STRUCT_MEMBER_PTR(ProtobufCMessage *,
						  latter_msg,
						  fields[i].offset);
			if (*em != NULL) {
				if (*lm != NULL) {
					if (!merge_messages
					    (*em, *lm, allocator))
						return FALSE;
				} else {
					/* Zero copy the optional message */
					assert(fields[i].label ==
					       PROTOBUF_C_LABEL_OPTIONAL);
					*lm = *em;
					*em = NULL;
				}
			}
		} else if (fields[i].label == PROTOBUF_C_LABEL_OPTIONAL) {
			size_t el_size = 0;
			protobuf_c_boolean need_to_merge = FALSE;
			void *earlier_elem =
				STRUCT_MEMBER_P(earlier_msg, fields[i].offset);
			void *latter_elem =
				STRUCT_MEMBER_P(latter_msg, fields[i].offset);
			const void *def_val = fields[i].default_value;
			switch (fields[i].type) {
			case PROTOBUF_C_TYPE_BYTES: {
				uint8_t *e_data =
					((ProtobufCBinaryData *) earlier_elem)->data;
				uint8_t *l_data =
					((ProtobufCBinaryData *) latter_elem)->data;
				const ProtobufCBinaryData *d_bd =
					(ProtobufCBinaryData *) def_val;
				el_size = sizeof(ProtobufCBinaryData);
				need_to_merge =
					(e_data != NULL &&
					 (d_bd != NULL &&
					  e_data != d_bd->data)) &&
					(l_data == NULL ||
					 (d_bd != NULL &&
					  l_data == d_bd->data));
				break;
			}
			case PROTOBUF_C_TYPE_STRING: {
				char *e_str = *(char **) earlier_elem;
				char *l_str = *(char **) latter_elem;
				const char *d_str = def_val;
				el_size = sizeof(char *);
				need_to_merge = e_str != d_str && l_str == d_str;
				break;
			}
			default: {
				el_size = sizeof_elt_in_repeated_array(fields[i].type);
				need_to_merge =
					STRUCT_MEMBER(protobuf_c_boolean,
						      earlier_msg,
						      fields[i].quantifier_offset) &&
					!STRUCT_MEMBER(protobuf_c_boolean,
						       latter_msg,
						       fields[i].quantifier_offset);
				break;
			}
			}
			if (need_to_merge) {
				memcpy(latter_elem, earlier_elem, el_size);
				/*
				 * Reset the element from the old message to 0
				 * to make sure earlier message deallocation
				 * doesn't corrupt zero-copied data in the new
				 * message, earlier message will be freed after
				 * this function is called anyway
				 */
				memset(earlier_elem, 0, el_size);
				if (fields[i].quantifier_offset != 0) {
					/* Set the has field, if applicable */
					STRUCT_MEMBER(protobuf_c_boolean,
						      latter_msg,
						      fields[i].
						      quantifier_offset) = TRUE;
					STRUCT_MEMBER(protobuf_c_boolean,
						      earlier_msg,
						      fields[i].
						      quantifier_offset) = FALSE;
				}
			}
		}
	}
	return TRUE;
}
