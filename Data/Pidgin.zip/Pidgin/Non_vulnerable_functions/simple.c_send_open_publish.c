}
static void send_open_publish(struct simple_account_data *sip) {
	gchar *add_headers = NULL;
	gchar *uri = g_strdup_printf("sip:%s@%s", sip->username, sip->servername);
	gchar *doc = gen_pidf(sip, TRUE);
	add_headers = g_strdup_printf("%s%s%s%s%d\r\n%s",
		sip->publish_etag ? "SIP-If-Match: " : "",
		sip->publish_etag ? sip->publish_etag : "",
		sip->publish_etag ? "\r\n" : "",
		"Expires: ", PUBLISH_EXPIRATION,
		"Event: presence\r\n"
		"Content-Type: application/pidf+xml\r\n");
	send_sip_request(sip->gc, "PUBLISH", uri, uri,
		add_headers, doc, NULL, process_publish_response);
	sip->republish = time(NULL) + PUBLISH_EXPIRATION - 50;
	g_free(uri);
	g_free(doc);
	g_free(add_headers);
}
