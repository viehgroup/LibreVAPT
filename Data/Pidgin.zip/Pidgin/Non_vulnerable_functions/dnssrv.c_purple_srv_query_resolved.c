static void
purple_srv_query_resolved(PurpleSrvTxtQueryData *query_data, GList *records)
{
	GList *l;
	PurpleSrvResponse *records_array;
	int i = 0, length;
	g_return_if_fail(records != NULL);
	if (query_data->cb.srv == NULL) {
		purple_srv_txt_query_destroy(query_data);
		while (records) {
			g_free(records->data);
			records = g_list_delete_link(records, records);
		}
		return;
	}
	records = purple_srv_sort(records);
	length = g_list_length(records);
	purple_debug_info("dnssrv", "SRV records resolved for %s, count: %d\n",
	                            query_data->query, length);
	records_array = g_new(PurpleSrvResponse, length);
	for (l = records; l; l = l->next, i++) {
		records_array[i] = *(PurpleSrvResponse *)l->data;
	}
	query_data->cb.srv(records_array, length, query_data->extradata);
	purple_srv_txt_query_destroy(query_data);
	while (records) {
		g_free(records->data);
		records = g_list_delete_link(records, records);
	}
}
