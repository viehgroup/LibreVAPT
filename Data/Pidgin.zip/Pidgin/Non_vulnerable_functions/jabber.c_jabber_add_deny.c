}
void jabber_add_deny(PurpleConnection *gc, const char *who)
{
	JabberStream *js;
	JabberIq *iq;
	xmlnode *block, *item;
	g_return_if_fail(who != NULL && *who != '\0');
	js = purple_connection_get_protocol_data(gc);
	if (js == NULL)
		return;
	if (js->server_caps & JABBER_CAP_GOOGLE_ROSTER)
	{
		jabber_google_roster_add_deny(js, who);
		return;
	}
	if (!(js->server_caps & JABBER_CAP_BLOCKING))
	{
		purple_notify_error(NULL, _("Server doesn't support blocking"),
							_("Server doesn't support blocking"), NULL);
		return;
	}
	iq = jabber_iq_new(js, JABBER_IQ_SET);
	block = xmlnode_new_child(iq->node, "block");
	xmlnode_set_namespace(block, NS_SIMPLE_BLOCKING);
	item = xmlnode_new_child(block, "item");
	xmlnode_set_attrib(item, "jid", who);
	jabber_iq_send(iq);
}
