static PurpleCmdRet
jabber_cmd_mood(PurpleConversation *conv,
		const char *cmd, char **args, char **error, void *data)
{
	JabberStream *js = conv->account->gc->proto_data;
	if (js->pep) {
		/* if no argument was given, unset mood */
		if (!args || !args[0]) {
			jabber_mood_set(js, NULL, NULL);
		} else if (!args[1]) {
			jabber_mood_set(js, args[0], NULL);
		} else {
			jabber_mood_set(js, args[0], args[1]);
		}
		return PURPLE_CMD_RET_OK;
	} else {
		/* account does not support PEP, can't set a mood */
		purple_conversation_write(conv, NULL,
		    _("Account does not support PEP, can't set mood"),
		    PURPLE_MESSAGE_ERROR, time(NULL));
		return PURPLE_CMD_RET_FAILED;
	}
}
