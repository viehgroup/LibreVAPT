}
void gnt_wm_set_event_stack(GntWM *wm, gboolean set)
{
	wm->event_stack = set;
}
