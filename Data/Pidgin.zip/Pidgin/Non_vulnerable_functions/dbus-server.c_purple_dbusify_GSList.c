dbus_int32_t *
purple_dbusify_GSList(GSList *list, gboolean free_memory, dbus_int32_t *len)
{
	dbus_int32_t *array;
	int i;
	GSList *elem;
	*len = g_slist_length(list);
	array = g_new0(dbus_int32_t, *len);
	for (i = 0, elem = list; elem != NULL; elem = elem->next, i++)
		array[i] = purple_dbus_pointer_to_id(elem->data);
	if (free_memory)
		g_slist_free(list);
	return array;
}
