PurpleBuddyIcon *
purple_buddy_icons_find(PurpleAccount *account, const char *username)
{
	GHashTable *icon_cache;
	PurpleBuddyIcon *icon = NULL;
	g_return_val_if_fail(account  != NULL, NULL);
	g_return_val_if_fail(username != NULL, NULL);
	icon_cache = g_hash_table_lookup(account_cache, account);
	if ((icon_cache == NULL) || ((icon = g_hash_table_lookup(icon_cache, username)) == NULL))
	{
		PurpleBuddy *b = purple_find_buddy(account, username);
		const char *protocol_icon_file;
		const char *dirname;
		gboolean caching;
		guchar *data;
		size_t len;
		if (!b)
			return NULL;
		protocol_icon_file = purple_blist_node_get_string((PurpleBlistNode*)b, "buddy_icon");
		if (protocol_icon_file == NULL)
			return NULL;
		dirname = purple_buddy_icons_get_cache_dir();
		caching = purple_buddy_icons_is_caching();
		/* By disabling caching temporarily, we avoid a loop
		 * and don't have to add special code through several
		 * functions. */
		purple_buddy_icons_set_caching(FALSE);
		if (protocol_icon_file != NULL)
		{
			char *path = g_build_filename(dirname, protocol_icon_file, NULL);
			if (read_icon_file(path, &data, &len))
			{
				const char *checksum;
				icon = purple_buddy_icon_create(account, username);
				icon->img = NULL;
				checksum = purple_blist_node_get_string((PurpleBlistNode*)b, "icon_checksum");
				purple_buddy_icon_set_data(icon, data, len, checksum);
			}
			else
				delete_buddy_icon_settings((PurpleBlistNode*)b, "buddy_icon");
			g_free(path);
		}
		purple_buddy_icons_set_caching(caching);
	}
	return (icon ? purple_buddy_icon_ref(icon) : NULL);
}
