static void
pidgin_media_dispose(GObject *media)
{
	PidginMedia *gtkmedia = PIDGIN_MEDIA(media);
	purple_debug_info("gtkmedia", "pidgin_media_dispose\n");
	if (gtkmedia->priv->media) {
		purple_request_close_with_handle(gtkmedia);
		purple_media_remove_output_windows(gtkmedia->priv->media);
		pidgin_media_disconnect_levels(gtkmedia->priv->media, gtkmedia);
		g_object_unref(gtkmedia->priv->media);
		gtkmedia->priv->media = NULL;
	}
	if (gtkmedia->priv->ui) {
		g_object_unref(gtkmedia->priv->ui);
		gtkmedia->priv->ui = NULL;
	}
	if (gtkmedia->priv->timeout_id != 0)
		g_source_remove(gtkmedia->priv->timeout_id);
	if (gtkmedia->priv->recv_progressbars) {
		g_hash_table_destroy(gtkmedia->priv->recv_progressbars);
		g_hash_table_destroy(gtkmedia->priv->remote_videos);
		gtkmedia->priv->recv_progressbars = NULL;
		gtkmedia->priv->remote_videos = NULL;
	}
	G_OBJECT_CLASS(parent_class)->dispose(media);
}
