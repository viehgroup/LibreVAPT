static void
novell_ssl_recv_cb(gpointer data, PurpleSslConnection * gsc,
				   PurpleInputCondition condition)
{
	PurpleConnection *gc = data;
	NMUser *user;
	NMERR_T rc;
	if (gc == NULL)
		return;
	user = gc->proto_data;
	if (user == NULL)
		return;
	rc = nm_process_new_data(user);
	if (rc != NM_OK) {
		if (_is_disconnect_error(rc)) {
			purple_connection_error_reason(gc,
				PURPLE_CONNECTION_ERROR_NETWORK_ERROR,
				_("Error communicating with server. Closing connection."));
		} else {
			purple_debug(PURPLE_DEBUG_INFO, "novell",
					   "Error processing event or response (%d).\n", rc);
		}
	}
}
