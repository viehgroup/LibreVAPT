}
void gnt_text_view_clear(GntTextView *view)
{
	reset_text_view(view);
	g_list_foreach(view->tags, free_tag, NULL);
	view->tags = NULL;
	if (GNT_WIDGET(view)->window)
		gnt_widget_draw(GNT_WIDGET(view));
}
