PidginMiniDialog *
pidgin_mini_dialog_new_with_custom_icon(const gchar *title,
					const gchar *description,
					GdkPixbuf *custom_icon)
{
	PidginMiniDialog *mini_dialog = mini_dialog_new(title, description);
	pidgin_mini_dialog_set_custom_icon(mini_dialog, custom_icon);
	return mini_dialog;
}
