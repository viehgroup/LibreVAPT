const ProtobufCFieldDescriptor *
protobuf_c_message_descriptor_get_field(const ProtobufCMessageDescriptor *desc,
					unsigned value)
{
	int rv = int_range_lookup(desc->n_field_ranges,desc->field_ranges, value);
	if (rv < 0)
		return NULL;
	return desc->fields + rv;
}
