static void
ask_delete_account_sel(GtkTreeModel *model, GtkTreePath *path,
					   GtkTreeIter *iter, gpointer data)
{
	PurpleAccount *account;
	gtk_tree_model_get(model, iter, COLUMN_DATA, &account, -1);
	if (account != NULL) {
		char *buf;
		buf = g_strdup_printf(_("Are you sure you want to delete %s?"),
							  purple_account_get_username(account));
		purple_request_close_with_handle(account);
		purple_request_action(account, NULL, buf, NULL,
							PURPLE_DEFAULT_ACTION_NONE,
							account, NULL, NULL,
							account, 2,
							_("Delete"), delete_account_cb,
							_("Cancel"), NULL);
		g_free(buf);
	}
}
