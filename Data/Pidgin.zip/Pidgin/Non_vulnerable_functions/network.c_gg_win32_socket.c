#undef socket
int gg_win32_socket(int domain, int type, int protocol)
{
	int res;
	res = socket(domain, type, protocol);
	if (res == -1)
		errno = gg_win32_map_wsa_error_to_errno(EAGAIN);
	return res;
}
