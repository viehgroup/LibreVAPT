}
static void url_fetched(PurpleUtilFetchUrlData *url_data, gpointer cb_data,
				const gchar *url_text, gsize len, const gchar *error_message)
{
	CbInfo *data = (CbInfo *)cb_data;
	PurpleConversation *conv = data->conv;
	GList *convs = purple_get_conversations();
	/* ensure the conversation still exists */
	for (; convs; convs = convs->next) {
		if ((PurpleConversation *)(convs->data) == conv) {
			FinchConv *fconv = FINCH_CONV(conv);
			gchar *str = g_strdup_printf("[%d] %s", data->num, url_text);
			GntTextView *tv = GNT_TEXT_VIEW(fconv->tv);
			gnt_text_view_tag_change(tv, data->tag, str, FALSE);
			g_free(str);
			g_free(data->tag);
			g_free(data);
			return;
		}
	}
	g_free(data->tag);
	g_free(data);
	purple_debug_info("TinyURL", "Conversation no longer exists... :(\n");
}
