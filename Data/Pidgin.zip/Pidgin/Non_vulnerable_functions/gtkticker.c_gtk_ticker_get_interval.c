}
guint gtk_ticker_get_interval (GtkTicker *ticker)
{
	g_return_val_if_fail (ticker != NULL, -1);
	g_return_val_if_fail (GTK_IS_TICKER (ticker), -1);
	return ticker->interval;
}
