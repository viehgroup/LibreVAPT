void
oscar_auth_sendrequest_menu(PurpleBlistNode *node, gpointer ignored)
{
	PurpleBuddy *buddy;
	PurpleConnection *gc;
	g_return_if_fail(PURPLE_BLIST_NODE_IS_BUDDY(node));
	buddy = (PurpleBuddy *) node;
	gc = purple_account_get_connection(purple_buddy_get_account(buddy));
	oscar_auth_sendrequest(gc, purple_buddy_get_name(buddy), NULL);
}
