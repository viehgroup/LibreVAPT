} JabberOOBXfer;
static void jabber_oob_xfer_init(PurpleXfer *xfer)
{
	JabberOOBXfer *jox = xfer->data;
	purple_xfer_start(xfer, -1, jox->address, jox->port);
}
