void
pidgin_smiley_editor_set_image(PidginSmiley *editor, GdkPixbuf *image)
{
	if (editor->custom_pixbuf)
		g_object_unref(G_OBJECT(editor->custom_pixbuf));
	editor->custom_pixbuf = image ? g_object_ref(G_OBJECT(image)) : NULL;
	if (image) {
		gtk_image_set_from_pixbuf(GTK_IMAGE(editor->smiley_image), image);
		if (editor->entry_len > 0)
			gtk_dialog_set_response_sensitive(GTK_DIALOG(editor->parent),
			                                  GTK_RESPONSE_ACCEPT, TRUE);
	}
	else
		gtk_dialog_set_response_sensitive(GTK_DIALOG(editor->parent),
		                                  GTK_RESPONSE_ACCEPT, FALSE);
}
