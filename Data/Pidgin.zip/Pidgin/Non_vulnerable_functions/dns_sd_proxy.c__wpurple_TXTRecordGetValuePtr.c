}
const void * _wpurple_TXTRecordGetValuePtr(uint16_t txtLen, const void *txtRecord, const char *key, uint8_t *valueLen) {
	g_return_val_if_fail(_TXTRecordGetValuePtr != NULL, NULL);
	return (_TXTRecordGetValuePtr)(txtLen, txtRecord, key, valueLen);
}
