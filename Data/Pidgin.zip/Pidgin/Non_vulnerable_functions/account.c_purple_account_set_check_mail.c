void
purple_account_set_check_mail(PurpleAccount *account, gboolean value)
{
	g_return_if_fail(account != NULL);
	purple_account_set_bool(account, "check-mail", value);
}
