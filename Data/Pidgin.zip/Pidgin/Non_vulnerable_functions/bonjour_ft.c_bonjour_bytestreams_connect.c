static void
bonjour_bytestreams_connect(PurpleXfer *xfer)
{
	PurpleBuddy *pb;
	PurpleAccount *account = NULL;
	XepXfer *xf;
	char dstaddr[41];
	const gchar *name = NULL;
	unsigned char hashval[20];
	char *p;
	int i;
	if(xfer == NULL)
		return;
	purple_debug_info("bonjour", "bonjour-bytestreams-connect.\n");
	xf = (XepXfer*)xfer->data;
	if(!xf)
		return;
	pb = xf->pb;
	name = purple_buddy_get_name(pb);
	account = purple_buddy_get_account(pb);
	p = g_strdup_printf("%s%s%s", xf->sid, name, bonjour_get_jid(account));
	purple_cipher_digest_region("sha1", (guchar *)p, strlen(p),
				    sizeof(hashval), hashval, NULL);
	g_free(p);
	memset(dstaddr, 0, 41);
	p = dstaddr;
	for(i = 0; i < 20; i++, p += 2)
		snprintf(p, 3, "%02x", hashval[i]);
	xf->proxy_info = purple_proxy_info_new();
	purple_proxy_info_set_type(xf->proxy_info, PURPLE_PROXY_SOCKS5);
	purple_proxy_info_set_host(xf->proxy_info, xf->proxy_host);
	purple_proxy_info_set_port(xf->proxy_info, xf->proxy_port);
	xf->proxy_connection = purple_proxy_connect_socks5_account(
							   purple_account_get_connection(account),
							   account,
							   xf->proxy_info,
							   dstaddr, 0,
							   bonjour_bytestreams_connect_cb, xfer);
	if(xf->proxy_connection == NULL) {
		xep_ft_si_reject(xf->data, xf->iq_id, xfer->who, "404", "cancel");
		/* Cancel the connection */
		purple_xfer_cancel_local(xfer);
	}
}
