static void
sanitize (PurpleDesktopItem *item, const char *uri)
{
	const char *type;
	type = lookup (item, PURPLE_DESKTOP_ITEM_TYPE);
	/* understand old gnome style url exec thingies */
	if (purple_strequal(type, "URL")) {
		const char *exec = lookup (item, PURPLE_DESKTOP_ITEM_EXEC);
		set (item, PURPLE_DESKTOP_ITEM_TYPE, "Link");
		if (exec != NULL) {
			/* Note, this must be in this order */
			set (item, PURPLE_DESKTOP_ITEM_URL, exec);
			set (item, PURPLE_DESKTOP_ITEM_EXEC, NULL);
		}
	}
	/* we make sure we have Name, Encoding and Version */
	if (lookup (item, PURPLE_DESKTOP_ITEM_NAME) == NULL) {
		char *name = try_english_key (item, PURPLE_DESKTOP_ITEM_NAME);
		/* If no name, use the basename */
		if (name == NULL && uri != NULL)
			name = g_path_get_basename (uri);
		/* If no uri either, use same default as gnome_desktop_item_new */
		if (name == NULL)
			name = g_strdup (_("No name"));
		g_hash_table_replace (item->main_hash,
				      g_strdup (PURPLE_DESKTOP_ITEM_NAME),
				      name);
		item->keys = g_list_prepend
			(item->keys, g_strdup (PURPLE_DESKTOP_ITEM_NAME));
	}
	if (lookup (item, PURPLE_DESKTOP_ITEM_ENCODING) == NULL) {
		/* We store everything in UTF-8 so write that down */
		g_hash_table_replace (item->main_hash,
				      g_strdup (PURPLE_DESKTOP_ITEM_ENCODING),
				      g_strdup ("UTF-8"));
		item->keys = g_list_prepend
			(item->keys, g_strdup (PURPLE_DESKTOP_ITEM_ENCODING));
	}
	if (lookup (item, PURPLE_DESKTOP_ITEM_VERSION) == NULL) {
		/* this is the version that we follow, so write it down */
		g_hash_table_replace (item->main_hash,
				      g_strdup (PURPLE_DESKTOP_ITEM_VERSION),
				      g_strdup ("1.0"));
		item->keys = g_list_prepend
			(item->keys, g_strdup (PURPLE_DESKTOP_ITEM_VERSION));
	}
}
