static void*
purple_pmp_get_handle(void)
{
	static int handle;
	return &handle;
}
