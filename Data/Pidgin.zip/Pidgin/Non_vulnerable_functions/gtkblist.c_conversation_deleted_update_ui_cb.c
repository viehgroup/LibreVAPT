static void
conversation_deleted_update_ui_cb(PurpleConversation *conv, struct _pidgin_blist_node *ui)
{
	if (ui->conv.conv != conv)
		return;
	ui->conv.conv = NULL;
	ui->conv.flags = 0;
	ui->conv.last_message = 0;
}
