}
void purple_contact_invalidate_priority_buddy(PurpleContact *contact)
{
	g_return_if_fail(contact != NULL);
	contact->priority_valid = FALSE;
}
