void
pidgin_connection_uninit(void)
{
	purple_signals_disconnect_by_handle(pidgin_connection_get_handle());
	g_hash_table_destroy(auto_reconns);
}
