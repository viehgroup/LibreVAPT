static gboolean
gnt_box_confirm_size(GntWidget *widget, int width, int height)
{
	GList *iter;
	GntBox *box = GNT_BOX(widget);
	int wchange, hchange;
	GntWidget *child, *last;
	if (!box->list)
		return TRUE;
	wchange = widget->priv.width - width;
	hchange = widget->priv.height - height;
	if (wchange == 0 && hchange == 0)
		return TRUE;		/* Quit playing games with my size */
	child = NULL;
	last = g_object_get_data(G_OBJECT(box), PROP_LAST_RESIZE_S);
	/* First, make sure all the widgets will fit into the box after resizing. */
	for (iter = box->list; iter; iter = iter->next) {
		GntWidget *wid = iter->data;
		int w, h;
		gnt_widget_get_size(wid, &w, &h);
		if (wid != last && !child && w > 0 && h > 0 &&
				!GNT_WIDGET_IS_FLAG_SET(wid, GNT_WIDGET_INVISIBLE) &&
				gnt_widget_confirm_size(wid, w - wchange, h - hchange)) {
			child = wid;
			break;
		}
	}
	if (!child && (child = last)) {
		int w, h;
		gnt_widget_get_size(child, &w, &h);
		if (!gnt_widget_confirm_size(child, w - wchange, h - hchange))
			child = NULL;
	}
	g_object_set_data(G_OBJECT(box), PROP_SIZE_QUEUED_S, child);
	if (child) {
		for (iter = box->list; iter; iter = iter->next) {
			GntWidget *wid = iter->data;
			int w, h;
			if (wid == child)
				continue;
			gnt_widget_get_size(wid, &w, &h);
			if (box->vertical) {
				/* For a vertical box, if we are changing the width, make sure the widgets
				 * in the box will fit after resizing the width. */
				if (wchange > 0 &&
						w >= child->priv.width &&
						!gnt_widget_confirm_size(wid, w - wchange, h))
					return FALSE;
			} else {
				/* If we are changing the height, make sure the widgets in the box fit after
				 * the resize. */
				if (hchange > 0 &&
						h >= child->priv.height &&
						!gnt_widget_confirm_size(wid, w, h - hchange))
					return FALSE;
			}
		}
	}
	return (child != NULL);
}
