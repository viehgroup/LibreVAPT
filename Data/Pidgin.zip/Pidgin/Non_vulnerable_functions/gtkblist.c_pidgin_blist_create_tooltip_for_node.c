static gboolean
pidgin_blist_create_tooltip_for_node(GtkWidget *widget, gpointer data, int *w, int *h)
{
	PurpleBlistNode *node = data;
	int width, height;
	GList *list;
	int max_text_width = 0;
	int max_avatar_width = 0;
	int status_size = 0;
	if (gtkblist->tooltipdata) {
		gtkblist->tipwindow = NULL;
		pidgin_blist_destroy_tooltip_data();
	}
	gtkblist->tipwindow = widget;
	if (PURPLE_BLIST_NODE_IS_CHAT(node) ||
	   PURPLE_BLIST_NODE_IS_BUDDY(node)) {
		struct tooltip_data *td = create_tip_for_node(node, TRUE);
		pidgin_blist_align_tooltip(td, gtkblist->tipwindow);
		gtkblist->tooltipdata = g_list_append(gtkblist->tooltipdata, td);
	} else if (PURPLE_BLIST_NODE_IS_GROUP(node)) {
		PurpleGroup *group = (PurpleGroup*)node;
		GSList *accounts;
		struct tooltip_data *td = create_tip_for_node(node, TRUE);
		pidgin_blist_align_tooltip(td, gtkblist->tipwindow);
		gtkblist->tooltipdata = g_list_append(gtkblist->tooltipdata, td);
		/* Accounts with buddies in group */
		accounts = purple_group_get_accounts(group);
		for (; accounts != NULL;
		     accounts = g_slist_delete_link(accounts, accounts)) {
			PurpleAccount *account = accounts->data;
			td = create_tip_for_account(account);
			gtkblist->tooltipdata = g_list_append(gtkblist->tooltipdata, td);
		}
	} else if (PURPLE_BLIST_NODE_IS_CONTACT(node)) {
		PurpleBlistNode *child;
		PurpleBuddy *b = purple_contact_get_priority_buddy((PurpleContact *)node);
		for(child = node->child; child; child = child->next)
		{
			if(PURPLE_BLIST_NODE_IS_BUDDY(child) && buddy_is_displayable((PurpleBuddy*)child)) {
				struct tooltip_data *td = create_tip_for_node(child, (b == (PurpleBuddy*)child));
				pidgin_blist_align_tooltip(td, gtkblist->tipwindow);
				if (b == (PurpleBuddy *)child) {
					gtkblist->tooltipdata = g_list_prepend(gtkblist->tooltipdata, td);
				} else {
					gtkblist->tooltipdata = g_list_append(gtkblist->tooltipdata, td);
				}
			}
		}
	} else {
		return FALSE;
	}
	height = width = 0;
	for (list = gtkblist->tooltipdata; list; list = list->next) {
		struct tooltip_data *td = list->data;
		max_text_width = MAX(max_text_width, MAX(td->width, td->name_width));
		max_avatar_width = MAX(max_avatar_width, td->avatar_width);
		height += MAX(MAX(STATUS_SIZE, td->avatar_height), td->height + td->name_height) + td->padding;
		if (td->status_icon)
			status_size = MAX(status_size, STATUS_SIZE);
	}
	height += TOOLTIP_BORDER;
	width = TOOLTIP_BORDER + status_size + SMALL_SPACE + max_text_width + SMALL_SPACE + max_avatar_width + TOOLTIP_BORDER;
	if (w)
		*w = width;
	if (h)
		*h = height;
	return TRUE;
}
