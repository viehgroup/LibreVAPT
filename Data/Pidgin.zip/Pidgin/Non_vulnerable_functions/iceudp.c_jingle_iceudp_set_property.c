static void
jingle_iceudp_set_property (GObject *object, guint prop_id, const GValue *value, GParamSpec *pspec)
{
	JingleIceUdp *iceudp;
	g_return_if_fail(object != NULL);
	g_return_if_fail(JINGLE_IS_ICEUDP(object));
	iceudp = JINGLE_ICEUDP(object);
	switch (prop_id) {
		case PROP_LOCAL_CANDIDATES:
			iceudp->priv->local_candidates =
					g_value_get_pointer(value);
			break;
		case PROP_REMOTE_CANDIDATES:
			iceudp->priv->remote_candidates =
					g_value_get_pointer(value);
			break;
		default:
			G_OBJECT_WARN_INVALID_PROPERTY_ID (object, prop_id, pspec);
			break;
	}
}
