void
purple_savedstatuses_init(void)
{
	void *handle = purple_savedstatuses_get_handle();
	creation_times = g_hash_table_new(g_direct_hash, g_direct_equal);
	/*
	 * Using 0 as the creation_time is a special case.
	 * If someone calls purple_savedstatus_get_current() or
	 * purple_savedstatus_get_idleaway() and either of those functions
	 * sees a creation_time of 0, then it will create a default
	 * saved status and return that to the user.
	 */
	purple_prefs_add_none("/purple/savedstatus");
	purple_prefs_add_int("/purple/savedstatus/default", 0);
	purple_prefs_add_int("/purple/savedstatus/startup", 0);
	purple_prefs_add_bool("/purple/savedstatus/startup_current_status", TRUE);
	purple_prefs_add_int("/purple/savedstatus/idleaway", 0);
	purple_prefs_add_bool("/purple/savedstatus/isidleaway", FALSE);
	load_statuses();
	purple_signal_register(handle, "savedstatus-changed",
					 purple_marshal_VOID__POINTER_POINTER, NULL, 2,
					 purple_value_new(PURPLE_TYPE_SUBTYPE,
									PURPLE_SUBTYPE_SAVEDSTATUS),
					 purple_value_new(PURPLE_TYPE_SUBTYPE,
									PURPLE_SUBTYPE_SAVEDSTATUS));
	purple_signal_register(handle, "savedstatus-added",
		purple_marshal_VOID__POINTER, NULL, 1,
		purple_value_new(PURPLE_TYPE_SUBTYPE,
			PURPLE_SUBTYPE_SAVEDSTATUS));
	purple_signal_register(handle, "savedstatus-deleted",
		purple_marshal_VOID__POINTER, NULL, 1,
		purple_value_new(PURPLE_TYPE_SUBTYPE,
			PURPLE_SUBTYPE_SAVEDSTATUS));
	purple_signal_register(handle, "savedstatus-modified",
		purple_marshal_VOID__POINTER, NULL, 1,
		purple_value_new(PURPLE_TYPE_SUBTYPE,
			PURPLE_SUBTYPE_SAVEDSTATUS));
	purple_signal_connect(purple_accounts_get_handle(), "account-removed",
			handle,
			PURPLE_CALLBACK(purple_savedstatus_unset_all_substatuses),
			NULL);
}
