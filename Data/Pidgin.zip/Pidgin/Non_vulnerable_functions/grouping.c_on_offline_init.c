					   offline = {.type = PURPLE_BLIST_OTHER_NODE};
static gboolean on_offline_init()
{
	GntTree *tree = finch_blist_get_tree();
	gnt_tree_add_row_after(tree, &online,
			gnt_tree_create_row(tree, _("Online")), NULL, NULL);
	gnt_tree_add_row_after(tree, &offline,
			gnt_tree_create_row(tree, _("Offline")), NULL, &online);
	return TRUE;
}
