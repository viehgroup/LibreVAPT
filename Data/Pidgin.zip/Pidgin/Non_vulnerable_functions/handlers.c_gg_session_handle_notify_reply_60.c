 */
static int gg_session_handle_notify_reply_60(struct gg_session *gs,
	uint32_t type, const char *ptr, size_t len, struct gg_event *ge)
{
	const struct gg_notify_reply60 *n = (const void*) ptr;
	unsigned int length = len, i = 0;
	gg_debug_session(gs, GG_DEBUG_MISC, "// gg_watch_fd_connected() received a notify reply\n");
	ge->type = GG_EVENT_NOTIFY60;
	ge->event.notify60 = malloc(sizeof(*ge->event.notify60));
	if (ge->event.notify60 == NULL) {
		gg_debug_session(gs, GG_DEBUG_MISC, "// gg_watch_fd_connected() out of memory\n");
		return -1;
	}
	ge->event.notify60[0].uin = 0;
	while (length >= sizeof(struct gg_notify_reply60)) {
		uin_t uin = gg_fix32(n->uin);
		void *tmp;
		ge->event.notify60[i].uin = uin & 0x00ffffff;
		ge->event.notify60[i].status = n->status;
		ge->event.notify60[i].remote_ip = n->remote_ip;
		ge->event.notify60[i].remote_port = gg_fix16(n->remote_port);
		ge->event.notify60[i].version = n->version;
		ge->event.notify60[i].image_size = n->image_size;
		ge->event.notify60[i].descr = NULL;
		ge->event.notify60[i].time = 0;
		if (uin & 0x40000000)
			ge->event.notify60[i].version |= GG_HAS_AUDIO_MASK;
		if (uin & 0x08000000)
			ge->event.notify60[i].version |= GG_ERA_OMNIX_MASK;
		if (GG_S_D(n->status)) {
			unsigned char descr_len = *((const char*) n + sizeof(struct gg_notify_reply60));
			if (sizeof(struct gg_notify_reply60) + descr_len <= length) {
				char *descr;
				descr = gg_encoding_convert((const char*) n +
					sizeof(struct gg_notify_reply60) + 1,
					GG_ENCODING_CP1250, gs->encoding,
					descr_len, -1);
				if (descr == NULL) {
					gg_debug_session(gs, GG_DEBUG_MISC,
						"// gg_watch_fd_connected() "
						"out of memory\n");
					return -1;
				}
				ge->event.notify60[i].descr = descr;
				/* XXX czas */
				length -= sizeof(struct gg_notify_reply60) + descr_len + 1;
				n = (const void*) ((const char*) n + sizeof(struct gg_notify_reply60) + descr_len + 1);
			} else {
				length = 0;
			}
		} else {
			length -= sizeof(struct gg_notify_reply60);
			n = (const void*) ((const char*) n + sizeof(struct gg_notify_reply60));
		}
		if (!(tmp = realloc(ge->event.notify60, (i + 2) * sizeof(*ge->event.notify60)))) {
			gg_debug_session(gs, GG_DEBUG_MISC, "// gg_watch_fd_connected() out of memory\n");
			free(ge->event.notify60);
			return -1;
		}
		ge->event.notify60 = tmp;
		ge->event.notify60[++i].uin = 0;
	}
	return 0;
}
