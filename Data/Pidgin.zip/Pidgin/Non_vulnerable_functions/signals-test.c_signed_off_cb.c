static void
signed_off_cb(PurpleConnection *gc, void *data)
{
	purple_debug_misc("signals test", "signed-off (%s)\n",
					purple_account_get_username(purple_connection_get_account(gc)));
}
