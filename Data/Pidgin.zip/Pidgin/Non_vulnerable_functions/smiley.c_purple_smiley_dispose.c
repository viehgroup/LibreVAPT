static void
purple_smiley_dispose(GObject *gobj)
{
	g_signal_emit(gobj, signals[SIG_DESTROY], 0);
	parent_class->dispose(gobj);
}
