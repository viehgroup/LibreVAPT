}
guint16 byte_stream_get16(ByteStream *bs)
{
	g_return_val_if_fail(byte_stream_bytes_left(bs) >= 2, 0);
	bs->offset += 2;
	return aimutil_get16(bs->data + bs->offset - 2);
}
