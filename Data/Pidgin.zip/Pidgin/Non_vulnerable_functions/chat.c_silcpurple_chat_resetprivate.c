static void
silcpurple_chat_resetprivate(PurpleBlistNode *node, gpointer data)
{
	PurpleChat *chat;
	PurpleConnection *gc;
	SilcPurple sg;
	g_return_if_fail(PURPLE_BLIST_NODE_IS_CHAT(node));
	chat = (PurpleChat *) node;
	gc = purple_account_get_connection(chat->account);
	sg = gc->proto_data;
	silc_client_command_call(sg->client, sg->conn, NULL, "CMODE",
				 g_hash_table_lookup(chat->components, "channel"),
				 "-p", NULL);
}
