static void
add_contact(PurpleContact *contact, FinchBlist *ggblist)
{
	gpointer parent;
	PurpleBlistNode *node = (PurpleBlistNode*)contact;
	const char *name;
	if (FINCH_GET_DATA(node))
		return;
	name = get_display_name(node);
	if (name == NULL)
		return;
	parent = ggblist->manager->find_parent((PurpleBlistNode*)contact);
	create_finch_blist_node(node, gnt_tree_add_row_after(GNT_TREE(ggblist->tree), contact,
				gnt_tree_create_row(GNT_TREE(ggblist->tree), name),
				parent, NULL));
	gnt_tree_set_expanded(GNT_TREE(ggblist->tree), contact, FALSE);
}
