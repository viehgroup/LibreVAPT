static void
buddy_idle_changed(PurpleBuddy *buddy, int old, int new, FinchBlist *ggblist)
{
	update_buddy_display(buddy, ggblist);
}
