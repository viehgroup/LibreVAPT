static void
gtk_source_undo_manager_check_list_size (GtkSourceUndoManager *um)
{
	gint undo_levels;
	g_return_if_fail (GTK_SOURCE_IS_UNDO_MANAGER (um));
	g_return_if_fail (um->priv != NULL);
	undo_levels = gtk_source_undo_manager_get_max_undo_levels (um);
	if (undo_levels < 1)
		return;
	if (um->priv->num_of_groups > undo_levels)
	{
		GtkSourceUndoAction *undo_action;
		GList *last;
		last = g_list_last (um->priv->actions);
		undo_action = (GtkSourceUndoAction*) last->data;
		do
		{
			GList *tmp;
			if (undo_action->order_in_group == 1)
				--um->priv->num_of_groups;
			if (undo_action->modified)
				um->priv->modified_action = NULL;
			gtk_source_undo_action_free (undo_action);
			tmp = g_list_previous (last);
			um->priv->actions = g_list_delete_link (um->priv->actions, last);
			last = tmp;
			g_return_if_fail (last != NULL);
			undo_action = (GtkSourceUndoAction*) last->data;
		} while ((undo_action->order_in_group > 1) ||
			 (um->priv->num_of_groups > undo_levels));
	}
}
