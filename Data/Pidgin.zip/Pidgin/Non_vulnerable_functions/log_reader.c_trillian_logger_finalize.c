}
static void trillian_logger_finalize(PurpleLog *log)
{
	struct trillian_logger_data *data;
	g_return_if_fail(log != NULL);
	data = log->logger_data;
	g_free(data->path);
	g_free(data->their_nickname);
	g_free(data);
}
