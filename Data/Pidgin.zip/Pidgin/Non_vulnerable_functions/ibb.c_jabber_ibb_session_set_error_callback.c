void
jabber_ibb_session_set_error_callback(JabberIBBSession *sess,
	JabberIBBErrorCallback *cb)
{
	sess->error_cb = cb;
}
